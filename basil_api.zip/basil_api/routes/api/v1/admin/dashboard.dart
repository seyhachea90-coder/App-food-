import 'package:basil_api/basil_api.dart';
import 'package:basil_api/src/http/admin_rows.dart';
import 'package:dart_frog/dart_frog.dart';

/// GET /api/v1/admin/dashboard — KPI cards + latest orders table.
Future<Response> onRequest(RequestContext context) => handle(context, {
      HttpMethod.get: () {
        final store = context.store;
        final now = DateTime.now();
        bool sameDay(DateTime a, DateTime b) => a.year == b.year && a.month == b.month && a.day == b.day;
        final yesterday = now.subtract(const Duration(days: 1));
        final orders = store.orders.values.toList()..sort((a, b) => b.createdAt.compareTo(a.createdAt));
        final today = orders.where((o) => sameDay(o.createdAt.toLocal(), now)).toList();
        final yesterdayCount = orders.where((o) => sameDay(o.createdAt.toLocal(), yesterday)).length;
        final paidToday = today.where((o) => o.status != OrderStatus.cancelled);
        final revenue = paidToday.fold(0, (sum, o) => sum + o.quote.totalCents);
        final change = yesterdayCount == 0 ? null : ((today.length - yesterdayCount) / yesterdayCount * 100).round();

        return ok({
          'kpis': [
            {
              'key': 'orders_today',
              'label': 'Orders today',
              'value': today.length,
              'changePct': change,
              'changeLabel': change == null ? 'No orders yesterday' : '${change >= 0 ? '+' : ''}$change% vs yesterday',
            },
            {'key': 'revenue_today', 'label': 'Revenue today', 'valueCents': revenue},
            {
              'key': 'active_orders',
              'label': 'Active orders',
              'value': orders.where((o) => o.status.isActive).length,
            },
            {
              'key': 'average_order',
              'label': 'Average order',
              'valueCents': paidToday.isEmpty ? 0 : revenue ~/ paidToday.length,
            },
            {
              'key': 'customers',
              'label': 'Customers',
              'value': store.users.values.where((u) => u.role == UserRole.customer).length,
            },
          ],
          'recentOrders': orders.take(8).map(adminOrderRow).toList(),
        });
      },
    });

import '../http/api_exception.dart';
import '../models/models.dart';
import '../security/crypto.dart';
import '../services/pricing.dart';
import 'seed.dart';

/// A geocoded place returned by the address search.
class Place {
  const Place(this.id, this.street, this.city, this.state, this.zip, this.lat, this.lng, this.name);

  final String id;
  final String street;
  final String city;
  final String state;
  final String zip;
  final double lat;
  final double lng;
  final String? name;

  Map<String, dynamic> toJson() => {
        'placeId': id,
        'name': name,
        'street': street,
        'city': city,
        'state': state,
        'zip': zip,
        'formatted': '$street, $city, $state $zip',
        'location': {'lat': lat, 'lng': lng},
      };
}

class FaqEntry {
  const FaqEntry(this.id, this.topic, this.question, this.answer);
  final String id;
  final String topic;
  final String question;
  final String answer;

  Map<String, dynamic> toJson() =>
      {'id': id, 'topic': topic, 'question': question, 'answer': answer};
}

/// In-memory data store. Data resets every time the server restarts.
///
/// Replace with a real database by keeping these method signatures and
/// swapping the maps for repository calls.
class Store {
  Store._() {
    seedStore(this);
  }

  /// Fresh store (used by tests).
  factory Store.fresh() => Store._();

  static final Store instance = Store._();

  final settings = PlatformSettings();
  final users = <String, User>{};
  final refreshTokens = <String, RefreshSession>{};
  final resetTokens = <String, ResetTicket>{};
  final categories = <Category>[];
  final restaurants = <String, Restaurant>{};
  final dishes = <String, Dish>{};
  final addresses = <String, Address>{};
  final paymentMethods = <String, PaymentMethod>{};
  final carts = <String, Cart>{};
  final coupons = <String, Coupon>{};
  final orders = <String, Order>{};
  final couriers = <String, Courier>{};
  final messages = <ChatMessage>[];
  final reviews = <Review>[];
  final favorites = <String, Favorite>{};
  final notifications = <AppNotification>[];
  final supportMessages = <SupportMessage>[];
  final uploads = <String, Upload>{};
  final places = <Place>[];
  final faqs = <FaqEntry>[];
  final trendingSearches = <String>[];

  int orderSequence = 1037;

  String nextOrderNumber() => 'BSL-${++orderSequence}';

  // ---- Lookups (throw 404 when missing) ----

  User? userByEmail(String email) =>
      users.values.where((u) => u.email == email.toLowerCase()).firstOrNull;

  Restaurant restaurant(String id) =>
      restaurants[id] ?? (throw ApiException.notFound('Restaurant'));

  Dish dish(String id) => dishes[id] ?? (throw ApiException.notFound('Dish'));

  Category? category(String id) =>
      categories.where((c) => c.id == id).firstOrNull;

  Address ownedAddress(User user, String id) {
    final a = addresses[id];
    if (a == null || a.userId != user.id) throw ApiException.notFound('Address');
    return a;
  }

  PaymentMethod ownedPaymentMethod(User user, String id) {
    final p = paymentMethods[id];
    if (p == null || p.userId != user.id) {
      throw ApiException.notFound('Payment method');
    }
    return p;
  }

  /// Accepts the order id (`ord_...`) or its number (`BSL-1038`).
  Order ownedOrder(User user, String idOrNumber) {
    final o = orderByIdOrNumber(idOrNumber);
    if (o == null || o.userId != user.id) throw ApiException.notFound('Order');
    return o;
  }

  Order? orderByIdOrNumber(String idOrNumber) {
    final key = idOrNumber.startsWith('#') ? idOrNumber.substring(1) : idOrNumber;
    return orders[key] ??
        orders.values
            .where((o) => o.number.toUpperCase() == key.toUpperCase())
            .firstOrNull;
  }

  // ---- Per-user collections ----

  List<Address> addressesOf(String userId) {
    final list = addresses.values.where((a) => a.userId == userId).toList()
      ..sort((a, b) => (b.isDefault ? 1 : 0) - (a.isDefault ? 1 : 0));
    return list;
  }

  Address? defaultAddressOf(String userId) {
    final list = addressesOf(userId);
    return list.where((a) => a.isDefault).firstOrNull ?? list.firstOrNull;
  }

  List<PaymentMethod> paymentMethodsOf(String userId) {
    final list = paymentMethods.values.where((p) => p.userId == userId).toList()
      ..sort((a, b) => (b.isDefault ? 1 : 0) - (a.isDefault ? 1 : 0));
    return list;
  }

  PaymentMethod? defaultPaymentMethodOf(String userId) {
    final list = paymentMethodsOf(userId);
    return list.where((p) => p.isDefault).firstOrNull ?? list.firstOrNull;
  }

  Cart cartOf(String userId) => carts.putIfAbsent(userId, () => Cart(userId));

  List<Order> ordersOf(String userId) =>
      orders.values.where((o) => o.userId == userId).toList()
        ..sort((a, b) => b.createdAt.compareTo(a.createdAt));

  List<Favorite> favoritesOf(String userId) =>
      favorites.values.where((f) => f.userId == userId).toList()
        ..sort((a, b) => b.createdAt.compareTo(a.createdAt));

  List<AppNotification> notificationsOf(String userId) =>
      notifications.where((n) => n.userId == userId).toList()
        ..sort((a, b) => b.createdAt.compareTo(a.createdAt));

  bool isFavoriteRestaurant(String userId, String restaurantId) =>
      favorites.values.any(
        (f) => f.userId == userId && f.type == 'restaurant' && f.restaurantId == restaurantId,
      );

  int placeCount(String categoryId) =>
      restaurants.values.where((r) => r.categoryIds.contains(categoryId)).length;

  void notify(
    String userId, {
    required String type,
    required String title,
    required String body,
    String? orderId,
  }) {
    notifications.add(
      AppNotification(
        id: newId('ntf'),
        userId: userId,
        type: type,
        title: title,
        body: body,
        orderId: orderId,
        createdAt: DateTime.now().toUtc(),
      ),
    );
  }

  /// Removes a user and everything personal tied to them. Orders are kept
  /// (needed for restaurant accounting) but no longer reachable by the user.
  void deleteUser(User user) {
    users.remove(user.id);
    addresses.removeWhere((_, a) => a.userId == user.id);
    paymentMethods.removeWhere((_, p) => p.userId == user.id);
    favorites.removeWhere((_, f) => f.userId == user.id);
    carts.remove(user.id);
    notifications.removeWhere((n) => n.userId == user.id);
    supportMessages.removeWhere((m) => m.userId == user.id);
    refreshTokens.removeWhere((_, s) => s.userId == user.id);
    resetTokens.removeWhere((_, t) => t.userId == user.id);
    uploads.removeWhere((_, u) => u.ownerId == user.id);
  }
}

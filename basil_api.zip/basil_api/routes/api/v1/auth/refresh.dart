import 'package:basil_api/basil_api.dart';
import 'package:dart_frog/dart_frog.dart';

/// POST /api/v1/auth/refresh — swap a refresh token for a new token pair.
/// The old refresh token stops working (rotation).
Future<Response> onRequest(RequestContext context) => handle(context, {
      HttpMethod.post: () async {
        final body = await Body.parse(context);
        final token = body.string('refreshToken', required: true);
        body.validate();

        final store = context.store;
        final session = store.refreshTokens.remove(token);
        final user = session == null ? null : store.users[session.userId];
        if (session == null || user == null || session.expiresAt.isBefore(DateTime.now().toUtc())) {
          throw ApiException(401, 'REFRESH_TOKEN_INVALID', 'Please sign in again.');
        }
        return ok(issueSession(store, user));
      },
    });

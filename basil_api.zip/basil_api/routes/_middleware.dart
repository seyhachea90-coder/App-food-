import 'dart:io';

import 'package:basil_api/basil_api.dart';
import 'package:dart_frog/dart_frog.dart';

/// Root middleware (outermost first): CORS → error handling → request log →
/// data store → authentication.
Handler middleware(Handler handler) {
  return handler
      .use(_authenticate())
      .use(provider<Store>((_) => Store.instance))
      .use(_errors())
      .use(requestLogger())
      .use(_cors());
}

const _corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, PATCH, DELETE, OPTIONS',
  'Access-Control-Allow-Headers': 'Origin, Content-Type, Accept, Authorization',
};

Middleware _cors() => (handler) => (context) async {
      if (context.request.method == HttpMethod.options) {
        return Response(statusCode: HttpStatus.noContent, headers: _corsHeaders);
      }
      final response = await handler(context);
      return response.copyWith(headers: {...response.headers, ..._corsHeaders});
    };

/// Turns [ApiException]s (and unexpected errors) into JSON error responses.
Middleware _errors() => (handler) => (context) async {
      try {
        return await handler(context);
      } on ApiException catch (e) {
        return Response.json(statusCode: e.statusCode, body: e.toJson());
      } on Object catch (e, stack) {
        stderr.writeln('Unhandled error on ${context.request.uri}: $e\n$stack');
        return Response.json(
          statusCode: HttpStatus.internalServerError,
          body: ApiException(500, 'INTERNAL_ERROR', 'Something went wrong on our side.').toJson(),
        );
      }
    };

/// Reads `Authorization: Bearer <accessToken>` when present. Routes decide
/// whether a user is required (`context.user`) or optional (`context.userOrNull`).
Middleware _authenticate() => (handler) => (context) {
      final header = context.request.headers['authorization'];
      User? user;
      if (header != null && header.toLowerCase().startsWith('bearer ')) {
        final token = header.substring(7).trim();
        final claims = Config.jwt.verify(token);
        if (claims == null || claims['type'] != 'access') {
          throw ApiException(
            401,
            'TOKEN_INVALID',
            'Your session has expired. Refresh the token or sign in again.',
          );
        }
        user = context.read<Store>().users[claims['sub']];
        if (user == null) {
          throw ApiException(401, 'TOKEN_INVALID', 'This account no longer exists.');
        }
      }
      return handler(context.provide<AuthContext>(() => AuthContext(user)));
    };

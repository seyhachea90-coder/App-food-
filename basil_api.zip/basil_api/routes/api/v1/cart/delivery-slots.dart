import 'package:basil_api/basil_api.dart';
import 'package:dart_frog/dart_frog.dart';

/// GET /api/v1/cart/delivery-slots — "Fresh, on your time." day + window picker.
/// Uses the cart's restaurant, or `?restaurantId=`. Times are server local time.
Future<Response> onRequest(RequestContext context) => handle(context, {
      HttpMethod.get: () {
        final user = context.user;
        final store = context.store;
        final restaurantId = context.queryString('restaurantId') ?? store.cartOf(user.id).restaurantId;
        if (restaurantId == null) {
          throw ApiException.unprocessable('CART_EMPTY', 'Add something to your bag, or pass ?restaurantId=.');
        }
        final r = store.restaurant(restaurantId);
        return ok({
          'restaurantId': r.id,
          'asap': {
            'available': r.isAcceptingOrders && r.isOpenNow,
            'label': 'As soon as possible',
            'description': 'Arrives in ${r.deliveryMinMinutes}–${r.deliveryMaxMinutes} min after ordering',
          },
          'timezoneOffsetMinutes': DateTime.now().timeZoneOffset.inMinutes,
          'days': OrderService(store).deliverySlots(r),
          'note': 'Your food will be prepared fresh for your selected window. '
              'Delivery fee stays ${formatCents(r.deliveryFeeCents)}.',
        });
      },
    });

import 'package:basil_api/basil_api.dart';
import 'package:dart_frog/dart_frog.dart';

/// POST /api/v1/auth/reset-password — "A fresh start." (Create a new password)
Future<Response> onRequest(RequestContext context) => handle(context, {
      HttpMethod.post: () async {
        final body = await Body.parse(context);
        final token = body.string('token', required: true);
        final password = body.password('newPassword');
        final confirm = body.string('confirmPassword', required: true);
        if (password != null && confirm != null && password != confirm) {
          body.fail('confirmPassword', 'Passwords do not match.');
        }
        body.validate();

        final store = context.store;
        final ticket = store.resetTokens.remove(token);
        final user = ticket == null ? null : store.users[ticket.userId];
        if (ticket == null || user == null || ticket.expiresAt.isBefore(DateTime.now().toUtc())) {
          throw ApiException.badRequest(
            'This reset link is invalid or has expired. Request a new one.',
            code: 'RESET_TOKEN_INVALID',
          );
        }
        user.passwordHash = hashPassword(password!);
        // Sign out everywhere after a password reset.
        store.refreshTokens.removeWhere((_, s) => s.userId == user.id);
        return ok({'message': 'Password updated. You can sign in with your new password.'});
      },
    });

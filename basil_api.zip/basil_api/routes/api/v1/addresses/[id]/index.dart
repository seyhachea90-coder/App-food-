import 'package:basil_api/basil_api.dart';
import 'package:basil_api/src/http/address_input.dart';
import 'package:dart_frog/dart_frog.dart';

/// /api/v1/addresses/{id} — view, edit, remove a saved address.
Future<Response> onRequest(RequestContext context, String id) => handle(context, {
      HttpMethod.get: () => ok(context.store.ownedAddress(context.user, id).toJson()),
      HttpMethod.patch: () async {
        final user = context.user;
        final store = context.store;
        final address = store.ownedAddress(user, id);
        final input = AddressInput.read(await Body.parse(context), partial: true);
        input.applyTo(address);
        if (input.isDefault ?? false) {
          for (final a in store.addressesOf(user.id)) {
            a.isDefault = a.id == address.id;
          }
        }
        return ok(address.toJson());
      },
      HttpMethod.delete: () {
        final user = context.user;
        final store = context.store;
        final address = store.ownedAddress(user, id);
        store.addresses.remove(address.id);
        // Promote another address to default if needed.
        final rest = store.addressesOf(user.id);
        if (address.isDefault && rest.isNotEmpty) rest.first.isDefault = true;
        return ok({'message': 'Address removed.', 'id': address.id});
      },
    });

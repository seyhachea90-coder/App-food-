import 'package:basil_api/basil_api.dart';
import 'package:dart_frog/dart_frog.dart';

/// POST /api/v1/notifications/read-all — "Mark all as read".
Future<Response> onRequest(RequestContext context) => handle(context, {
      HttpMethod.post: () {
        final user = context.user;
        final now = DateTime.now().toUtc();
        var updated = 0;
        for (final n in context.store.notificationsOf(user.id).where((n) => n.readAt == null)) {
          n.readAt = now;
          updated++;
        }
        return ok({'updated': updated, 'unreadCount': 0});
      },
    });

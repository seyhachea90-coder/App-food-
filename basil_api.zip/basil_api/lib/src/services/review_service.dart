import 'package:dart_frog/dart_frog.dart';

import '../http/request.dart';
import '../models/models.dart';

/// Builds the "Loved around here." reviews payload (summary + filtered page).
Response reviewsResponse(
  RequestContext context, {
  required Iterable<Review> reviews,
  required Map<int, int> breakdown,
  required double average,
}) {
  final filter = context.queryEnum('filter', ['all', 'five_stars', 'with_photos'], 'all');
  final sort = context.queryEnum('sort', ['newest', 'highest', 'lowest'], 'newest');
  final page = Pagination.of(context);

  final list = reviews.where((r) => r.isPublic).where((r) {
    return switch (filter) {
      'five_stars' => r.rating == 5,
      'with_photos' => r.photoUrls.isNotEmpty,
      _ => true,
    };
  }).toList();
  switch (sort) {
    case 'highest':
      list.sort((a, b) => b.rating.compareTo(a.rating));
    case 'lowest':
      list.sort((a, b) => a.rating.compareTo(b.rating));
    default:
      list.sort((a, b) => b.createdAt.compareTo(a.createdAt));
  }

  final total = breakdown.values.fold(0, (a, b) => a + b);
  return ok(
    {
      'summary': {
        'average': average,
        'total': total,
        'breakdown': {for (var s = 5; s >= 1; s--) '$s': breakdown[s] ?? 0},
      },
      'items': page.slice(list).map((r) => r.toJson()).toList(),
    },
    meta: {...page.meta(list.length), 'filter': filter, 'sort': sort},
  );
}

import 'package:basil_api/basil_api.dart';
import 'package:basil_api/src/http/admin_rows.dart';
import 'package:dart_frog/dart_frog.dart';

/// GET /api/v1/admin/orders?q=&status=&restaurantId= — "Search orders, dishes..."
Future<Response> onRequest(RequestContext context) => handle(context, {
      HttpMethod.get: () {
        final store = context.store;
        final q = context.queryString('q')?.toLowerCase();
        final status = context.queryString('status');
        if (status != null && OrderStatus.parse(status) == null) {
          throw ApiException.validation({
            'status': 'Use: ${OrderStatus.values.map((s) => s.value).join(', ')}.',
          });
        }
        final restaurantId = context.queryString('restaurantId');
        final page = Pagination.of(context);
        final list = store.orders.values
            .where((o) => status == null || o.status.value == status)
            .where((o) => restaurantId == null || o.restaurantId == restaurantId)
            .where(
              (o) =>
                  q == null ||
                  '${o.number} ${o.customerName} ${o.restaurantName} ${o.itemsSummary}'.toLowerCase().contains(q),
            )
            .toList()
          ..sort((a, b) => b.createdAt.compareTo(a.createdAt));
        return ok(page.slice(list).map(adminOrderRow).toList(), meta: page.meta(list.length));
      },
    });

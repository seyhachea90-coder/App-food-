import 'package:basil_api/basil_api.dart';
import 'package:dart_frog/dart_frog.dart';

/// GET /api/v1/orders/{id}/receipt?format=json|text — "Download receipt".
Future<Response> onRequest(RequestContext context, String id) => handle(context, {
      HttpMethod.get: () {
        final order = context.store.ownedOrder(context.user, id);
        final service = OrderService(context.store);
        final format = context.queryEnum('format', ['json', 'text'], 'json');
        if (format == 'text') {
          return Response(
            body: service.receiptText(order),
            headers: {
              'Content-Type': 'text/plain; charset=utf-8',
              'Content-Disposition': 'attachment; filename="basil-receipt-${order.number}.txt"',
            },
          );
        }
        return ok(service.receiptJson(order));
      },
    });

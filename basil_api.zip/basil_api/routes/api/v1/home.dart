import 'package:basil_api/basil_api.dart';
import 'package:dart_frog/dart_frog.dart';

/// GET /api/v1/home — "What sounds good, Dara?"
/// Works for guests; signed-in users get their name and delivery address.
Future<Response> onRequest(RequestContext context) => handle(context, {
      HttpMethod.get: () {
        final store = context.store;
        final catalog = CatalogService(store);
        final user = context.userOrNull;
        final address = user == null ? null : store.defaultAddressOf(user.id);
        final (lat, lng) = catalog.origin(context);

        final popular = catalog.searchRestaurants(RestaurantFilters(sort: 'top_rated'))
            .where((r) => r.isAcceptingOrders)
            .take(6);
        final recommended = store.dishes.values
            .where((d) => d.isPopular && d.isAvailable)
            .toList()
          ..sort((a, b) => b.rating.compareTo(a.rating));

        return ok({
          'greeting': user == null ? 'What sounds good?' : 'What sounds good, ${user.firstName}?',
          'deliveryAddress': address?.toJson(),
          'categories': store.categories
              .take(4)
              .map((c) => c.toJson(placeCount: store.placeCount(c.id)))
              .toList(),
          'popularRestaurants': popular
              .map((r) => {
                    ...r.toSummaryJson(fromLat: lat, fromLng: lng),
                    if (user != null) 'isFavorite': store.isFavoriteRestaurant(user.id, r.id),
                  })
              .toList(),
          'recommendedDishes': recommended.take(6).map(catalog.dishJson).toList(),
        });
      },
    });

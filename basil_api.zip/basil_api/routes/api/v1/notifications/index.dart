import 'package:basil_api/basil_api.dart';
import 'package:dart_frog/dart_frog.dart';

/// GET /api/v1/notifications?filter=all|unread — "A little heads-up."
/// Grouped by local day ("Today · November 3", "Earlier").
Future<Response> onRequest(RequestContext context) => handle(context, {
      HttpMethod.get: () {
        final user = context.user;
        final filter = context.queryEnum('filter', ['all', 'unread'], 'all');
        final page = Pagination.of(context);
        final all = context.store.notificationsOf(user.id);
        final list = filter == 'unread' ? all.where((n) => n.readAt == null).toList() : all;
        final today = DateTime.now();
        return ok(
          page.slice(list).map((n) {
            final local = n.createdAt.toLocal();
            final isToday =
                local.year == today.year && local.month == today.month && local.day == today.day;
            return {...n.toJson(), 'group': isToday ? 'today' : 'earlier'};
          }).toList(),
          meta: {
            ...page.meta(list.length),
            'unreadCount': all.where((n) => n.readAt == null).length,
          },
        );
      },
    });

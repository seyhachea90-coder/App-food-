import '../security/crypto.dart';

class Review {
  Review({
    required this.id,
    required this.target,
    required this.userId,
    required this.authorName,
    required this.restaurantId,
    required this.rating,
    required this.createdAt,
    this.orderId,
    this.dishId,
    this.courierId,
    this.orderedItem,
    this.tags = const [],
    this.comment,
    this.photoUrls = const [],
    this.isPublic = true,
    this.verified = true,
  });

  static const targets = ['restaurant', 'dish', 'courier'];

  /// Allowed "What stood out?" chips per target (from the rating screens).
  static const tagOptions = {
    'restaurant': [
      'order_accuracy',
      'thoughtful_packaging',
      'ready_on_time',
      'great_value',
    ],
    'courier': ['friendly', 'handled_with_care', 'followed_instructions', 'on_time'],
    'dish': ['fresh', 'great_portion', 'delicious'],
  };

  static const ratingLabels = {
    1: 'Not great',
    2: 'Could be better',
    3: 'Pretty good',
    4: 'A great experience',
    5: 'Absolutely delicious',
  };

  final String id;
  final String target;
  final String userId;
  final String authorName;
  final String restaurantId;
  final String? orderId;
  final String? dishId;
  final String? courierId;
  final String? orderedItem;
  final int rating;
  final List<String> tags;
  final String? comment;
  final List<String> photoUrls;
  final bool isPublic;
  final bool verified;
  final DateTime createdAt;

  Map<String, dynamic> toJson() => {
        'id': id,
        'target': target,
        'author': {
          'name': authorName,
          'initials': authorName
              .split(' ')
              .where((p) => p.isNotEmpty)
              .map((p) => p[0])
              .take(2)
              .join()
              .toUpperCase(),
        },
        'rating': rating,
        'ratingLabel': ratingLabels[rating],
        'tags': tags,
        'comment': comment,
        'photoUrls': photoUrls,
        'verifiedOrder': verified,
        'orderedItem': orderedItem,
        'restaurantId': restaurantId,
        'dishId': dishId,
        'courierId': courierId,
        'orderId': orderId,
        'isPublic': isPublic,
        'createdAt': iso(createdAt),
      };
}

class Favorite {
  Favorite({
    required this.id,
    required this.userId,
    required this.type,
    required this.restaurantId,
    required this.createdAt,
    this.dishId,
    this.sizeId,
    this.addOnIds = const [],
    this.note,
  });

  final String id;
  final String userId;

  /// `restaurant` or `dish`.
  final String type;
  final String restaurantId;
  final String? dishId;

  /// Saved customization (only for dishes; all optional).
  final String? sizeId;
  final List<String> addOnIds;
  final String? note;
  final DateTime createdAt;

  bool get hasCustomization =>
      sizeId != null || addOnIds.isNotEmpty || note != null;
}

class AppNotification {
  AppNotification({
    required this.id,
    required this.userId,
    required this.type,
    required this.title,
    required this.body,
    required this.createdAt,
    this.orderId,
    this.readAt,
  });

  final String id;
  final String userId;

  /// `order_update`, `receipt`, `promotion`, `favorites`, `account`.
  final String type;
  final String title;
  final String body;
  final String? orderId;
  final DateTime createdAt;
  DateTime? readAt;

  Map<String, dynamic> toJson() => {
        'id': id,
        'type': type,
        'title': title,
        'body': body,
        'orderId': orderId,
        'isRead': readAt != null,
        'readAt': readAt == null ? null : iso(readAt!),
        'createdAt': iso(createdAt),
      };
}

class SupportMessage {
  SupportMessage({
    required this.id,
    required this.userId,
    required this.sender,
    required this.authorName,
    required this.text,
    required this.createdAt,
    this.orderId,
  });

  final String id;
  final String userId;

  /// `customer`, `agent` or `system`.
  final String sender;
  final String authorName;
  final String text;
  final String? orderId;
  final DateTime createdAt;

  Map<String, dynamic> toJson() => {
        'id': id,
        'sender': sender,
        'authorName': authorName,
        'text': text,
        'orderId': orderId,
        'createdAt': iso(createdAt),
      };
}

class Upload {
  Upload({
    required this.id,
    required this.ownerId,
    required this.contentType,
    required this.bytes,
    required this.createdAt,
  });

  final String id;
  final String ownerId;
  final String contentType;
  final List<int> bytes;
  final DateTime createdAt;

  String get url => '/api/v1/uploads/$id';
}

import 'package:basil_api/basil_api.dart';
import 'package:dart_frog/dart_frog.dart';

/// GET /api/v1/admin/orders/{id} — full order (id or number).
Future<Response> onRequest(RequestContext context, String id) => handle(context, {
      HttpMethod.get: () {
        final store = context.store;
        final order = store.orderByIdOrNumber(id) ?? (throw ApiException.notFound('Order'));
        return ok({
          ...OrderService(store).detailJson(order),
          'customer': {
            'id': order.userId,
            'name': order.customerName,
            'email': store.users[order.userId]?.email,
          },
        });
      },
    });

import 'dart:io';

import 'security/crypto.dart';

/// Runtime configuration. Override with environment variables.
abstract final class Config {
  static const apiVersion = '1.0.0';
  static const currency = 'USD';

  /// HMAC secret for access tokens. ALWAYS set `JWT_SECRET` outside local dev.
  static final jwtSecret =
      Platform.environment['JWT_SECRET'] ?? 'basil-local-dev-secret-change-me';

  static final jwt = JwtService(jwtSecret);

  static const accessTokenTtl = Duration(hours: 1);
  static const refreshTokenTtl = Duration(days: 30);
  static const resetTokenTtl = Duration(minutes: 30);

  /// In development the API returns the password-reset token in the response
  /// (there is no email service). Set `BASIL_ENV=production` to hide it.
  static final isProduction = Platform.environment['BASIL_ENV'] == 'production';

  /// Maximum delivery distance from a restaurant.
  static const maxDeliveryMiles = 5.0;

  static const maxUploadBytes = 5 * 1024 * 1024;
}

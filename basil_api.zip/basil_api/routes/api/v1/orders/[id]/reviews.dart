import 'package:basil_api/basil_api.dart';
import 'package:dart_frog/dart_frog.dart';

/// /api/v1/orders/{id}/reviews — "Rate restaurant", "Rate courier",
/// "Review your food" / "Write a review". Only for delivered orders, one per
/// target (and per dish).
Future<Response> onRequest(RequestContext context, String id) => handle(context, {
      HttpMethod.get: () {
        final store = context.store;
        final order = store.ownedOrder(context.user, id);
        final reviews = store.reviews.where((r) => r.orderId == order.id);
        return ok({
          'reviews': reviews.map((r) => r.toJson()).toList(),
          'tagOptions': Review.tagOptions,
          'ratingLabels': {for (final e in Review.ratingLabels.entries) '${e.key}': e.value},
        });
      },
      HttpMethod.post: () async {
        final user = context.user;
        final store = context.store;
        final order = store.ownedOrder(user, id);
        final body = await Body.parse(context);
        final target = body.string('target', required: true, oneOf: Review.targets);
        final rating = body.integer('rating', required: true, min: 1, max: 5);
        final dishId = body.string('dishId', required: target == 'dish');
        final tags = body.strings('tags', maxItems: 6) ?? <String>[];
        final comment = body.string('comment', max: 500);
        final photoUrls = body.strings('photoUrls', maxItems: 5) ?? <String>[];
        final isPublic = body.boolean('isPublic') ?? true;
        if (target != null) {
          final allowed = Review.tagOptions[target]!;
          final bad = tags.where((t) => !allowed.contains(t));
          if (bad.isNotEmpty) body.fail('tags', 'For $target use: ${allowed.join(', ')}.');
        }
        if (photoUrls.any((u) => !u.startsWith('/api/v1/uploads/') && !u.startsWith('https://'))) {
          body.fail('photoUrls', 'Upload photos with POST /api/v1/uploads and use the returned url.');
        }
        if (target == 'courier' && photoUrls.isNotEmpty) {
          body.fail('photoUrls', 'Courier ratings do not take photos.');
        }
        body.validate();

        if (order.status != OrderStatus.delivered) {
          throw ApiException.conflict('ORDER_NOT_DELIVERED', 'You can rate this order once it is delivered.');
        }
        final orderItem = dishId == null ? null : order.items.where((i) => i.dishId == dishId).firstOrNull;
        if (target == 'dish' && orderItem == null) {
          throw ApiException.validation({'dishId': 'That dish is not part of this order.'});
        }
        if (target == 'courier' && order.courierId == null) {
          throw ApiException.conflict('NO_COURIER', 'This order had no courier.');
        }
        final key = target == 'dish' ? 'dish:$dishId' : target!;
        if (order.reviewIds.containsKey(key)) {
          throw ApiException.conflict('ALREADY_REVIEWED', 'You already shared a rating for this.');
        }

        final review = Review(
          id: newId('rev'),
          target: target!,
          userId: user.id,
          authorName: user.publicName,
          restaurantId: order.restaurantId,
          orderId: order.id,
          dishId: target == 'courier' ? null : (dishId ?? order.items.first.dishId),
          courierId: target == 'courier' ? order.courierId : null,
          orderedItem: orderItem?.name ?? order.items.first.name,
          rating: rating!,
          tags: tags,
          comment: comment,
          photoUrls: photoUrls,
          // Courier ratings never appear publicly.
          isPublic: target != 'courier' && isPublic,
          createdAt: DateTime.now().toUtc(),
        );
        store.reviews.add(review);
        order.reviewIds[key] = review.id;

        switch (target) {
          case 'restaurant':
            final r = store.restaurants[order.restaurantId];
            if (r != null) r.ratingBreakdown[rating] = (r.ratingBreakdown[rating] ?? 0) + 1;
          case 'dish':
            final d = store.dishes[dishId];
            if (d != null) d.ratingBreakdown[rating] = (d.ratingBreakdown[rating] ?? 0) + 1;
          case 'courier':
            final c = store.couriers[order.courierId];
            if (c != null) {
              final n = c.deliveries.clamp(1, 100000);
              c.rating = double.parse(((c.rating * n + rating) / (n + 1)).toStringAsFixed(2));
            }
        }
        return created(review.toJson());
      },
    });

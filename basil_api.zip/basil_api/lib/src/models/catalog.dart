import 'dart:math';

class Category {
  Category({required this.id, required this.name, required this.imageUrl});

  final String id;
  final String name;
  final String imageUrl;

  Map<String, dynamic> toJson({int? placeCount}) => {
        'id': id,
        'name': name,
        'imageUrl': imageUrl,
        if (placeCount != null) 'placeCount': placeCount,
      };
}

class OpeningHours {
  const OpeningHours(this.label, this.weekdays, this.opens, this.closes);

  /// e.g. "Monday–Thursday".
  final String label;

  /// ISO weekdays (1 = Monday ... 7 = Sunday).
  final List<int> weekdays;

  /// 24h "HH:mm".
  final String opens;
  final String closes;

  static int toMinutes(String hhmm) {
    final parts = hhmm.split(':');
    return int.parse(parts[0]) * 60 + int.parse(parts[1]);
  }

  bool covers(DateTime t) {
    final m = t.hour * 60 + t.minute;
    return weekdays.contains(t.weekday) &&
        m >= toMinutes(opens) &&
        m < toMinutes(closes);
  }

  Map<String, dynamic> toJson() => {
        'label': label,
        'weekdays': weekdays,
        'opens': opens,
        'closes': closes,
      };
}

class Restaurant {
  Restaurant({
    required this.id,
    required this.name,
    required this.cuisines,
    required this.categoryIds,
    required this.neighborhood,
    required this.tagline,
    required this.description,
    required this.address,
    required this.phone,
    required this.lat,
    required this.lng,
    required this.ratingBreakdown,
    required this.deliveryMinMinutes,
    required this.deliveryMaxMinutes,
    required this.deliveryFeeCents,
    required this.minOrderCents,
    required this.priceLevel,
    required this.hours,
    required this.menuSections,
    required this.imageUrl,
    this.dietary = const [],
    this.offer,
    this.badge,
    this.isAcceptingOrders = true,
  });

  final String id;
  String name;
  List<String> cuisines;
  List<String> categoryIds;
  String neighborhood;
  String tagline;
  String description;
  String address;
  String phone;
  double lat;
  double lng;

  /// Star -> count, e.g. {5: 207, 4: 28, ...}.
  final Map<int, int> ratingBreakdown;
  int deliveryMinMinutes;
  int deliveryMaxMinutes;
  int deliveryFeeCents;
  int minOrderCents;

  /// 1..4 ($ .. $$$$).
  int priceLevel;
  List<OpeningHours> hours;
  List<String> menuSections;
  String imageUrl;
  List<String> dietary;
  String? offer;
  String? badge;
  bool isAcceptingOrders;

  int get ratingCount => ratingBreakdown.values.fold(0, (a, b) => a + b);

  double get rating {
    final total = ratingCount;
    if (total == 0) return 0;
    var sum = 0;
    ratingBreakdown.forEach((star, count) => sum += star * count);
    return double.parse((sum / total).toStringAsFixed(1));
  }

  bool isOpenAt(DateTime local) => hours.any((h) => h.covers(local));

  bool get isOpenNow => isOpenAt(DateTime.now());

  String? get closesTodayAt {
    final now = DateTime.now();
    for (final h in hours) {
      if (h.covers(now)) return h.closes;
    }
    return null;
  }

  double? distanceMilesTo(double? lat2, double? lng2) {
    if (lat2 == null || lng2 == null) return null;
    return double.parse(haversineMiles(lat, lng, lat2, lng2).toStringAsFixed(1));
  }

  Map<String, dynamic> toSummaryJson({double? fromLat, double? fromLng}) => {
        'id': id,
        'name': name,
        'imageUrl': imageUrl,
        'cuisines': cuisines,
        'neighborhood': neighborhood,
        'rating': rating,
        'ratingCount': ratingCount,
        'deliveryTime': {
          'minMinutes': deliveryMinMinutes,
          'maxMinutes': deliveryMaxMinutes,
        },
        'deliveryFeeCents': deliveryFeeCents,
        'priceLevel': priceLevel,
        'distanceMiles': distanceMilesTo(fromLat, fromLng),
        'offer': offer,
        'badge': badge,
        'isAcceptingOrders': isAcceptingOrders,
        'isOpenNow': isOpenNow,
      };

  Map<String, dynamic> toDetailJson({double? fromLat, double? fromLng}) => {
        ...toSummaryJson(fromLat: fromLat, fromLng: fromLng),
        'tagline': tagline,
        'description': description,
        'address': address,
        'phone': phone,
        'location': {'lat': lat, 'lng': lng},
        'minOrderCents': minOrderCents,
        'closesTodayAt': closesTodayAt,
        'hours': hours.map((h) => h.toJson()).toList(),
        'dietary': dietary,
        'categoryIds': categoryIds,
        'menuSections': menuSections,
        'ratingBreakdown': {
          for (var star = 5; star >= 1; star--)
            '$star': ratingBreakdown[star] ?? 0,
        },
      };
}

class DishOption {
  DishOption({
    required this.id,
    required this.name,
    required this.priceDeltaCents,
    this.description,
  });

  final String id;
  final String name;
  final String? description;
  final int priceDeltaCents;

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'description': description,
        'priceDeltaCents': priceDeltaCents,
      };
}

class Dish {
  Dish({
    required this.id,
    required this.restaurantId,
    required this.name,
    required this.description,
    required this.priceCents,
    required this.section,
    required this.imageUrl,
    required this.sizes,
    this.details,
    this.addOns = const [],
    this.dietary = const [],
    this.tags = const [],
    this.allergens,
    this.isPopular = false,
    this.isAvailable = true,
    Map<int, int>? ratingBreakdown,
  }) : ratingBreakdown = ratingBreakdown ?? {};

  final String id;
  final String restaurantId;
  String name;
  String description;
  String? details;
  int priceCents;
  String section;
  String imageUrl;

  /// Always at least one size; the first one is the base size.
  List<DishOption> sizes;
  List<DishOption> addOns;
  List<String> dietary;
  List<String> tags;
  String? allergens;
  bool isPopular;
  bool isAvailable;
  final Map<int, int> ratingBreakdown;

  int get ratingCount => ratingBreakdown.values.fold(0, (a, b) => a + b);

  double get rating {
    final total = ratingCount;
    if (total == 0) return 0;
    var sum = 0;
    ratingBreakdown.forEach((star, count) => sum += star * count);
    return double.parse((sum / total).toStringAsFixed(1));
  }

  DishOption? sizeById(String id) =>
      sizes.where((s) => s.id == id).firstOrNull;

  DishOption? addOnById(String id) =>
      addOns.where((a) => a.id == id).firstOrNull;

  Map<String, dynamic> toSummaryJson(Restaurant restaurant) => {
        'id': id,
        'name': name,
        'description': description,
        'priceCents': priceCents,
        'imageUrl': imageUrl,
        'section': section,
        'dietary': dietary,
        'rating': rating,
        'ratingCount': ratingCount,
        'isPopular': isPopular,
        'isAvailable': isAvailable,
        'hasOptions': sizes.length > 1 || addOns.isNotEmpty,
        'restaurant': {
          'id': restaurant.id,
          'name': restaurant.name,
          'rating': restaurant.rating,
        },
      };

  Map<String, dynamic> toDetailJson(Restaurant restaurant) => {
        ...toSummaryJson(restaurant),
        'details': details ?? description,
        'allergens': allergens,
        'options': {
          'size': {
            'required': true,
            'defaultId': sizes.first.id,
            'choices': sizes.map((s) => s.toJson()).toList(),
          },
          'addOns': {
            'required': false,
            'choices': addOns.map((a) => a.toJson()).toList(),
          },
          'kitchenNote': {'maxLength': 200},
          'quantity': {'min': 1, 'max': 20},
        },
      };
}

double haversineMiles(double lat1, double lng1, double lat2, double lng2) {
  const earthRadiusMiles = 3958.8;
  double rad(double d) => d * pi / 180;
  final dLat = rad(lat2 - lat1);
  final dLng = rad(lng2 - lng1);
  final a = sin(dLat / 2) * sin(dLat / 2) +
      cos(rad(lat1)) * cos(rad(lat2)) * sin(dLng / 2) * sin(dLng / 2);
  return earthRadiusMiles * 2 * atan2(sqrt(a), sqrt(1 - a));
}

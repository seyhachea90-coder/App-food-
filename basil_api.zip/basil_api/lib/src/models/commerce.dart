import '../security/crypto.dart';

class DeliverySchedule {
  const DeliverySchedule.asap()
      : type = 'asap',
        date = null,
        windowStart = null,
        windowEnd = null;

  const DeliverySchedule.scheduled({
    required String this.date,
    required String this.windowStart,
    required String this.windowEnd,
  }) : type = 'scheduled';

  /// `asap` or `scheduled`.
  final String type;

  /// `YYYY-MM-DD` (server local date).
  final String? date;

  /// `HH:mm` (server local time).
  final String? windowStart;
  final String? windowEnd;

  bool get isScheduled => type == 'scheduled';

  DateTime? get windowStartAt =>
      isScheduled ? DateTime.parse('${date}T$windowStart:00') : null;
  DateTime? get windowEndAt =>
      isScheduled ? DateTime.parse('${date}T$windowEnd:00') : null;

  Map<String, dynamic> toJson() => {
        'type': type,
        if (isScheduled) ...{
          'date': date,
          'windowStart': windowStart,
          'windowEnd': windowEnd,
        },
      };
}

class CartItem {
  CartItem({
    required this.id,
    required this.dishId,
    required this.sizeId,
    required this.addOnIds,
    required this.quantity,
    this.note,
  });

  final String id;
  final String dishId;
  String sizeId;
  List<String> addOnIds;
  String? note;
  int quantity;
}

class Cart {
  Cart(this.userId);

  final String userId;
  String? restaurantId;
  final List<CartItem> items = [];
  String? promoCode;
  String? addressId;
  DeliverySchedule schedule = const DeliverySchedule.asap();
  String? paymentMethodId;

  void clearItems() {
    items.clear();
    restaurantId = null;
    promoCode = null;
    schedule = const DeliverySchedule.asap();
  }
}

enum CouponType { percentOff, amountOff, freeDelivery }

class Coupon {
  Coupon({
    required this.code,
    required this.title,
    required this.type,
    required this.value,
    required this.minSubtotalCents,
    required this.validUntil,
    this.maxDiscountCents,
    this.restaurantId,
  });

  final String code;
  final String title;
  final CouponType type;

  /// Percent for [CouponType.percentOff], cents for [CouponType.amountOff].
  final int value;
  final int minSubtotalCents;
  final int? maxDiscountCents;
  final DateTime validUntil;

  /// Null = valid at every restaurant.
  final String? restaurantId;

  bool get isExpired => DateTime.now().isAfter(validUntil);

  Map<String, dynamic> toJson() => {
        'code': code,
        'title': title,
        'type': switch (type) {
          CouponType.percentOff => 'percent_off',
          CouponType.amountOff => 'amount_off',
          CouponType.freeDelivery => 'free_delivery',
        },
        'value': value,
        'minSubtotalCents': minSubtotalCents,
        'maxDiscountCents': maxDiscountCents,
        'restaurantId': restaurantId,
        'validUntil': iso(validUntil),
      };
}

class PriceQuote {
  PriceQuote({
    required this.itemCount,
    required this.subtotalCents,
    required this.foodDiscountCents,
    required this.deliveryFeeCents,
    required this.deliveryDiscountCents,
    required this.serviceFeeCents,
    required this.taxCents,
    this.promoCode,
  });

  final int itemCount;
  final int subtotalCents;
  final int foodDiscountCents;
  final int deliveryFeeCents;
  final int deliveryDiscountCents;
  final int serviceFeeCents;
  final int taxCents;
  final String? promoCode;

  int get savingsCents => foodDiscountCents + deliveryDiscountCents;

  int get totalCents =>
      subtotalCents -
      foodDiscountCents +
      deliveryFeeCents -
      deliveryDiscountCents +
      serviceFeeCents +
      taxCents;

  Map<String, dynamic> toJson() => {
        'currency': 'USD',
        'itemCount': itemCount,
        'subtotalCents': subtotalCents,
        'promoCode': promoCode,
        'foodDiscountCents': foodDiscountCents,
        'deliveryFeeCents': deliveryFeeCents,
        'deliveryDiscountCents': deliveryDiscountCents,
        'serviceFeeCents': serviceFeeCents,
        'taxCents': taxCents,
        'savingsCents': savingsCents,
        'totalCents': totalCents,
      };
}

enum OrderStatus {
  pending('pending', 'Pending'),
  confirmed('confirmed', 'Confirmed'),
  preparing('preparing', 'Preparing'),
  onTheWay('on_the_way', 'On the way'),
  delivered('delivered', 'Delivered'),
  cancelled('cancelled', 'Cancelled');

  const OrderStatus(this.value, this.label);
  final String value;
  final String label;

  static OrderStatus? parse(String? value) =>
      OrderStatus.values.where((s) => s.value == value).firstOrNull;

  bool get isActive =>
      this != OrderStatus.delivered && this != OrderStatus.cancelled;
}

class OrderItem {
  OrderItem({
    required this.dishId,
    required this.name,
    required this.imageUrl,
    required this.basePriceCents,
    required this.size,
    required this.addOns,
    required this.quantity,
    this.note,
  });

  final String dishId;
  final String name;
  final String imageUrl;
  final int basePriceCents;

  /// `{id, name, priceDeltaCents}`.
  final Map<String, dynamic> size;
  final List<Map<String, dynamic>> addOns;
  final int quantity;
  final String? note;

  int get unitPriceCents =>
      basePriceCents +
      (size['priceDeltaCents'] as int) +
      addOns.fold<int>(0, (sum, a) => sum + (a['priceDeltaCents'] as int));

  int get totalCents => unitPriceCents * quantity;

  Map<String, dynamic> toJson() => {
        'dishId': dishId,
        'name': name,
        'imageUrl': imageUrl,
        'basePriceCents': basePriceCents,
        'size': size,
        'addOns': addOns,
        'note': note,
        'quantity': quantity,
        'unitPriceCents': unitPriceCents,
        'totalCents': totalCents,
      };
}

class OrderEvent {
  OrderEvent(this.status, this.title, this.description, this.at);

  final OrderStatus status;
  final String title;
  final String description;
  final DateTime at;

  Map<String, dynamic> toJson() => {
        'status': status.value,
        'title': title,
        'description': description,
        'at': iso(at),
      };
}

class Order {
  Order({
    required this.id,
    required this.number,
    required this.userId,
    required this.customerName,
    required this.restaurantId,
    required this.restaurantName,
    required this.items,
    required this.quote,
    required this.address,
    required this.schedule,
    required this.payment,
    required this.createdAt,
    this.status = OrderStatus.confirmed,
  });

  final String id;

  /// Human-facing number, e.g. `BSL-1038`.
  final String number;
  final String userId;
  final String customerName;
  final String restaurantId;
  final String restaurantName;
  final List<OrderItem> items;
  final PriceQuote quote;

  /// Address snapshot (Address.toJson + `addressId`).
  final Map<String, dynamic> address;
  final DeliverySchedule schedule;
  final Map<String, dynamic> payment;
  final DateTime createdAt;
  OrderStatus status;
  final List<OrderEvent> events = [];
  String? courierId;
  DateTime? pickedUpAt;
  DateTime? deliveredAt;
  String dropoff = 'hand_to_me';
  String? dropoffNote;
  String? cancelReason;
  bool refunded = false;

  /// Review ids keyed by target (`restaurant`, `courier`, `dish:<dishId>`).
  final Map<String, String> reviewIds = {};

  int get itemCount => items.fold(0, (sum, i) => sum + i.quantity);

  String get itemsSummary =>
      items.map((i) => '${i.quantity}× ${i.name}').join(', ');
}

class Courier {
  Courier({
    required this.id,
    required this.name,
    required this.vehicle,
    required this.rating,
    required this.deliveries,
    required this.proxyPhone,
  });

  final String id;
  final String name;
  final String vehicle;
  double rating;
  int deliveries;

  /// Masked relay number so neither side sees the other's real number.
  final String proxyPhone;

  String get firstName => name.split(' ').first;

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'firstName': firstName,
        'vehicle': vehicle,
        'rating': rating,
        'deliveries': deliveries,
        'contactPhone': proxyPhone,
      };
}

class ChatMessage {
  ChatMessage({
    required this.id,
    required this.orderId,
    required this.sender,
    required this.text,
    required this.sentAt,
  });

  final String id;
  final String orderId;

  /// `customer` or `courier`.
  final String sender;
  final String text;
  final DateTime sentAt;
  bool read = false;

  Map<String, dynamic> toJson() => {
        'id': id,
        'sender': sender,
        'text': text,
        'sentAt': iso(sentAt),
        'read': read,
      };
}

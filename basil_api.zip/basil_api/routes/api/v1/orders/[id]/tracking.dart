import 'package:basil_api/basil_api.dart';
import 'package:dart_frog/dart_frog.dart';

/// GET /api/v1/orders/{id}/tracking — "Order status", "Your courier",
/// "Live tracking", "Arriving soon", "Delivered". Poll every 10–15 s while
/// `isLive` is true.
Future<Response> onRequest(RequestContext context, String id) => handle(context, {
      HttpMethod.get: () {
        final order = context.store.ownedOrder(context.user, id);
        return ok(OrderService(context.store).trackingJson(order));
      },
    });

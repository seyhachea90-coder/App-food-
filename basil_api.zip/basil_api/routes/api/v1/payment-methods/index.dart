import 'package:basil_api/basil_api.dart';
import 'package:dart_frog/dart_frog.dart';

/// Test card tokens. The app must never send raw card numbers to this API:
/// collect the card with your payment provider's SDK (e.g. Stripe) and send
/// the token it returns. These tokens mimic that in development.
const _testTokens = {
  'tok_visa': ('visa', '4242', false),
  'tok_mastercard': ('mastercard', '4444', false),
  'tok_amex': ('amex', '8431', false),
  'tok_card_declined': ('visa', '0002', true),
};

/// /api/v1/payment-methods — "Payment management" / "Payment methods".
Future<Response> onRequest(RequestContext context) => handle(context, {
      HttpMethod.get: () {
        final list = context.store.paymentMethodsOf(context.user.id);
        return ok(
          list.map((p) => p.toJson()).toList(),
          meta: {
            'total': list.length,
            'testCardTokens': _testTokens.keys.toList(),
          },
        );
      },
      // "Add a new card" / "Connect" PayPal / Apple Pay.
      HttpMethod.post: () async {
        final user = context.user;
        final store = context.store;
        final body = await Body.parse(context);
        final type = body.string('type', required: true, oneOf: PaymentMethod.types);
        final token = body.string('token', required: type == 'card');
        final holderName = body.string('holderName', max: 80);
        final expMonth = body.integer('expMonth', min: 1, max: 12);
        final expYear = body.integer('expYear', min: 2000, max: 2100);
        final email = type == 'paypal' ? body.email('email', required: true) : null;
        final setDefault = body.boolean('setDefault') ?? false;
        if (type == 'card' && token != null && !_testTokens.containsKey(token)) {
          body.fail('token', 'Unknown card token. Test tokens: ${_testTokens.keys.join(', ')}.');
        }
        final now = DateTime.now();
        if (expMonth != null && expYear != null &&
            (expYear < now.year || (expYear == now.year && expMonth < now.month))) {
          body.fail('expYear', 'This card has expired.');
        }
        body.validate();

        final existing = store.paymentMethodsOf(user.id);
        if (existing.length >= 10) {
          throw ApiException.unprocessable('PAYMENT_METHOD_LIMIT', 'You can save up to 10 payment methods.');
        }
        if (type != 'card' && existing.any((p) => p.type == type)) {
          throw ApiException.conflict('ALREADY_CONNECTED', 'This wallet is already connected.');
        }

        final PaymentMethod method;
        if (type == 'card') {
          final (brand, last4, declines) = _testTokens[token]!;
          if (existing.any((p) => p.brand == brand && p.last4 == last4)) {
            throw ApiException.conflict('CARD_EXISTS', 'This card is already saved.');
          }
          method = PaymentMethod(
            id: newId('pm'),
            userId: user.id,
            type: 'card',
            brand: brand,
            last4: last4,
            expMonth: expMonth ?? 12,
            expYear: expYear ?? now.year + 3,
            holderName: holderName ?? user.fullName,
            declines: declines,
          );
        } else {
          method = PaymentMethod(id: newId('pm'), userId: user.id, type: type!, email: email);
        }
        if (existing.isEmpty || setDefault) {
          for (final p in existing) {
            p.isDefault = false;
          }
          method.isDefault = true;
        }
        store.paymentMethods[method.id] = method;
        return created(method.toJson());
      },
    });

import 'package:basil_api/basil_api.dart';
import 'package:dart_frog/dart_frog.dart';

/// GET /api/v1/search?q=pizza&type=all — "Search results"
/// (Restaurants (12) | Dishes (36) tabs). Accepts every filter from
/// GET /api/v1/search/filters. Signed-in searches are saved to recent searches.
Future<Response> onRequest(RequestContext context) => handle(context, {
      HttpMethod.get: () {
        final store = context.store;
        final catalog = CatalogService(store);
        final filters = RestaurantFilters.fromQuery(context);
        final q = filters.q;
        if (q == null) throw ApiException.validation({'q': 'Type something to search for.'});
        if (q.length > 80) throw ApiException.validation({'q': 'Must be 80 characters or fewer.'});
        final type = context.queryEnum('type', ['all', 'restaurants', 'dishes'], 'all');
        final page = Pagination.of(context);
        final (lat, lng) = catalog.origin(context);

        final user = context.userOrNull;
        if (user != null) {
          user.recentSearches
            ..removeWhere((s) => s.toLowerCase() == q.toLowerCase())
            ..insert(0, q);
          if (user.recentSearches.length > 10) user.recentSearches.removeLast();
        }

        final restaurants = catalog.searchRestaurants(filters);
        final dishes = catalog.searchDishes(filters);
        final empty = restaurants.isEmpty && dishes.isEmpty;
        final address = user == null ? null : store.defaultAddressOf(user.id);

        return ok(
          {
            'query': q,
            'restaurants': {
              'total': restaurants.length,
              'items': type == 'dishes'
                  ? <Object>[]
                  : page.slice(restaurants).map((r) => r.toSummaryJson(fromLat: lat, fromLng: lng)).toList(),
            },
            'dishes': {
              'total': dishes.length,
              'items': type == 'restaurants' ? <Object>[] : page.slice(dishes).map(catalog.dishJson).toList(),
            },
            'nearLabel': address == null ? null : '${restaurants.length} places near ${address.displayLabel}',
            'emptyState': empty
                ? {
                    'title': 'No bites just yet.',
                    'message': 'No matches for “$q”. Check the spelling or clear your filters.',
                    'suggestedQueries': ['Pizza', 'Bowls', 'Coffee'],
                  }
                : null,
          },
          meta: page.meta(type == 'dishes' ? dishes.length : restaurants.length),
        );
      },
    });

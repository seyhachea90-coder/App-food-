import '../models/models.dart';
import '../security/crypto.dart';

/// One row of the admin orders table:
/// Order | Customer | Items | Total | Status | Date.
Map<String, dynamic> adminOrderRow(Order o) => {
      'id': o.id,
      'number': o.number,
      'customer': o.customerName,
      'customerId': o.userId,
      'restaurant': o.restaurantName,
      'items': o.itemsSummary,
      'totalCents': o.quote.totalCents,
      'status': o.status.value,
      'statusLabel': o.status.label,
      'placedAt': iso(o.createdAt),
    };

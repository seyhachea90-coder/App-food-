import 'package:basil_api/basil_api.dart';
import 'package:dart_frog/dart_frog.dart';

/// /api/v1/cart/items/{itemId} — "Edit item" (Update cart / Remove item from cart).
Future<Response> onRequest(RequestContext context, String itemId) => handle(context, {
      HttpMethod.patch: () async {
        final user = context.user;
        final store = context.store;
        final carts = CartService(store);
        final cart = store.cartOf(user.id);
        final item = _find(cart, itemId);
        final dish = store.dish(item.dishId);

        final body = await Body.parse(context);
        final sizeId = body.string('sizeId');
        final addOnIds = body.strings('addOnIds', maxItems: 10);
        final note = body.string('note', max: 200);
        final quantity = body.integer('quantity', min: 1, max: 20);
        body.validate();
        final (size, addOns) = carts.validateSelection(
          body,
          dish,
          sizeId: sizeId ?? item.sizeId,
          addOnIds: addOnIds ?? item.addOnIds,
        );
        body.validate();

        item
          ..sizeId = size!.id
          ..addOnIds = (addOns.map((a) => a.id).toList()..sort());
        if (body.has('note')) item.note = note;
        if (quantity != null) item.quantity = quantity;
        return ok(carts.toJson(cart));
      },
      HttpMethod.delete: () {
        final user = context.user;
        final store = context.store;
        final cart = store.cartOf(user.id);
        final item = _find(cart, itemId);
        cart.items.remove(item);
        if (cart.items.isEmpty) cart.clearItems();
        return ok(CartService(store).toJson(cart));
      },
    });

CartItem _find(Cart cart, String id) =>
    cart.items.where((i) => i.id == id).firstOrNull ?? (throw ApiException.notFound('Cart item'));

import 'package:basil_api/basil_api.dart';
import 'package:dart_frog/dart_frog.dart';

/// POST /api/v1/payment-methods/{id}/default — "Set as default".
Future<Response> onRequest(RequestContext context, String id) => handle(context, {
      HttpMethod.post: () {
        final user = context.user;
        final store = context.store;
        final method = store.ownedPaymentMethod(user, id);
        if (method.isExpired) {
          throw ApiException.unprocessable('CARD_EXPIRED', 'An expired card can’t be the default.');
        }
        for (final p in store.paymentMethodsOf(user.id)) {
          p.isDefault = p.id == method.id;
        }
        return ok(method.toJson());
      },
    });

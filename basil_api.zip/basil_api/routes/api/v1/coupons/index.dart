import 'package:basil_api/basil_api.dart';
import 'package:dart_frog/dart_frog.dart';

/// GET /api/v1/coupons — "Your coupons" checked against the current cart
/// (eligible / not eligible / applied, and how much more unlocks it).
Future<Response> onRequest(RequestContext context) => handle(context, {
      HttpMethod.get: () {
        final user = context.user;
        final store = context.store;
        final carts = CartService(store);
        final cart = store.cartOf(user.id);
        final restaurant = carts.restaurantOf(cart);
        final subtotal = carts.subtotal(cart);

        final list = store.coupons.values.where((c) => !c.isExpired).map((c) {
          final check = checkCoupon(c, restaurant, subtotal);
          return {
            ...c.toJson(),
            'eligible': cart.items.isNotEmpty && check.eligible,
            'applied': cart.promoCode == c.code && check.eligible,
            'savingsCents': check.savingsCents,
            'amountToUnlockCents': check.amountToUnlockCents,
            'reason': cart.items.isEmpty ? 'Add something to your bag first.' : check.reason,
          };
        }).toList();
        return ok(list, meta: {
          'appliedCode': cart.promoCode,
          'note': 'One coupon per order. Applying another offer replaces the current one.',
        });
      },
    });

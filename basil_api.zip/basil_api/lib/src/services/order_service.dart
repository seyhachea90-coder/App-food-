import '../data/store.dart';
import '../http/api_exception.dart';
import '../models/models.dart';
import '../security/crypto.dart';
import 'cart_service.dart';
import 'pricing.dart';

const _flow = [
  OrderStatus.pending,
  OrderStatus.confirmed,
  OrderStatus.preparing,
  OrderStatus.onTheWay,
  OrderStatus.delivered,
];

/// Steps shown on the status tracker: Confirmed → Preparing → On the way → Delivered.
const _trackerSteps = [
  OrderStatus.confirmed,
  OrderStatus.preparing,
  OrderStatus.onTheWay,
  OrderStatus.delivered,
];

const _tripMinutes = 12;

String _two(int n) => n.toString().padLeft(2, '0');

String dateKey(DateTime d) => '${d.year}-${_two(d.month)}-${_two(d.day)}';

String hhmm(DateTime d) => '${_two(d.hour)}:${_two(d.minute)}';

/// 12:30 -> "12:30 pm".
String clockLabel(DateTime d) {
  final h = d.hour % 12 == 0 ? 12 : d.hour % 12;
  return '$h:${_two(d.minute)} ${d.hour < 12 ? 'am' : 'pm'}';
}

String rangeLabel(DateTime a, DateTime b) {
  final start = clockLabel(a);
  final end = clockLabel(b);
  final sameHalf = (a.hour < 12) == (b.hour < 12);
  return sameHalf ? '${start.substring(0, start.length - 3)}–$end' : '$start–$end';
}

const _weekdayNames = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
const _monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

/// "Tue, Nov 3".
String dayLabel(DateTime d) => '${_weekdayNames[d.weekday - 1]}, ${_monthNames[d.month - 1]} ${d.day}';

class OrderService {
  OrderService(this.store) : carts = CartService(store);

  final Store store;
  final CartService carts;

  // ---------------- Delivery slots ----------------

  /// 30-minute delivery windows for today and tomorrow inside opening hours.
  /// Times are in the server's local time zone.
  List<Map<String, dynamic>> deliverySlots(Restaurant r) {
    final now = DateTime.now();
    final earliest = now.add(const Duration(minutes: 45));
    final days = <Map<String, dynamic>>[];
    for (var offset = 0; offset < 2; offset++) {
      final day = DateTime(now.year, now.month, now.day + offset);
      final windows = <Map<String, dynamic>>[];
      for (final h in r.hours.where((h) => h.weekdays.contains(day.weekday))) {
        var start = day.add(Duration(minutes: OpeningHours.toMinutes(h.opens)));
        final close = day.add(Duration(minutes: OpeningHours.toMinutes(h.closes)));
        while (!start.add(const Duration(minutes: 30)).isAfter(close)) {
          final end = start.add(const Duration(minutes: 30));
          if (!start.isBefore(earliest)) {
            windows.add({
              'start': hhmm(start),
              'end': hhmm(end),
              'label': rangeLabel(start, end),
            });
          }
          start = end;
        }
      }
      days.add({
        'date': dateKey(day),
        'label': offset == 0 ? 'Today' : 'Tomorrow',
        'displayDate': dayLabel(day),
        'windows': windows,
      });
    }
    return days;
  }

  // ---------------- Placing an order ----------------

  Order placeOrder(User user, Cart cart) {
    final lines = carts.lines(cart);
    final restaurant = carts.restaurantOf(cart);
    if (lines.isEmpty || restaurant == null) {
      throw ApiException.unprocessable('CART_EMPTY', 'Your cart is empty.');
    }
    if (!restaurant.isAcceptingOrders) {
      throw ApiException.conflict(
        'RESTAURANT_NOT_ACCEPTING_ORDERS',
        '${restaurant.name} has temporarily paused new orders.',
      );
    }
    final unavailable = lines.where((l) => !l.dish.isAvailable).map((l) => l.dish.name);
    if (unavailable.isNotEmpty) {
      throw ApiException.conflict(
        'ITEMS_UNAVAILABLE',
        'No longer available: ${unavailable.join(', ')}.',
      );
    }
    final quote = carts.quote(cart);
    if (quote.subtotalCents < restaurant.minOrderCents) {
      throw ApiException.unprocessable(
        'MINIMUM_ORDER_NOT_MET',
        'Minimum order is ${formatCents(restaurant.minOrderCents)}.',
      );
    }
    final address = carts.addressOf(cart);
    if (address == null) {
      throw ApiException.unprocessable('ADDRESS_REQUIRED', 'Add a delivery address.');
    }
    final delivery = carts.deliverability(restaurant, address);
    if (delivery != null && delivery['deliversHere'] == false) {
      throw ApiException.unprocessable('ADDRESS_OUT_OF_RANGE', delivery['message'] as String);
    }
    final payment = carts.paymentOf(cart);
    if (payment == null) {
      throw ApiException.unprocessable('PAYMENT_METHOD_REQUIRED', 'Add a payment method.');
    }
    if (payment.isExpired) {
      throw ApiException.unprocessable('CARD_EXPIRED', 'This card has expired. Choose another.');
    }
    if (cart.schedule.isScheduled &&
        !cart.schedule.windowStartAt!.isAfter(DateTime.now().add(const Duration(minutes: 30)))) {
      throw ApiException.unprocessable(
        'SCHEDULE_EXPIRED',
        'That delivery window is no longer available. Pick another time.',
      );
    }
    // Mock payment processor: test cards created with `tok_card_declined`
    // are always declined.
    if (payment.declines) {
      throw ApiException(402, 'PAYMENT_DECLINED', 'Your card was declined. Try another payment method.');
    }

    final now = DateTime.now().toUtc();
    final order = Order(
      id: newId('ord'),
      number: store.nextOrderNumber(),
      userId: user.id,
      customerName: user.fullName,
      restaurantId: restaurant.id,
      restaurantName: restaurant.name,
      items: lines.map((l) => l.toOrderItem()).toList(),
      quote: quote,
      address: {'addressId': address.id, ...address.toJson()},
      schedule: cart.schedule,
      payment: payment.toSnapshot(),
      createdAt: now,
    )
      ..dropoff = address.dropoff
      ..dropoffNote = address.instructions;
    order.events.add(
      OrderEvent(
        OrderStatus.confirmed,
        'Order accepted',
        cart.schedule.isScheduled
            ? 'Scheduled order accepted by the kitchen.'
            : 'Accepted by the kitchen.',
        now,
      ),
    );
    store.orders[order.id] = order;
    store.notify(
      user.id,
      type: 'order_update',
      title: 'Order confirmed',
      body: '${restaurant.name} has received your order #${order.number}.',
      orderId: order.id,
    );
    cart.clearItems();
    return order;
  }

  // ---------------- Status changes ----------------

  void setStatus(Order order, OrderStatus next, {String? reason}) {
    final current = order.status;
    if (current == next) return;
    if (!current.isActive) {
      throw ApiException.conflict(
        'ORDER_CLOSED',
        'Order is already ${current.label.toLowerCase()}.',
      );
    }
    if (next != OrderStatus.cancelled &&
        _flow.indexOf(next) != _flow.indexOf(current) + 1) {
      throw ApiException.conflict(
        'INVALID_STATUS_TRANSITION',
        'Cannot move from ${current.value} to ${next.value}. Next allowed: '
            '${_flow[_flow.indexOf(current) + 1].value} or cancelled.',
      );
    }
    final now = DateTime.now().toUtc();
    final firstName = store.users[order.userId]?.firstName ?? 'you';
    order.status = next;
    switch (next) {
      case OrderStatus.pending:
        break;
      case OrderStatus.confirmed:
        order.events.add(OrderEvent(next, 'Order accepted', 'Accepted by the kitchen.', now));
      case OrderStatus.preparing:
        order.courierId ??= store.couriers.keys.first;
        order.events.add(
          OrderEvent(next, 'Preparing your order', 'Made fresh by ${order.restaurantName}.', now),
        );
      case OrderStatus.onTheWay:
        order
          ..courierId ??= store.couriers.keys.first
          ..pickedUpAt = now;
        final courier = store.couriers[order.courierId]!;
        order.events.add(
          OrderEvent(next, 'Picked up', '${courier.firstName} picked up your order.', now),
        );
        store.messages.add(
          ChatMessage(
            id: newId('msg'),
            orderId: order.id,
            sender: 'courier',
            text: 'Hi $firstName! I’ve picked up your ${order.restaurantName} order. I’m on my way!',
            sentAt: now,
          ),
        );
        store.notify(
          order.userId,
          type: 'order_update',
          title: '${courier.firstName} is on the way',
          body: 'Your courier picked up order #${order.number} from ${order.restaurantName}.',
          orderId: order.id,
        );
      case OrderStatus.delivered:
        order.deliveredAt = now;
        final courier = store.couriers[order.courierId];
        if (courier != null) courier.deliveries++;
        order.events.add(
          OrderEvent(
            next,
            'Delivered',
            'Handed to $firstName${courier == null ? '' : ' by ${courier.name}'}.',
            now,
          ),
        );
        store
          ..notify(
            order.userId,
            type: 'order_update',
            title: 'Lunch has landed.',
            body: '${courier?.name ?? 'Your courier'} delivered your ${order.restaurantName} order #${order.number}.',
            orderId: order.id,
          )
          ..notify(
            order.userId,
            type: 'receipt',
            title: 'Your receipt is ready',
            body: '${formatCents(order.quote.totalCents)} paid with ${order.payment['label']}. '
                'View your receipt in order details.',
            orderId: order.id,
          );
      case OrderStatus.cancelled:
        order
          ..cancelReason = reason
          ..refunded = true;
        order.events.add(
          OrderEvent(next, 'Order cancelled', reason ?? 'This order was cancelled. You have been refunded.', now),
        );
        store.notify(
          order.userId,
          type: 'order_update',
          title: 'Order cancelled',
          body: 'Order #${order.number} was cancelled. ${formatCents(order.quote.totalCents)} '
              'will be refunded to ${order.payment['label']}.',
          orderId: order.id,
        );
    }
  }

  // ---------------- JSON ----------------

  Map<String, dynamic>? eta(Order o) {
    if (!o.status.isActive) return null;
    final r = store.restaurants[o.restaurantId];
    final now = DateTime.now();
    DateTime from;
    DateTime to;
    if (o.status == OrderStatus.onTheWay && o.pickedUpAt != null) {
      from = o.pickedUpAt!.toLocal().add(const Duration(minutes: _tripMinutes));
      to = from;
    } else if (o.schedule.isScheduled) {
      from = o.schedule.windowStartAt!;
      to = o.schedule.windowEndAt!;
    } else {
      final base = o.createdAt.toLocal();
      from = base.add(Duration(minutes: r?.deliveryMinMinutes ?? 20));
      to = base.add(Duration(minutes: r?.deliveryMaxMinutes ?? 30));
    }
    final minutesAway = to.difference(now).inMinutes;
    return {
      'from': iso(from),
      'to': iso(to),
      'label': from == to ? clockLabel(from) : rangeLabel(from, to),
      'minutesAway': minutesAway < 0 ? 0 : minutesAway,
    };
  }

  List<Map<String, dynamic>> steps(Order o) {
    final currentIndex = _trackerSteps.indexOf(o.status);
    return [
      for (var i = 0; i < _trackerSteps.length; i++)
        {
          'status': _trackerSteps[i].value,
          'label': _trackerSteps[i].label,
          'state': o.status == OrderStatus.cancelled
              ? 'cancelled'
              : i < currentIndex
                  ? 'done'
                  : i == currentIndex
                      ? (o.status == OrderStatus.delivered ? 'done' : 'current')
                      : 'upcoming',
          'at': o.events
              .where((e) => e.status == _trackerSteps[i])
              .map((e) => iso(e.at))
              .firstOrNull,
        },
    ];
  }

  Map<String, dynamic> summaryJson(Order o) {
    final r = store.restaurants[o.restaurantId];
    return {
      'id': o.id,
      'number': o.number,
      'status': o.status.value,
      'statusLabel': o.status.label,
      'restaurant': {
        'id': o.restaurantId,
        'name': o.restaurantName,
        'imageUrl': r?.imageUrl,
        'cuisines': r?.cuisines ?? const <String>[],
      },
      'itemCount': o.itemCount,
      'itemsSummary': o.itemsSummary,
      'totalCents': o.quote.totalCents,
      'placedAt': iso(o.createdAt),
      'deliveredAt': o.deliveredAt == null ? null : iso(o.deliveredAt!),
      'schedule': o.schedule.toJson(),
      'canCancel': o.status == OrderStatus.pending || o.status == OrderStatus.confirmed,
      'canReorder': !o.status.isActive,
      'canRate': o.status == OrderStatus.delivered,
    };
  }

  Map<String, dynamic> detailJson(Order o) {
    final courier = store.couriers[o.courierId];
    return {
      ...summaryJson(o),
      'items': o.items.map((i) => i.toJson()).toList(),
      'pricing': o.quote.toJson(),
      'deliveryAddress': o.address,
      'dropoff': {'method': o.dropoff, 'note': o.dropoffNote},
      'payment': {...o.payment, 'status': o.refunded ? 'refunded' : 'paid'},
      'eta': eta(o),
      'steps': steps(o),
      'events': o.events.map((e) => e.toJson()).toList(),
      'courier': courier?.toJson(),
      'cancelReason': o.cancelReason,
      'reviews': {
        'restaurant': o.reviewIds.containsKey('restaurant'),
        'courier': o.reviewIds.containsKey('courier'),
        'dishes': {
          for (final i in o.items) i.dishId: o.reviewIds.containsKey('dish:${i.dishId}'),
        },
      },
    };
  }

  Map<String, dynamic> trackingJson(Order o) {
    final r = store.restaurants[o.restaurantId];
    final courier = store.couriers[o.courierId];
    final destLat = (o.address['location'] as Map?)?['lat'] as double?;
    final destLng = (o.address['location'] as Map?)?['lng'] as double?;

    Map<String, double>? courierLocation;
    if (courier != null && r != null && destLat != null && destLng != null) {
      var fraction = 0.0;
      if (o.status == OrderStatus.onTheWay && o.pickedUpAt != null) {
        final elapsed = DateTime.now().toUtc().difference(o.pickedUpAt!).inSeconds;
        fraction = (elapsed / (_tripMinutes * 60)).clamp(0.0, 0.95);
      } else if (o.status == OrderStatus.delivered) {
        fraction = 1.0;
      }
      courierLocation = {
        'lat': r.lat + (destLat - r.lat) * fraction,
        'lng': r.lng + (destLng - r.lng) * fraction,
      };
    }

    final headline = switch (o.status) {
      OrderStatus.pending => 'Waiting for payment.',
      OrderStatus.confirmed => 'Order confirmed.',
      OrderStatus.preparing => '${o.restaurantName} is preparing your order.',
      OrderStatus.onTheWay => '${courier?.firstName ?? 'Your courier'} is on the way.',
      OrderStatus.delivered => 'Delivered. Enjoy!',
      OrderStatus.cancelled => 'This order was cancelled.',
    };

    return {
      'orderId': o.id,
      'number': o.number,
      'status': o.status.value,
      'statusLabel': o.status.label,
      'headline': headline,
      'isLive': o.status == OrderStatus.onTheWay,
      'eta': eta(o),
      'steps': steps(o),
      'events': o.events.map((e) => e.toJson()).toList(),
      'courier': courier == null
          ? null
          : {...courier.toJson(), 'location': courierLocation},
      'restaurant': r == null
          ? null
          : {'id': r.id, 'name': r.name, 'location': {'lat': r.lat, 'lng': r.lng}},
      'destination': {
        'label': o.address['displayLabel'],
        'line1': o.address['line1'],
        'line2': o.address['line2'],
        'location': o.address['location'],
      },
      'dropoff': {'method': o.dropoff, 'note': o.dropoffNote},
      'pickedUpAt': o.pickedUpAt == null ? null : iso(o.pickedUpAt!),
      'deliveredAt': o.deliveredAt == null ? null : iso(o.deliveredAt!),
    };
  }

  Map<String, dynamic> receiptJson(Order o) {
    final r = store.restaurants[o.restaurantId];
    return {
      'orderNumber': o.number,
      'customerName': o.customerName,
      'restaurant': {'name': o.restaurantName, 'address': r?.address, 'phone': r?.phone},
      'placedAt': iso(o.createdAt),
      'deliveredAt': o.deliveredAt == null ? null : iso(o.deliveredAt!),
      'deliveryAddress': '${o.address['line1']}, ${o.address['line2']}',
      'items': o.items.map((i) => i.toJson()).toList(),
      'pricing': o.quote.toJson(),
      'payment': {...o.payment, 'status': o.refunded ? 'refunded' : 'paid'},
    };
  }

  String receiptText(Order o) {
    final q = o.quote;
    final b = StringBuffer()
      ..writeln('BASIL — RECEIPT')
      ..writeln('Order #${o.number}')
      ..writeln(o.restaurantName)
      ..writeln('Placed: ${o.createdAt.toLocal()}')
      ..writeln('Deliver to: ${o.address['line1']}, ${o.address['line2']}')
      ..writeln('-' * 40);
    for (final i in o.items) {
      b.writeln('${i.quantity} × ${i.name} (${i.size['name']})  ${formatCents(i.totalCents)}');
      for (final a in i.addOns) {
        b.writeln('    + ${a['name']}  ${formatCents(a['priceDeltaCents'] as int)} each');
      }
      if (i.note != null) b.writeln('    Note: ${i.note}');
    }
    b
      ..writeln('-' * 40)
      ..writeln('Subtotal            ${formatCents(q.subtotalCents)}');
    if (q.foodDiscountCents > 0) {
      b.writeln('${q.promoCode ?? 'Discount'}             ${formatCents(-q.foodDiscountCents)}');
    }
    b.writeln('Delivery fee        ${formatCents(q.deliveryFeeCents)}');
    if (q.deliveryDiscountCents > 0) {
      b.writeln('Delivery discount   ${formatCents(-q.deliveryDiscountCents)}');
    }
    b
      ..writeln('Service fee         ${formatCents(q.serviceFeeCents)}')
      ..writeln('Tax                 ${formatCents(q.taxCents)}')
      ..writeln('TOTAL (USD)         ${formatCents(q.totalCents)}')
      ..writeln('${o.refunded ? 'Refunded to' : 'Paid with'} ${o.payment['label']}');
    return b.toString();
  }
}

import 'package:dart_frog/dart_frog.dart';

import '../data/store.dart';
import '../http/api_exception.dart';
import '../http/request.dart';
import '../models/models.dart';
import '../security/auth_context.dart';

const sortOptions = ['recommended', 'top_rated', 'fastest_delivery', 'lowest_delivery_fee'];
const dietaryOptions = ['vegetarian', 'vegan', 'gluten_free', 'halal'];

/// Filters from the Filters screen, read from query parameters.
class RestaurantFilters {
  RestaurantFilters({
    this.q,
    this.categoryId,
    this.sort = 'recommended',
    this.priceLevels = const [],
    this.maxDeliveryMinutes,
    this.minRating,
    this.dietary = const [],
    this.freeDelivery = false,
    this.offersOnly = false,
  });

  factory RestaurantFilters.fromQuery(RequestContext context) {
    final priceLevels = <int>[];
    for (final p in context.queryList('price')) {
      final v = int.tryParse(p);
      if (v == null || v < 1 || v > 4) {
        throw ApiException.validation({'price': 'Use 1-4, comma separated (e.g. price=1,2).'});
      }
      priceLevels.add(v);
    }
    final dietary = context.queryList('dietary');
    final bad = dietary.where((d) => !dietaryOptions.contains(d));
    if (bad.isNotEmpty) {
      throw ApiException.validation({'dietary': 'Must be any of: ${dietaryOptions.join(', ')}.'});
    }
    final maxMinutes = context.queryInt('maxDeliveryMinutes');
    final minRating = context.queryDouble('minRating');
    if (minRating != null && (minRating < 0 || minRating > 5)) {
      throw ApiException.validation({'minRating': 'Must be between 0 and 5.'});
    }
    return RestaurantFilters(
      q: context.queryString('q'),
      categoryId: context.queryString('categoryId'),
      sort: context.queryEnum('sort', sortOptions, 'recommended'),
      priceLevels: priceLevels,
      maxDeliveryMinutes: maxMinutes,
      minRating: minRating,
      dietary: dietary,
      freeDelivery: context.queryBool('freeDelivery'),
      offersOnly: context.queryBool('offers'),
    );
  }

  final String? q;
  final String? categoryId;
  final String sort;
  final List<int> priceLevels;
  final int? maxDeliveryMinutes;
  final double? minRating;
  final List<String> dietary;
  final bool freeDelivery;
  final bool offersOnly;

  bool matchesRestaurantFilters(Restaurant r) {
    if (categoryId != null && !r.categoryIds.contains(categoryId)) return false;
    if (priceLevels.isNotEmpty && !priceLevels.contains(r.priceLevel)) return false;
    if (maxDeliveryMinutes != null && r.deliveryMaxMinutes > maxDeliveryMinutes!) return false;
    if (minRating != null && r.rating < minRating!) return false;
    if (dietary.any((d) => !r.dietary.contains(d))) return false;
    if (freeDelivery && r.deliveryFeeCents > 0) return false;
    if (offersOnly && r.offer == null) return false;
    return true;
  }
}

class CatalogService {
  CatalogService(this.store);

  final Store store;

  bool _matches(String? haystack, String needle) =>
      haystack != null && haystack.toLowerCase().contains(needle);

  bool restaurantMatchesText(Restaurant r, String q) {
    final n = q.toLowerCase();
    if (_matches(r.name, n) || r.cuisines.any((c) => _matches(c, n))) return true;
    if (r.categoryIds.any((id) => _matches(store.category(id)?.name, n))) return true;
    return store.dishes.values
        .where((d) => d.restaurantId == r.id)
        .any((d) => dishMatchesText(d, n));
  }

  bool dishMatchesText(Dish d, String q) {
    final n = q.toLowerCase();
    return _matches(d.name, n) ||
        _matches(d.description, n) ||
        _matches(d.section, n) ||
        d.tags.any((t) => _matches(t, n));
  }

  List<Restaurant> searchRestaurants(RestaurantFilters f) {
    final list = store.restaurants.values
        .where(f.matchesRestaurantFilters)
        .where((r) => f.q == null || restaurantMatchesText(r, f.q!))
        .toList();
    _sort(list, f.sort);
    return list;
  }

  List<Dish> searchDishes(RestaurantFilters f) {
    final list = store.dishes.values.where((d) {
      final r = store.restaurants[d.restaurantId];
      if (r == null || !f.matchesRestaurantFilters(r)) return false;
      if (f.dietary.any((x) => !d.dietary.contains(x))) return false;
      return f.q == null || dishMatchesText(d, f.q!);
    }).toList()
      ..sort((a, b) => b.rating.compareTo(a.rating));
    return list;
  }

  void _sort(List<Restaurant> list, String sort) {
    switch (sort) {
      case 'top_rated':
        list.sort((a, b) => b.rating.compareTo(a.rating));
      case 'fastest_delivery':
        list.sort((a, b) => a.deliveryMaxMinutes.compareTo(b.deliveryMaxMinutes));
      case 'lowest_delivery_fee':
        list.sort((a, b) => a.deliveryFeeCents.compareTo(b.deliveryFeeCents));
      default:
        // Recommended: accepting orders first, then rating, then speed.
        list.sort((a, b) {
          final open = (b.isAcceptingOrders ? 1 : 0) - (a.isAcceptingOrders ? 1 : 0);
          if (open != 0) return open;
          final rating = b.rating.compareTo(a.rating);
          if (rating != 0) return rating;
          return a.deliveryMaxMinutes.compareTo(b.deliveryMaxMinutes);
        });
    }
  }

  /// The point distances are measured from: `?lat=&lng=` or the user's
  /// default address.
  (double?, double?) origin(RequestContext context) {
    final lat = context.queryDouble('lat');
    final lng = context.queryDouble('lng');
    if (lat != null && lng != null) return (lat, lng);
    final user = context.userOrNull;
    if (user == null) return (null, null);
    final a = store.defaultAddressOf(user.id);
    return (a?.lat, a?.lng);
  }

  Map<String, dynamic> dishJson(Dish d) =>
      d.toSummaryJson(store.restaurant(d.restaurantId));
}

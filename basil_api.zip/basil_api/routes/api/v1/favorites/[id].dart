import 'package:basil_api/basil_api.dart';
import 'package:dart_frog/dart_frog.dart';

/// DELETE /api/v1/favorites/{id} — remove (also used for "Undo").
Future<Response> onRequest(RequestContext context, String id) => handle(context, {
      HttpMethod.delete: () {
        final user = context.user;
        final store = context.store;
        final f = store.favorites[id];
        if (f == null || f.userId != user.id) throw ApiException.notFound('Favorite');
        store.favorites.remove(id);
        return ok({'message': 'Removed from favorites.', 'id': id});
      },
    });

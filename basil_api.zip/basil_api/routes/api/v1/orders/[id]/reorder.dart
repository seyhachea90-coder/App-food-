import 'package:basil_api/basil_api.dart';
import 'package:dart_frog/dart_frog.dart';

/// POST /api/v1/orders/{id}/reorder — "Order again" → "Add 2 to new cart".
///
/// Starts a fresh cart with the order's items (promo codes are not carried
/// over). Body (all optional):
/// `{"keepNotes": true, "quantities": {"dish_burrata_salad": 2}}`
Future<Response> onRequest(RequestContext context, String id) => handle(context, {
      HttpMethod.post: () async {
        final user = context.user;
        final store = context.store;
        final order = store.ownedOrder(user, id);
        final body = await Body.parse(context);
        final keepNotes = body.boolean('keepNotes') ?? true;
        final quantities = body.object('quantities') ?? const <String, dynamic>{};
        quantities.forEach((dishId, q) {
          if (q is! int || q < 1 || q > 20) body.fail('quantities.$dishId', 'Must be 1–20.');
        });
        body.validate();

        if (order.status.isActive) {
          throw ApiException.conflict('ORDER_IN_PROGRESS', 'This order is still in progress.');
        }
        final restaurant = store.restaurant(order.restaurantId);
        if (!restaurant.isAcceptingOrders) {
          throw ApiException.conflict(
            'RESTAURANT_NOT_ACCEPTING_ORDERS',
            '${restaurant.name} has temporarily paused new orders.',
          );
        }

        final cart = store.cartOf(user.id)..clearItems();
        cart.restaurantId = restaurant.id;
        final skipped = <String>[];
        for (final item in order.items) {
          final dish = store.dishes[item.dishId];
          if (dish == null || !dish.isAvailable) {
            skipped.add(item.name);
            continue;
          }
          final size = dish.sizeById(item.size['id'] as String) ?? dish.sizes.first;
          final addOnIds = item.addOns
              .map((a) => a['id'] as String)
              .where((a) => dish.addOnById(a) != null)
              .toList()
            ..sort();
          cart.items.add(
            CartItem(
              id: newId('ci'),
              dishId: dish.id,
              sizeId: size.id,
              addOnIds: addOnIds,
              note: keepNotes ? item.note : null,
              quantity: (quantities[dish.id] as int?) ?? item.quantity,
            ),
          );
        }
        if (cart.items.isEmpty) {
          cart.clearItems();
          throw ApiException.conflict('ITEMS_UNAVAILABLE', 'None of these items are available any more.');
        }
        return created({
          ...CartService(store).toJson(cart),
          'skippedItems': skipped,
          'message': 'A new order, a fresh checkout.',
        });
      },
    });

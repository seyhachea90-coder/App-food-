import 'package:basil_api/basil_api.dart';
import 'package:basil_api/src/services/review_service.dart';
import 'package:dart_frog/dart_frog.dart';

/// GET /api/v1/restaurants/{id}/reviews?filter=all|five_stars|with_photos&sort=newest|highest|lowest
/// "Loved around here." To write one, use POST /api/v1/orders/{id}/reviews.
Future<Response> onRequest(RequestContext context, String id) => handle(context, {
      HttpMethod.get: () {
        final store = context.store;
        final r = store.restaurant(id);
        return reviewsResponse(
          context,
          reviews: store.reviews.where(
            (v) => v.restaurantId == r.id && (v.target == 'restaurant' || v.target == 'dish'),
          ),
          breakdown: r.ratingBreakdown,
          average: r.rating,
        );
      },
    });

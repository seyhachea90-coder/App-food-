import 'package:basil_api/basil_api.dart';
import 'package:basil_api/src/http/uploads.dart';
import 'package:dart_frog/dart_frog.dart';

/// /api/v1/me/avatar — Edit profile → Change photo (JPG or PNG · up to 5 MB).
/// Send `multipart/form-data` with the image in the `photo` field.
Future<Response> onRequest(RequestContext context) => handle(context, {
      HttpMethod.post: () async {
        final user = context.user;
        final store = context.store;
        final upload = await readImageUpload(context, ownerId: user.id, field: 'photo');
        if (user.avatarUploadId != null) store.uploads.remove(user.avatarUploadId);
        store.uploads[upload.id] = upload;
        user.avatarUploadId = upload.id;
        return ok(user.toJson());
      },
      HttpMethod.delete: () {
        final user = context.user;
        if (user.avatarUploadId != null) context.store.uploads.remove(user.avatarUploadId);
        user.avatarUploadId = null;
        return ok(user.toJson());
      },
    });

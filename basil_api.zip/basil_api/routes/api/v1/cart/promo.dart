import 'package:basil_api/basil_api.dart';
import 'package:dart_frog/dart_frog.dart';

/// /api/v1/cart/promo — "Promo code" screen. One code per order; applying a
/// new one replaces the current one.
Future<Response> onRequest(RequestContext context) => handle(context, {
      HttpMethod.put: () async {
        final user = context.user;
        final store = context.store;
        final carts = CartService(store);
        final body = await Body.parse(context);
        final code = body.string('code', required: true, max: 30)?.toUpperCase();
        body.validate();

        final cart = store.cartOf(user.id);
        if (cart.items.isEmpty) {
          throw ApiException.unprocessable('CART_EMPTY', 'Add something to your bag first.');
        }
        final coupon = store.coupons[code];
        if (coupon == null) {
          throw ApiException.unprocessable('PROMO_INVALID', 'That code isn’t valid. Check the spelling and try again.');
        }
        final check = checkCoupon(coupon, carts.restaurantOf(cart), carts.subtotal(cart));
        if (!check.eligible) {
          throw ApiException(
            422,
            'PROMO_NOT_ELIGIBLE',
            check.reason ?? 'This code can’t be used on this order.',
            details: {
              if (check.amountToUnlockCents > 0) 'amountToUnlockCents': '${check.amountToUnlockCents}',
            },
          );
        }
        cart.promoCode = coupon.code;
        return ok({
          ...carts.toJson(cart),
          'message': 'You saved ${formatCents(check.savingsCents)}. Nice choice!',
        });
      },
      HttpMethod.delete: () {
        final user = context.user;
        final cart = context.store.cartOf(user.id)..promoCode = null;
        return ok(CartService(context.store).toJson(cart));
      },
    });

import 'package:basil_api/basil_api.dart';
import 'package:dart_frog/dart_frog.dart';

/// GET /api/v1/restaurants — browse/filter restaurants.
/// Query: q, categoryId, sort, price, maxDeliveryMinutes, minRating, dietary,
/// freeDelivery, offers, lat, lng, page, limit.
Future<Response> onRequest(RequestContext context) => handle(context, {
      HttpMethod.get: () {
        final store = context.store;
        final catalog = CatalogService(store);
        final filters = RestaurantFilters.fromQuery(context);
        final page = Pagination.of(context);
        final (lat, lng) = catalog.origin(context);
        final user = context.userOrNull;
        final list = catalog.searchRestaurants(filters);
        return ok(
          page
              .slice(list)
              .map((r) => {
                    ...r.toSummaryJson(fromLat: lat, fromLng: lng),
                    if (user != null) 'isFavorite': store.isFavoriteRestaurant(user.id, r.id),
                  })
              .toList(),
          meta: page.meta(list.length),
        );
      },
    });

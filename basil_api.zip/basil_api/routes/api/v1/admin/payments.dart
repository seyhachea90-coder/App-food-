import 'package:basil_api/basil_api.dart';
import 'package:dart_frog/dart_frog.dart';

/// GET /api/v1/admin/payments?status=paid|refunded — payment ledger.
Future<Response> onRequest(RequestContext context) => handle(context, {
      HttpMethod.get: () {
        final store = context.store;
        final status = context.queryEnum('status', ['all', 'paid', 'refunded'], 'all');
        final page = Pagination.of(context);
        final list = store.orders.values
            .where((o) => status == 'all' || (status == 'refunded') == o.refunded)
            .toList()
          ..sort((a, b) => b.createdAt.compareTo(a.createdAt));
        final paid = list.where((o) => !o.refunded).fold(0, (s, o) => s + o.quote.totalCents);
        final refunded = list.where((o) => o.refunded).fold(0, (s, o) => s + o.quote.totalCents);
        return ok(
          page
              .slice(list)
              .map((o) => {
                    'orderId': o.id,
                    'orderNumber': o.number,
                    'customer': o.customerName,
                    'method': o.payment['label'],
                    'amountCents': o.quote.totalCents,
                    'status': o.refunded ? 'refunded' : 'paid',
                    'paidAt': iso(o.createdAt),
                  })
              .toList(),
          meta: {...page.meta(list.length), 'paidTotalCents': paid, 'refundedTotalCents': refunded},
        );
      },
    });

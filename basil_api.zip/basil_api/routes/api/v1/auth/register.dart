import 'package:basil_api/basil_api.dart';
import 'package:dart_frog/dart_frog.dart';

/// POST /api/v1/auth/register — "Your table’s ready." (Create account)
Future<Response> onRequest(RequestContext context) => handle(context, {
      HttpMethod.post: () async {
        final body = await Body.parse(context);
        final fullName = body.string('fullName', required: true, min: 2, max: 80);
        final email = body.email('email', required: true);
        final password = body.password('password');
        final accepted = body.boolean('acceptTerms', required: true);
        if (accepted == false) {
          body.fail('acceptTerms', 'Please agree to the Terms of Service and Privacy Policy.');
        }
        body.validate();

        final store = context.store;
        if (store.userByEmail(email!) != null) {
          throw ApiException.conflict(
            'EMAIL_TAKEN',
            'An account with this email already exists. Try signing in.',
          );
        }
        final user = User(
          id: newId('usr'),
          fullName: fullName!,
          email: email,
          passwordHash: hashPassword(password!),
        );
        store.users[user.id] = user;
        return created(issueSession(store, user));
      },
    });

import 'package:basil_api/basil_api.dart';
import 'package:basil_api/src/http/admin_input.dart';
import 'package:dart_frog/dart_frog.dart';

/// /api/v1/admin/dishes/{id} — edit (e.g. `{"isAvailable": false}` to 86 a dish) or delete.
Future<Response> onRequest(RequestContext context, String id) => handle(context, {
      HttpMethod.patch: () async {
        final store = context.store;
        final dish = store.dish(id);
        final r = store.restaurant(dish.restaurantId);
        applyDishInput(await Body.parse(context), dish, creating: false);
        if (!r.menuSections.contains(dish.section)) r.menuSections = [...r.menuSections, dish.section];
        return ok(dish.toDetailJson(r));
      },
      HttpMethod.delete: () {
        final store = context.store;
        final dish = store.dish(id);
        final inCarts = store.carts.values.any((c) => c.items.any((i) => i.dishId == dish.id));
        if (inCarts) {
          throw ApiException.conflict(
            'DISH_IN_CARTS',
            'Customers have this dish in their bags. Set isAvailable to false instead.',
          );
        }
        store.dishes.remove(dish.id);
        store.favorites.removeWhere((_, f) => f.dishId == dish.id);
        return ok({'message': 'Dish deleted.', 'id': dish.id});
      },
    });

import 'package:basil_api/basil_api.dart';
import 'package:dart_frog/dart_frog.dart';

/// GET /api/v1/dishes/{id} — "Food details" + the "Make it yours" steps
/// (sizes, add-ons, kitchen note).
Future<Response> onRequest(RequestContext context, String id) => handle(context, {
      HttpMethod.get: () {
        final store = context.store;
        final dish = store.dish(id);
        final user = context.userOrNull;
        return ok({
          ...dish.toDetailJson(store.restaurant(dish.restaurantId)),
          if (user != null)
            'isFavorite': store.favoritesOf(user.id).any((f) => f.dishId == dish.id),
        });
      },
    });

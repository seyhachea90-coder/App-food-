import 'package:basil_api/basil_api.dart';
import 'package:dart_frog/dart_frog.dart';

const _topics = [
  {'id': 'orders_delivery', 'title': 'Orders & delivery', 'subtitle': 'Tracking, items & issues'},
  {'id': 'payments', 'title': 'Payments', 'subtitle': 'Charges, receipts & refunds'},
  {'id': 'account', 'title': 'Your account', 'subtitle': 'Profile, access & privacy'},
  {'id': 'offers_credits', 'title': 'Offers & credits', 'subtitle': 'Promo codes & savings'},
];

/// GET /api/v1/help — "We’re here to help." Topics, quick answers and (for
/// signed-in users) the latest order card.
Future<Response> onRequest(RequestContext context) => handle(context, {
      HttpMethod.get: () {
        final store = context.store;
        final user = context.userOrNull;
        final latest = user == null ? null : store.ordersOf(user.id).firstOrNull;
        return ok({
          'recentOrder': latest == null ? null : OrderService(store).summaryJson(latest),
          'topics': _topics,
          'quickAnswers': store.faqs.take(2).map((f) => f.toJson()).toList(),
        });
      },
    });

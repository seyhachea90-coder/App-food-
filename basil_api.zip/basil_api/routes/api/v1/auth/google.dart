import 'package:basil_api/basil_api.dart';
import 'package:dart_frog/dart_frog.dart';

/// POST /api/v1/auth/google — "Continue with Google".
///
/// Development mock: send `idToken` as `dev:<email>:<Full Name>`.
/// For production, verify the Google ID token (audience = your OAuth client
/// id) and read the email/name from its claims instead.
Future<Response> onRequest(RequestContext context) => handle(context, {
      HttpMethod.post: () async {
        final body = await Body.parse(context);
        final idToken = body.string('idToken', required: true);
        body.validate();

        if (Config.isProduction) {
          throw ApiException(501, 'NOT_CONFIGURED', 'Google sign-in is not configured on this server.');
        }
        final parts = idToken!.split(':');
        final emailOk = parts.length >= 3 &&
            parts[0] == 'dev' &&
            RegExp(r'^[^\s@]+@[^\s@]+\.[^\s@]+$').hasMatch(parts[1]);
        if (!emailOk) {
          throw ApiException(
            401,
            'INVALID_GOOGLE_TOKEN',
            'Google token is invalid. In development use "dev:<email>:<Full Name>".',
          );
        }
        final email = parts[1].toLowerCase();
        final name = parts.sublist(2).join(':').trim();

        final store = context.store;
        var user = store.userByEmail(email);
        final isNew = user == null;
        if (user == null) {
          user = User(
            id: newId('usr'),
            fullName: name.isEmpty ? email.split('@').first : name,
            email: email,
            // Random password: the account can only sign in with Google until
            // the user resets their password.
            passwordHash: hashPassword(randomToken()),
            emailVerified: true,
            authProvider: 'google',
          );
          store.users[user.id] = user;
        }
        return ok(
          {...issueSession(store, user), 'isNewUser': isNew},
          status: isNew ? 201 : 200,
        );
      },
    });

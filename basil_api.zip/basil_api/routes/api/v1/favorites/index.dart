import 'package:basil_api/basil_api.dart';
import 'package:dart_frog/dart_frog.dart';

/// /api/v1/favorites — "Your good-food list." / "Keep a good thing."
Future<Response> onRequest(RequestContext context) => handle(context, {
      HttpMethod.get: () {
        final user = context.user;
        final store = context.store;
        final carts = CartService(store);
        final type = context.queryEnum('type', ['all', 'restaurants', 'dishes'], 'all');
        final all = store.favoritesOf(user.id);
        final restaurants = all.where((f) => f.type == 'restaurant').toList();
        final dishes = all.where((f) => f.type == 'dish').toList();

        Map<String, dynamic> dishFavorite(Favorite f) {
          final dish = store.dishes[f.dishId]!;
          final restaurant = store.restaurant(dish.restaurantId);
          final line = carts.resolve(
            CartItem(
              id: f.id,
              dishId: dish.id,
              sizeId: f.sizeId ?? dish.sizes.first.id,
              addOnIds: f.addOnIds,
              quantity: 1,
              note: f.note,
            ),
          );
          return {
            'id': f.id,
            'type': 'dish',
            'dish': dish.toSummaryJson(restaurant),
            'customization': f.hasCustomization
                ? {
                    'size': line.size.toJson(),
                    'addOns': line.addOns.map((a) => a.toJson()).toList(),
                    'note': f.note,
                    'unitPriceCents': line.unitPriceCents,
                    'summary': [line.size.name, ...line.addOns.map((a) => a.name)].join(' · '),
                  }
                : null,
            'createdAt': iso(f.createdAt),
          };
        }

        return ok({
          'counts': {'all': all.length, 'restaurants': restaurants.length, 'dishes': dishes.length},
          'restaurants': type == 'dishes'
              ? <Object>[]
              : restaurants
                  .where((f) => store.restaurants.containsKey(f.restaurantId))
                  .map((f) => {
                        'id': f.id,
                        'type': 'restaurant',
                        'restaurant': store.restaurants[f.restaurantId]!.toSummaryJson(),
                        'createdAt': iso(f.createdAt),
                      })
                  .toList(),
          'dishes': type == 'restaurants'
              ? <Object>[]
              : dishes.where((f) => store.dishes.containsKey(f.dishId)).map(dishFavorite).toList(),
        });
      },

      // Save a restaurant, or a dish (optionally with its customization).
      // `alsoSaveRestaurant: true` = "Save the restaurant, too."
      HttpMethod.post: () async {
        final user = context.user;
        final store = context.store;
        final body = await Body.parse(context);
        final type = body.string('type', required: true, oneOf: ['restaurant', 'dish']);
        final restaurantId = body.string('restaurantId', required: type == 'restaurant');
        final dishId = body.string('dishId', required: type == 'dish');
        final customization = body.object('customization');
        final alsoSaveRestaurant = body.boolean('alsoSaveRestaurant') ?? false;
        body.validate();

        final created = <Favorite>[];
        final now = DateTime.now().toUtc();
        Favorite? saveRestaurant(String id, {required bool failIfExists}) {
          store.restaurant(id);
          if (store.isFavoriteRestaurant(user.id, id)) {
            if (failIfExists) {
              throw ApiException.conflict('ALREADY_FAVORITE', 'This restaurant is already in your favorites.');
            }
            return null;
          }
          final f = Favorite(id: newId('fav'), userId: user.id, type: 'restaurant', restaurantId: id, createdAt: now);
          store.favorites[f.id] = f;
          return f;
        }

        if (type == 'restaurant') {
          created.add(saveRestaurant(restaurantId!, failIfExists: true)!);
        } else {
          final dish = store.dish(dishId!);
          String? sizeId;
          var addOnIds = <String>[];
          String? note;
          if (customization != null) {
            final c = Body.fromMap(customization);
            sizeId = c.string('sizeId');
            addOnIds = c.strings('addOnIds', maxItems: 10) ?? <String>[];
            note = c.string('note', max: 200);
            final (size, addOns) = CartService(store).validateSelection(c, dish, sizeId: sizeId, addOnIds: addOnIds);
            c.validate();
            sizeId = size!.id;
            addOnIds = addOns.map((a) => a.id).toList()..sort();
          }
          final duplicate = store.favoritesOf(user.id).any(
                (f) =>
                    f.dishId == dish.id &&
                    f.sizeId == sizeId &&
                    f.note == note &&
                    ([...f.addOnIds]..sort()).join(',') == addOnIds.join(','),
              );
          if (duplicate) {
            throw ApiException.conflict('ALREADY_FAVORITE', 'This dish is already in your favorites.');
          }
          final f = Favorite(
            id: newId('fav'),
            userId: user.id,
            type: 'dish',
            restaurantId: dish.restaurantId,
            dishId: dish.id,
            sizeId: sizeId,
            addOnIds: addOnIds,
            note: note,
            createdAt: now,
          );
          store.favorites[f.id] = f;
          created.add(f);
          if (alsoSaveRestaurant) {
            final r = saveRestaurant(dish.restaurantId, failIfExists: false);
            if (r != null) created.add(r);
          }
        }
        return ok(
          {
            'message': 'Added to your favorites',
            'created': created
                .map((f) => {'id': f.id, 'type': f.type, 'restaurantId': f.restaurantId, 'dishId': f.dishId})
                .toList(),
          },
          status: 201,
        );
      },
    });

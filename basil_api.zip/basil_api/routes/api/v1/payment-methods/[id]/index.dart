import 'package:basil_api/basil_api.dart';
import 'package:dart_frog/dart_frog.dart';

/// /api/v1/payment-methods/{id} — "Manage card" / "Remove".
Future<Response> onRequest(RequestContext context, String id) => handle(context, {
      HttpMethod.get: () => ok(context.store.ownedPaymentMethod(context.user, id).toJson()),
      HttpMethod.patch: () async {
        final method = context.store.ownedPaymentMethod(context.user, id);
        if (method.type != 'card') {
          throw ApiException.unprocessable('NOT_A_CARD', 'Only cards can be edited.');
        }
        final body = await Body.parse(context);
        final expMonth = body.integer('expMonth', min: 1, max: 12);
        final expYear = body.integer('expYear', min: 2000, max: 2100);
        final holderName = body.string('holderName', min: 2, max: 80);
        final month = expMonth ?? method.expMonth!;
        final year = expYear ?? method.expYear!;
        final now = DateTime.now();
        if (year < now.year || (year == now.year && month < now.month)) {
          body.fail('expYear', 'This expiry date is in the past.');
        }
        body.validate();
        method
          ..expMonth = month
          ..expYear = year;
        if (holderName != null) method.holderName = holderName;
        return ok(method.toJson());
      },
      HttpMethod.delete: () {
        final user = context.user;
        final store = context.store;
        final method = store.ownedPaymentMethod(user, id);
        store.paymentMethods.remove(method.id);
        final rest = store.paymentMethodsOf(user.id);
        if (method.isDefault && rest.isNotEmpty) rest.first.isDefault = true;
        final cart = store.cartOf(user.id);
        if (cart.paymentMethodId == method.id) cart.paymentMethodId = null;
        return ok({'message': 'Payment method removed.', 'id': method.id});
      },
    });

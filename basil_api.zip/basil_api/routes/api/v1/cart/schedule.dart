import 'package:basil_api/basil_api.dart';
import 'package:dart_frog/dart_frog.dart';

/// PUT /api/v1/cart/schedule — "Save delivery time".
/// `{"type": "asap"}` or `{"type": "scheduled", "date": "2026-11-09", "windowStart": "12:30"}`
/// (pick from GET /api/v1/cart/delivery-slots).
Future<Response> onRequest(RequestContext context) => handle(context, {
      HttpMethod.put: () async {
        final user = context.user;
        final store = context.store;
        final body = await Body.parse(context);
        final type = body.string('type', required: true, oneOf: ['asap', 'scheduled']);
        final date = body.string('date', required: type == 'scheduled');
        final windowStart = body.string('windowStart', required: type == 'scheduled');
        body.validate();

        final cart = store.cartOf(user.id);
        if (type == 'asap') {
          cart.schedule = const DeliverySchedule.asap();
        } else {
          final restaurant = cart.restaurantId == null ? null : store.restaurants[cart.restaurantId];
          if (restaurant == null) {
            throw ApiException.unprocessable('CART_EMPTY', 'Add something to your bag first.');
          }
          final days = OrderService(store).deliverySlots(restaurant);
          final day = days.where((d) => d['date'] == date).firstOrNull;
          final window = (day?['windows'] as List<Map<String, dynamic>>?)
              ?.where((w) => w['start'] == windowStart)
              .firstOrNull;
          if (window == null) {
            throw ApiException.validation({
              'windowStart': 'That window is not available. Choose one from /cart/delivery-slots.',
            });
          }
          cart.schedule = DeliverySchedule.scheduled(
            date: date!,
            windowStart: windowStart!,
            windowEnd: window['end'] as String,
          );
        }
        return ok(CartService(store).toJson(cart));
      },
    });

import 'package:basil_api/basil_api.dart';
import 'package:basil_api/src/http/admin_input.dart';
import 'package:dart_frog/dart_frog.dart';

/// /api/v1/admin/dishes — Menu management (list by restaurant, create).
Future<Response> onRequest(RequestContext context) => handle(context, {
      HttpMethod.get: () {
        final store = context.store;
        final restaurantId = context.queryString('restaurantId');
        final list = store.dishes.values.where((d) => restaurantId == null || d.restaurantId == restaurantId).toList()
          ..sort((a, b) => a.name.compareTo(b.name));
        return ok(
          list.map((d) => d.toDetailJson(store.restaurant(d.restaurantId))).toList(),
          meta: {'total': list.length},
        );
      },
      HttpMethod.post: () async {
        final store = context.store;
        final body = await Body.parse(context);
        final restaurantId = body.string('restaurantId', required: true);
        body.validate();
        final r = store.restaurant(restaurantId!);
        final dish = Dish(
          id: newId('dish'),
          restaurantId: r.id,
          name: '',
          description: '',
          priceCents: 0,
          section: '',
          imageUrl: 'https://placehold.co/600x400?text=Dish',
          sizes: [DishOption(id: 'regular', name: 'Regular', priceDeltaCents: 0)],
        );
        applyDishInput(body, dish, creating: true);
        if (!r.menuSections.contains(dish.section)) r.menuSections = [...r.menuSections, dish.section];
        store.dishes[dish.id] = dish;
        return created(dish.toDetailJson(r));
      },
    });

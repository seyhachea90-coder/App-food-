import 'package:basil_api/basil_api.dart';
import 'package:dart_frog/dart_frog.dart';

/// POST /api/v1/notifications/{id}/read — mark one notification as read.
Future<Response> onRequest(RequestContext context, String id) => handle(context, {
      HttpMethod.post: () {
        final user = context.user;
        final n = context.store.notifications.where((n) => n.id == id && n.userId == user.id).firstOrNull ??
            (throw ApiException.notFound('Notification'));
        n.readAt ??= DateTime.now().toUtc();
        return ok(n.toJson());
      },
    });

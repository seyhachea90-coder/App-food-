import 'package:basil_api/basil_api.dart';
import 'package:dart_frog/dart_frog.dart';

const _quickReplies = ['Thank you!', 'I’m at home', 'Please call when you arrive'];

/// /api/v1/orders/{id}/messages — "Contact courier" chat.
/// Available once a courier is assigned and until the order is delivered.
Future<Response> onRequest(RequestContext context, String id) => handle(context, {
      HttpMethod.get: () {
        final store = context.store;
        final order = store.ownedOrder(context.user, id);
        final messages = store.messages.where((m) => m.orderId == order.id).toList()
          ..sort((a, b) => a.sentAt.compareTo(b.sentAt));
        // Opening the chat marks courier messages as read.
        for (final m in messages.where((m) => m.sender == 'courier')) {
          m.read = true;
        }
        return ok({
          'courier': store.couriers[order.courierId]?.toJson(),
          'canSend': order.courierId != null && order.status.isActive,
          'quickReplies': _quickReplies,
          'privacyNote': 'Your number stays private. Messages are only for this delivery.',
          'messages': messages.map((m) => m.toJson()).toList(),
        });
      },
      HttpMethod.post: () async {
        final store = context.store;
        final order = store.ownedOrder(context.user, id);
        final body = await Body.parse(context);
        final text = body.string('text', required: true, max: 500);
        body.validate();

        if (order.courierId == null) {
          throw ApiException.conflict('NO_COURIER_YET', 'We’ll let you know when your courier is assigned.');
        }
        if (!order.status.isActive) {
          throw ApiException.conflict('ORDER_CLOSED', 'This delivery is complete. Contact support for help.');
        }
        final message = ChatMessage(
          id: newId('msg'),
          orderId: order.id,
          sender: 'customer',
          text: text!,
          sentAt: DateTime.now().toUtc(),
        );
        store.messages.add(message);
        return created(message.toJson());
      },
    });

import 'package:basil_api/basil_api.dart';
import 'package:dart_frog/dart_frog.dart';

/// PATCH /api/v1/admin/orders/{id}/status — move an order along:
/// confirmed → preparing → on_the_way → delivered (or cancelled at any point).
///
/// This is also how you drive the customer tracking screens while testing.
Future<Response> onRequest(RequestContext context, String id) => handle(context, {
      HttpMethod.patch: () async {
        final store = context.store;
        final order = store.orderByIdOrNumber(id) ?? (throw ApiException.notFound('Order'));
        final body = await Body.parse(context);
        final status = body.string(
          'status',
          required: true,
          oneOf: OrderStatus.values.map((s) => s.value).toList(),
        );
        final reason = body.string('reason', max: 250);
        body.validate();

        final service = OrderService(store)..setStatus(order, OrderStatus.parse(status)!, reason: reason);
        return ok(service.detailJson(order));
      },
    });

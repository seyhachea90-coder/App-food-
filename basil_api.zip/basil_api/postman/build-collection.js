#!/usr/bin/env node
/*
 * Generates the Basil API Postman collection + local environment.
 *
 *   node postman/build-collection.js
 *
 * Folders follow the app's user journey (sign in → discover → cart →
 * checkout → order tracking → reviews → account) so "Run collection" works
 * top to bottom against a freshly started server.
 */
const fs = require('fs');
const path = require('path');

const json = (o) => JSON.stringify(o, null, 2);

// ---------- test-script snippets ----------
const expectStatus = (code) =>
  `pm.test("Status is ${code}", () => pm.response.to.have.status(${code}));`;
const expectError = (code, errCode) =>
  `${expectStatus(code)}
pm.test("Error code is ${errCode}", () => pm.expect(pm.response.json().error.code).to.eql("${errCode}"));`;
const save = (variable, expr) => `pm.environment.set("${variable}", ${expr});`;
const data = 'const res = pm.response.json().data;';

// ---------- request builder ----------
/**
 * @param {string} name
 * @param {string} method
 * @param {string} p        path after {{baseUrl}}, may contain ?query
 * @param {object} o        { body, desc, tests:[], auth:'user'|'admin'|'none'|'temp', form, pre }
 */
function req(name, method, p, o = {}) {
  const [pathPart, queryPart] = p.split('?');
  const query = queryPart
    ? queryPart.split('&').map((kv) => {
        const [key, ...rest] = kv.split('=');
        return { key, value: rest.join('=') };
      })
    : undefined;
  const request = {
    method,
    header: [],
    url: {
      raw: `{{baseUrl}}${p}`,
      host: ['{{baseUrl}}'],
      path: pathPart.split('/').filter(Boolean),
      ...(query ? { query } : {}),
    },
    description: o.desc || '',
  };
  if (o.body !== undefined) {
    request.header.push({ key: 'Content-Type', value: 'application/json' });
    request.body = {
      mode: 'raw',
      raw: typeof o.body === 'string' ? o.body : json(o.body),
      options: { raw: { language: 'json' } },
    };
  }
  if (o.form) {
    request.body = { mode: 'formdata', formdata: o.form };
  }
  const auth = o.auth || 'user';
  if (auth === 'none') request.auth = { type: 'noauth' };
  if (auth === 'admin' || auth === 'temp') {
    request.auth = {
      type: 'bearer',
      bearer: [{ key: 'token', value: auth === 'admin' ? '{{adminToken}}' : '{{tempToken}}', type: 'string' }],
    };
  }
  const event = [];
  if (o.pre) event.push({ listen: 'prerequest', script: { type: 'text/javascript', exec: o.pre.split('\n') } });
  if (o.tests && o.tests.length) {
    event.push({ listen: 'test', script: { type: 'text/javascript', exec: o.tests.join('\n').split('\n') } });
  }
  return { name, ...(event.length ? { event } : {}), request };
}

const folder = (name, description, item) => ({ name, description, item });

// =====================================================================
const items = [
  folder('00 · Health & App', 'Service checks and app-wide configuration (Splash, Settings → About).', [
    req('Health check', 'GET', '/health', {
      auth: 'none',
      desc: 'Returns `status: ok` when the server is up.',
      tests: [expectStatus(200), `pm.test("Server is ok", () => pm.expect(pm.response.json().data.status).to.eql("ok"));`],
    }),
    req('App config', 'GET', '/app/config', {
      auth: 'none',
      desc: 'Legal links, supported languages/appearances, password rule and upload limits.',
      tests: [expectStatus(200)],
    }),
  ]),

  // ------------------------------------------------------------------
  folder(
    '01 · Auth',
    'Screens: **Splash, Login, Sign up ("Your table’s ready."), Forgot password, Reset password ("A fresh start.")**.\n\n' +
      '`Login (customer)` stores `accessToken` + `refreshToken` in the environment; every other request uses them automatically ' +
      '(collection-level Bearer auth). `Login (admin)` stores `adminToken` for the Admin folder.',
    [
      req('Login (customer)', 'POST', '/auth/login', {
        auth: 'none',
        body: { email: '{{email}}', password: '{{password}}' },
        desc: 'Sign in. Demo customer: `dara@example.com` / `Basil1234`.\n\nSaves `accessToken` and `refreshToken`.',
        tests: [
          expectStatus(200),
          data,
          save('accessToken', 'res.accessToken'),
          save('refreshToken', 'res.refreshToken'),
          `pm.test("Returns the user", () => pm.expect(res.user.email).to.eql(pm.environment.get("email")));`,
        ],
      }),
      req('Login (admin)', 'POST', '/auth/login', {
        auth: 'none',
        body: { email: '{{adminEmail}}', password: '{{adminPassword}}' },
        desc: 'Sign in as the admin used by the dashboard endpoints. Saves `adminToken`.',
        tests: [expectStatus(200), data, save('adminToken', 'res.accessToken')],
      }),
      req('Login – wrong password (401)', 'POST', '/auth/login', {
        auth: 'none',
        body: { email: '{{email}}', password: 'not-my-password1' },
        desc: 'Error example: wrong email or password.',
        tests: [expectError(401, 'INVALID_CREDENTIALS')],
      }),
      req('Register', 'POST', '/auth/register', {
        auth: 'none',
        pre: `pm.environment.set("tempEmail", "new.user." + Date.now() + "@example.com");`,
        body: { fullName: 'Sreyneang Phan', email: '{{tempEmail}}', password: 'Welcome123', acceptTerms: true },
        desc:
          'Create account. Rules: full name 2–80 chars, valid email, password 8+ characters including a number, ' +
          '`acceptTerms` must be true.\n\nA unique email is generated in the pre-request script. Saves `tempToken` ' +
          '(used later by "Delete account" so the demo user is never deleted).',
        tests: [expectStatus(201), data, save('tempToken', 'res.accessToken')],
      }),
      req('Register – validation errors (422)', 'POST', '/auth/register', {
        auth: 'none',
        body: { fullName: 'J', email: 'not-an-email', password: 'short', acceptTerms: false },
        desc: 'Error example: every invalid field is listed in `error.details` so the app can show them under each input.',
        tests: [
          expectError(422, 'VALIDATION_ERROR'),
          `pm.test("Lists each field", () => pm.expect(pm.response.json().error.details).to.have.keys("fullName","email","password","acceptTerms"));`,
        ],
      }),
      req('Register – email taken (409)', 'POST', '/auth/register', {
        auth: 'none',
        body: { fullName: 'Dara Again', email: '{{email}}', password: 'Basil12345', acceptTerms: true },
        tests: [expectError(409, 'EMAIL_TAKEN')],
      }),
      req('Continue with Google', 'POST', '/auth/google', {
        auth: 'none',
        body: { idToken: 'dev:google.user@example.com:Bopha Nhem' },
        desc:
          'Development mock: send `idToken` as `dev:<email>:<Full Name>`. Creates the account on first use (201, `isNewUser: true`) ' +
          'and signs in afterwards (200).\n\nIn production the server must verify the real Google ID token.',
        tests: [`pm.test("Status is 200 or 201", () => pm.expect(pm.response.code).to.be.oneOf([200, 201]));`],
      }),
      req('Refresh token', 'POST', '/auth/refresh', {
        auth: 'none',
        body: { refreshToken: '{{refreshToken}}' },
        desc: 'Exchange the refresh token for a new pair (the old refresh token stops working). Access tokens last 1 hour.',
        tests: [expectStatus(200), data, save('accessToken', 'res.accessToken'), save('refreshToken', 'res.refreshToken')],
      }),
      req('Forgot password', 'POST', '/auth/forgot-password', {
        auth: 'none',
        body: { email: '{{email}}' },
        desc:
          '"Send reset link". Always returns the same message (does not reveal whether the email exists).\n\n' +
          'No email service yet: outside production the response includes `devResetToken`, saved here as `resetToken`.',
        tests: [expectStatus(200), data, save('resetToken', 'res.devResetToken || ""')],
      }),
      req('Reset password', 'POST', '/auth/reset-password', {
        auth: 'none',
        body: { token: '{{resetToken}}', newPassword: '{{password}}', confirmPassword: '{{password}}' },
        desc: 'Sets a new password and signs out all devices. Here it resets to the same demo password so the rest of the collection keeps working.',
        tests: [expectStatus(200)],
      }),
      req('Login again after reset', 'POST', '/auth/login', {
        auth: 'none',
        body: { email: '{{email}}', password: '{{password}}' },
        tests: [expectStatus(200), data, save('accessToken', 'res.accessToken'), save('refreshToken', 'res.refreshToken')],
      }),
    ],
  ),

  // ------------------------------------------------------------------
  folder('02 · Profile & Settings', 'Screens: **Your account, Edit profile, Settings**.', [
    req('Get my profile', 'GET', '/me', {
      desc: 'Profile plus counts for the account menu (favorites, saved addresses, cards, unread notifications).',
      tests: [expectStatus(200)],
    }),
    req('Edit profile', 'PATCH', '/me', {
      body: { fullName: 'Dara Sok', phone: '+1 (718) 555-0100' },
      desc: 'Any of `fullName`, `email`, `phone` (send `null` to remove the phone). Changing the email sets `emailVerified` to false.',
      tests: [expectStatus(200)],
    }),
    req('Upload profile photo', 'POST', '/me/avatar', {
      form: [{ key: 'photo', type: 'file', src: 'sample-photo.png' }],
      desc:
        '"Change photo" — `multipart/form-data`, field `photo`, JPG or PNG up to 5 MB.\n\n' +
        'In the Postman app set **Settings → General → Working directory** to the `postman` folder, or pick any image in the Body tab.',
      tests: [expectStatus(200)],
    }),
    req('Remove profile photo', 'DELETE', '/me/avatar', { tests: [expectStatus(200)] }),
    req('Change password', 'PUT', '/me/password', {
      body: { currentPassword: '{{password}}', newPassword: '{{password}}9', confirmPassword: '{{password}}9' },
      desc: 'Signs out other devices and returns a fresh token pair (saved).',
      tests: [expectStatus(200), data, save('accessToken', 'res.accessToken'), save('refreshToken', 'res.refreshToken')],
    }),
    req('Change password back', 'PUT', '/me/password', {
      body: { currentPassword: '{{password}}9', newPassword: '{{password}}', confirmPassword: '{{password}}' },
      desc: 'Restores the demo password.',
      tests: [expectStatus(200), data, save('accessToken', 'res.accessToken'), save('refreshToken', 'res.refreshToken')],
    }),
    req('Get settings', 'GET', '/me/settings', { tests: [expectStatus(200)] }),
    req('Update settings', 'PATCH', '/me/settings', {
      body: {
        notifications: { orderUpdates: true, offersAndRecommendations: false, emailReceipts: true },
        language: 'en',
        appearance: 'light',
        locationAccess: 'while_using',
      },
      desc: '`language`: en|es|fr|km · `appearance`: light|dark|system · `locationAccess`: while_using|always|never.',
      tests: [expectStatus(200)],
    }),
  ]),

  // ------------------------------------------------------------------
  folder(
    '03 · Location & Addresses',
    'Screens: **Find your neighborhood, Delivery address ("Where to, hungry?"), Add address, Saved addresses**.',
    [
      req('Use my current location', 'GET', '/places/reverse?lat=40.7196&lng=-73.9566', {
        auth: 'none',
        desc: 'Nearest address to the device location. Backed by a built-in list of Brooklyn addresses (replace with a real geocoder later).',
        tests: [expectStatus(200)],
      }),
      req('Search for an address', 'GET', '/places/search?q=bedford', {
        auth: 'none',
        desc: 'Address autocomplete (min 2 characters).',
        tests: [expectStatus(200)],
      }),
      req('List saved addresses', 'GET', '/addresses', { desc: 'Default address first.', tests: [expectStatus(200)] }),
      req('Add address', 'POST', '/addresses', {
        body: {
          label: 'other',
          customLabel: 'Gym',
          street: '68 Jay Street',
          apt: 'Floor 3',
          city: 'Brooklyn',
          state: 'NY',
          zip: '11201',
          instructions: 'Leave with the front desk.',
          dropoff: 'hand_to_me',
          lat: 40.7025,
          lng: -73.9866,
          isDefault: false,
        },
        desc:
          '`label`: home | work | other (`customLabel` optional). `dropoff`: hand_to_me | leave_at_door. ' +
          '`state` is the 2-letter code, `zip` 5 digits. Saves `addressId`.',
        tests: [expectStatus(201), data, save('addressId', 'res.id')],
      }),
      req('Get address', 'GET', '/addresses/{{addressId}}', { tests: [expectStatus(200)] }),
      req('Edit address', 'PATCH', '/addresses/{{addressId}}', {
        body: { apt: 'Floor 4', instructions: 'Ring the bell twice.' },
        desc: 'Send only the fields that change. Optional text fields can be cleared with `null`.',
        tests: [expectStatus(200)],
      }),
      req('Set as default', 'POST', '/addresses/{{addressId}}/default', { tests: [expectStatus(200)] }),
      req('Set Home back as default', 'POST', '/addresses/addr_home/default', { tests: [expectStatus(200)] }),
      req('Add address – invalid (422)', 'POST', '/addresses', {
        body: { label: 'cabin', street: '', city: 'Brooklyn', state: 'New York', zip: 'abc' },
        tests: [expectError(422, 'VALIDATION_ERROR')],
      }),
      req('Remove address', 'DELETE', '/addresses/{{addressId}}', { tests: [expectStatus(200)] }),
    ],
  ),

  // ------------------------------------------------------------------
  folder(
    '04 · Discover & Search',
    'Screens: **Home, Categories ("Follow your craving."), Search, Search results, Filters, No results**.\n\n' +
      'These work without signing in; with a token the response is personalised (name, address, favorites, recent searches, distances).',
    [
      req('Home', 'GET', '/home', {
        desc: 'Greeting, delivery address, 4 categories, popular restaurants and recommended dishes.',
        tests: [expectStatus(200)],
      }),
      req('Categories', 'GET', '/categories', { desc: 'All categories with `placeCount`.', tests: [expectStatus(200)] }),
      req('Search suggestions', 'GET', '/search/suggestions', {
        desc: 'Recent searches (signed-in), trending nearby and the "A pasta kind of day." card.',
        tests: [expectStatus(200)],
      }),
      req('Filter options', 'GET', '/search/filters', {
        auth: 'none',
        desc: 'Everything the Filters sheet needs: sort options, price, delivery time, rating, dietary, toggles — with the query parameter for each.',
        tests: [expectStatus(200)],
      }),
      req('Search "pizza"', 'GET', '/search?q=pizza&type=all&page=1&limit=20', {
        desc:
          'Restaurants + dishes tabs with totals. `type`: all | restaurants | dishes.\n\nAccepts every filter: ' +
          '`sort`, `price` (1–4, comma separated), `maxDeliveryMinutes`, `minRating`, `dietary`, `freeDelivery`, `offers`, `categoryId`, `lat`, `lng`.',
        tests: [expectStatus(200), `pm.test("Finds restaurants", () => pm.expect(pm.response.json().data.restaurants.total).to.be.above(0));`],
      }),
      req('Search with filters', 'GET', '/search?q=pizza&sort=top_rated&minRating=4.5&maxDeliveryMinutes=30&price=1,2', {
        desc: '"Show N restaurants": read `data.restaurants.total`.',
        tests: [expectStatus(200)],
      }),
      req('Search – no results', 'GET', '/search?q=Truffle ramen&maxDeliveryMinutes=30&freeDelivery=true', {
        desc: '"No bites just yet." — `emptyState` carries the title, message and suggested searches.',
        tests: [expectStatus(200), `pm.test("Has empty state", () => pm.expect(pm.response.json().data.emptyState).to.not.be.null);`],
      }),
      req('Clear recent searches', 'DELETE', '/search/recent', { desc: '"Clear all".', tests: [expectStatus(200)] }),
    ],
  ),

  // ------------------------------------------------------------------
  folder(
    '05 · Restaurants & Menu',
    'Screens: **Restaurant, Restaurant info, Menu, Reviews ("Loved around here."), Not accepting orders**.',
    [
      req('List restaurants', 'GET', '/restaurants?sort=recommended&page=1&limit=20', {
        desc: 'Same filters as search. Browse a category with `categoryId=cat_pizza`.',
        tests: [expectStatus(200)],
      }),
      req('Restaurants in a category', 'GET', '/restaurants?categoryId=cat_italian', { tests: [expectStatus(200)] }),
      req('Restaurant details', 'GET', '/restaurants/{{restaurantId}}', {
        desc:
          'Overview + info: rating, delivery time/fee, distance, address, phone, opening hours, `status` and featured dishes.\n\n' +
          'When the kitchen has paused orders `status.code` is `paused` and `alternatives` lists similar places.',
        tests: [expectStatus(200)],
      }),
      req('Menu', 'GET', '/restaurants/{{restaurantId}}/menu', {
        desc: 'Sections in menu order (Popular = "The local favorites").',
        tests: [expectStatus(200)],
      }),
      req('Search the menu', 'GET', '/restaurants/{{restaurantId}}/menu?q=burrata', {
        desc: '"Search Little Napoli’s menu".',
        tests: [expectStatus(200)],
      }),
      req('Reviews', 'GET', '/restaurants/{{restaurantId}}/reviews?filter=all&sort=newest&page=1&limit=10', {
        desc: '`filter`: all | five_stars | with_photos · `sort`: newest | highest | lowest. Includes the rating summary and star breakdown.',
        tests: [expectStatus(200)],
      }),
      req('Restaurant not found (404)', 'GET', '/restaurants/rest_does_not_exist', { tests: [expectError(404, 'NOT_FOUND')] }),
    ],
  ),

  // ------------------------------------------------------------------
  folder('06 · Dishes', 'Screens: **Food details, Add-ons, Choose your size, Special instructions**.', [
    req('Dish details', 'GET', '/dishes/{{dishId}}', {
      desc:
        'Everything for the "Make it yours" steps: `options.size` (required, one), `options.addOns` (optional, many), ' +
        '`options.kitchenNote` (max 200) and `options.quantity` (1–20). Prices are in cents.',
      tests: [expectStatus(200)],
    }),
    req('Dish reviews', 'GET', '/dishes/{{dishId}}/reviews', { tests: [expectStatus(200)] }),
  ]),

  // ------------------------------------------------------------------
  folder('07 · Favorites', 'Screens: **Favorites ("Your good-food list."), Add to favorites ("Keep a good thing.")**.', [
    req('List favorites', 'GET', '/favorites?type=all', { desc: '`type`: all | restaurants | dishes.', tests: [expectStatus(200)] }),
    req('Save a restaurant', 'POST', '/favorites', {
      body: { type: 'restaurant', restaurantId: 'rest_lolivo' },
      desc: 'Saves `favoriteId`.',
      tests: [expectStatus(201), data, save('favoriteId', 'res.created[0].id')],
    }),
    req('Save a dish with my customizations', 'POST', '/favorites', {
      body: {
        type: 'dish',
        dishId: 'dish_burrata_margherita',
        customization: { sizeId: 'large', addOnIds: ['extra_burrata'], note: 'Well done, please.' },
        alsoSaveRestaurant: true,
      },
      desc: '`customization` is optional. `alsoSaveRestaurant` = "Save the restaurant, too."',
      tests: [expectStatus(201)],
    }),
    req('Save again – already a favorite (409)', 'POST', '/favorites', {
      body: { type: 'restaurant', restaurantId: 'rest_lolivo' },
      tests: [expectError(409, 'ALREADY_FAVORITE')],
    }),
    req('Remove favorite (Undo)', 'DELETE', '/favorites/{{favoriteId}}', { tests: [expectStatus(200)] }),
  ]),

  // ------------------------------------------------------------------
  folder(
    '08 · Payment Methods',
    'Screens: **Payment management, Payment methods**.\n\n' +
      'Never send raw card numbers to this API. Collect cards with your payment provider SDK and send its token. ' +
      'Test tokens: `tok_visa`, `tok_mastercard`, `tok_amex`, `tok_card_declined` (checkout is declined with 402).',
    [
      req('List payment methods', 'GET', '/payment-methods', { tests: [expectStatus(200)] }),
      req('Add a card', 'POST', '/payment-methods', {
        body: { type: 'card', token: 'tok_mastercard', holderName: 'Dara Sok', expMonth: 11, expYear: 2029, setDefault: false },
        desc: 'Saves `paymentMethodId`.',
        tests: [expectStatus(201), data, save('paymentMethodId', 'res.id')],
      }),
      req('Get payment method', 'GET', '/payment-methods/{{paymentMethodId}}', { tests: [expectStatus(200)] }),
      req('Manage card (update expiry)', 'PATCH', '/payment-methods/{{paymentMethodId}}', {
        body: { expMonth: 12, expYear: 2030 },
        tests: [expectStatus(200)],
      }),
      req('Set as default', 'POST', '/payment-methods/{{paymentMethodId}}/default', { tests: [expectStatus(200)] }),
      req('Set Visa 4242 back as default', 'POST', '/payment-methods/pm_visa_4242/default', { tests: [expectStatus(200)] }),
      req('Connect PayPal', 'POST', '/payment-methods', {
        body: { type: 'paypal', email: 'dara@example.com' },
        tests: [`pm.test("Status is 201 or 409 (already connected)", () => pm.expect(pm.response.code).to.be.oneOf([201, 409]));`],
      }),
      req('Remove card', 'DELETE', '/payment-methods/{{paymentMethodId}}', { tests: [expectStatus(200)] }),
    ],
  ),

  // ------------------------------------------------------------------
  folder(
    '09 · Cart',
    'Screens: **Your creation ("Add 2 to bag"), Your cart, Edit item, Empty cart**.\n\n' +
      'A cart holds dishes from one restaurant. `pricing` is the payment summary (all amounts in cents, USD) and ' +
      '`blockers` lists anything that stops checkout.',
    [
      req('Empty the cart', 'DELETE', '/cart', { desc: 'Start clean.', tests: [expectStatus(200)] }),
      req('Get cart (empty)', 'GET', '/cart', {
        desc: '"A little empty. A lot of possibilities." — `isEmpty: true`.',
        tests: [expectStatus(200), `pm.test("Cart is empty", () => pm.expect(pm.response.json().data.isEmpty).to.be.true);`],
      }),
      req('Add to bag – customized salad', 'POST', '/cart/items', {
        body: {
          dishId: '{{dishId}}',
          sizeId: 'large',
          addOnIds: ['avocado', 'sourdough'],
          note: 'Dressing on the side, please.',
          quantity: 2,
        },
        desc: 'Large ($15.50) + avocado ($2.00) + sourdough ($1.50) = $19.00 each × 2 = $38.00. Saves `cartItemId`.',
        tests: [
          expectStatus(201),
          data,
          save('cartItemId', 'res.items[0].id'),
          `pm.test("Line total is $38.00", () => pm.expect(res.items[0].totalCents).to.eql(3800));`,
        ],
      }),
      req('Add to bag – tiramisu', 'POST', '/cart/items', {
        body: { dishId: 'dish_tiramisu', quantity: 1 },
        desc: 'Size defaults to the first one; add-ons and note are optional. Saves `secondCartItemId`.',
        tests: [expectStatus(201), data, save('secondCartItemId', 'res.items[res.items.length - 1].id')],
      }),
      req('Add from another restaurant (409)', 'POST', '/cart/items', {
        body: { dishId: 'dish_tacos_pastor', quantity: 1 },
        desc: 'Error example. Resend with `"replaceCart": true` to start a new bag.',
        tests: [expectError(409, 'CART_HAS_OTHER_RESTAURANT')],
      }),
      req('Add with an invalid add-on (422)', 'POST', '/cart/items', {
        body: { dishId: '{{dishId}}', sizeId: 'huge', addOnIds: ['gold_leaf'] },
        tests: [expectError(422, 'VALIDATION_ERROR')],
      }),
      req('Edit item', 'PATCH', '/cart/items/{{cartItemId}}', {
        body: { sizeId: 'large', addOnIds: ['avocado', 'sourdough'], note: 'Dressing on the side, please.', quantity: 2 },
        desc: '"Update cart". Send only what changes; `note: null` clears the note.',
        tests: [expectStatus(200)],
      }),
      req('Remove item', 'DELETE', '/cart/items/{{secondCartItemId}}', { desc: '"Remove item from cart".', tests: [expectStatus(200)] }),
      req('Get cart', 'GET', '/cart', {
        tests: [expectStatus(200), `pm.test("Subtotal is $38.00", () => pm.expect(pm.response.json().data.pricing.subtotalCents).to.eql(3800));`],
      }),
    ],
  ),

  // ------------------------------------------------------------------
  folder(
    '10 · Checkout',
    'Screens: **Delivery address ("Where’s lunch headed?"), Delivery time, Promo code, Your coupons, Payment methods, Checkout, Order confirmed**.',
    [
      req('Choose delivery address', 'PUT', '/cart/delivery-address', {
        body: { addressId: 'addr_home' },
        desc: '`delivery.message` → "Little Napoli delivers here · 0.2 mi · $1.99 fee".',
        tests: [expectStatus(200)],
      }),
      req('Delivery time slots', 'GET', '/cart/delivery-slots', {
        desc: 'Today/Tomorrow with 30-minute windows inside opening hours (server local time). Saves the first free window.',
        tests: [
          expectStatus(200),
          data,
          `const day = res.days.find(d => d.windows.length > 0);`,
          `pm.environment.set("slotDate", day ? day.date : "");`,
          `pm.environment.set("slotStart", day ? day.windows[0].start : "");`,
        ],
      }),
      req('Schedule for later', 'PUT', '/cart/schedule', {
        body: { type: 'scheduled', date: '{{slotDate}}', windowStart: '{{slotStart}}' },
        desc: '"Save delivery time" with a window from the previous request.',
        tests: [expectStatus(200)],
      }),
      req('Deliver as soon as possible', 'PUT', '/cart/schedule', {
        body: { type: 'asap' },
        desc: 'Switch back to ASAP (keeps the tracking demo quick).',
        tests: [expectStatus(200)],
      }),
      req('Available coupons', 'GET', '/coupons', {
        desc: 'Each coupon is checked against the cart: `eligible`, `applied`, `savingsCents`, `amountToUnlockCents` ("Add $12.00 in food to unlock").',
        tests: [expectStatus(200)],
      }),
      req('Apply coupon – not eligible (422)', 'PUT', '/cart/promo', {
        body: { code: 'LUNCH5' },
        desc: 'Error example: LUNCH5 needs a $50 food subtotal.',
        tests: [expectError(422, 'PROMO_NOT_ELIGIBLE')],
      }),
      req('Apply promo code BASIL10', 'PUT', '/cart/promo', {
        body: { code: 'BASIL10' },
        desc: '10% off food, $25 minimum, up to $5 off. One code per order.',
        tests: [
          expectStatus(200),
          data,
          `pm.test("Saves $3.80", () => pm.expect(res.pricing.foodDiscountCents).to.eql(380));`,
        ],
      }),
      req('Choose payment method', 'PUT', '/cart/payment-method', {
        body: { paymentMethodId: 'pm_visa_4242' },
        tests: [expectStatus(200)],
      }),
      req('Review checkout', 'GET', '/cart', {
        desc: 'Payment summary should match the design: total $40.73.',
        tests: [
          expectStatus(200),
          data,
          `pm.test("Ready to check out", () => pm.expect(res.canCheckout).to.be.true);`,
          `pm.test("Total is $40.73", () => pm.expect(res.pricing.totalCents).to.eql(4073));`,
        ],
      }),
      req('Place order & pay', 'POST', '/orders', {
        desc:
          'Turns the cart into an order (status `confirmed`) and empties the cart. Saves `orderId` and `orderNumber`.\n\n' +
          'Possible errors: CART_EMPTY, MINIMUM_ORDER_NOT_MET, ADDRESS_REQUIRED, PAYMENT_METHOD_REQUIRED, PAYMENT_DECLINED (402), ' +
          'RESTAURANT_NOT_ACCEPTING_ORDERS, SCHEDULE_EXPIRED.',
        tests: [expectStatus(201), data, save('orderId', 'res.id'), save('orderNumber', 'res.number')],
      }),
    ],
  ),

  // ------------------------------------------------------------------
  folder(
    '11 · Orders & Tracking',
    'Screens: **Order status, Your courier, Live tracking, Contact courier, Delivery instructions, Arriving soon, Delivered, ' +
      'Your orders, Order details, Order again**.\n\nRequests marked *(admin)* play the kitchen/courier so the tracking screens can be tested.',
    [
      req('Order details', 'GET', '/orders/{{orderId}}', {
        desc: '`{id}` can be the order id or its number (e.g. `BSL-1038`).',
        tests: [expectStatus(200)],
      }),
      req('Tracking – confirmed', 'GET', '/orders/{{orderId}}/tracking', {
        desc: 'Steps Confirmed → Preparing → On the way → Delivered, ETA, courier, map points. Poll every 10–15 s while `isLive`.',
        tests: [expectStatus(200)],
      }),
      req('Message courier – none yet (409)', 'POST', '/orders/{{orderId}}/messages', {
        body: { text: 'Hello?' },
        tests: [expectError(409, 'NO_COURIER_YET')],
      }),
      req('(admin) Kitchen starts preparing', 'PATCH', '/admin/orders/{{orderId}}/status', {
        auth: 'admin',
        body: { status: 'preparing' },
        desc: 'Assigns the courier.',
        tests: [expectStatus(200)],
      }),
      req('(admin) Courier picks up', 'PATCH', '/admin/orders/{{orderId}}/status', {
        auth: 'admin',
        body: { status: 'on_the_way' },
        desc: 'The courier sends the first chat message and the customer gets a notification.',
        tests: [expectStatus(200)],
      }),
      req('Tracking – live', 'GET', '/orders/{{orderId}}/tracking', {
        tests: [expectStatus(200), `pm.test("Is live", () => pm.expect(pm.response.json().data.isLive).to.be.true);`],
      }),
      req('Courier chat', 'GET', '/orders/{{orderId}}/messages', {
        desc: 'Messages, quick replies and the privacy note.',
        tests: [expectStatus(200)],
      }),
      req('Send message to courier', 'POST', '/orders/{{orderId}}/messages', {
        body: { text: 'Thanks, Sophal! Please ring buzzer 4B and take the stairs.' },
        tests: [expectStatus(201)],
      }),
      req('Delivery instructions', 'PUT', '/orders/{{orderId}}/delivery-instructions', {
        body: { dropoff: 'hand_to_me', note: 'Ring buzzer 4B. Take the stairs.', saveForAddress: true },
        desc: '`dropoff`: hand_to_me | leave_at_door. `saveForAddress` also updates the saved address.',
        tests: [expectStatus(200)],
      }),
      req('(admin) Delivered', 'PATCH', '/admin/orders/{{orderId}}/status', {
        auth: 'admin',
        body: { status: 'delivered' },
        tests: [expectStatus(200)],
      }),
      req('Cancel – too late (409)', 'POST', '/orders/{{orderId}}/cancel', {
        body: { reason: 'Changed my mind' },
        desc: 'Customers can cancel only before the kitchen starts preparing.',
        tests: [expectError(409, 'ORDER_NOT_CANCELLABLE')],
      }),
      req('Your orders – past', 'GET', '/orders?status=past&page=1&limit=20', {
        desc: '`status`: past | upcoming | all.',
        tests: [expectStatus(200)],
      }),
      req('Your orders – upcoming', 'GET', '/orders?status=upcoming', { tests: [expectStatus(200)] }),
      req('Receipt (JSON)', 'GET', '/orders/{{orderId}}/receipt', { tests: [expectStatus(200)] }),
      req('Download receipt (text)', 'GET', '/orders/{{orderId}}/receipt?format=text', {
        desc: 'Plain-text receipt with a download filename.',
        tests: [expectStatus(200), `pm.test("Is text", () => pm.expect(pm.response.headers.get("Content-Type")).to.include("text/plain"));`],
      }),
      req('Order again', 'POST', '/orders/{{orderId}}/reorder', {
        body: { keepNotes: true, quantities: { dish_burrata_salad: 2 } },
        desc: '"Add 2 to new cart" — replaces the cart with this order’s items. Promo codes are not carried over.',
        tests: [expectStatus(201)],
      }),
    ],
  ),

  // ------------------------------------------------------------------
  folder(
    '12 · Reviews & Ratings',
    'Screens: **Rate restaurant, Rate courier, Review your food / Write a review**. Only for delivered orders, one per target.',
    [
      req('Review options for the order', 'GET', '/orders/{{orderId}}/reviews', {
        desc: 'Existing reviews on the order, allowed tags per target and the star labels.',
        tests: [expectStatus(200)],
      }),
      req('Upload a review photo', 'POST', '/uploads', {
        form: [{ key: 'file', type: 'file', src: 'sample-photo.png' }],
        desc: '"Add photos" — JPG/PNG up to 5 MB. Saves `photoUrl` to use in `photoUrls`.',
        tests: [expectStatus(201), data, save('photoUrl', 'res.url'), save('uploadId', 'res.id')],
      }),
      req('View uploaded photo', 'GET', '/uploads/{{uploadId}}', { auth: 'none', tests: [expectStatus(200)] }),
      req('Rate restaurant', 'POST', '/orders/{{orderId}}/reviews', {
        body: {
          target: 'restaurant',
          rating: 4,
          tags: ['order_accuracy', 'thoughtful_packaging'],
          comment: 'Everything was packed with care, and both salads were customized exactly as requested.',
          isPublic: true,
        },
        desc: 'Tags: order_accuracy, thoughtful_packaging, ready_on_time, great_value.',
        tests: [expectStatus(201)],
      }),
      req('Rate courier', 'POST', '/orders/{{orderId}}/reviews', {
        body: {
          target: 'courier',
          rating: 5,
          tags: ['friendly', 'handled_with_care', 'followed_instructions'],
          comment: 'Thanks for bringing lunch up to 4B!',
        },
        desc: 'Tags: friendly, handled_with_care, followed_instructions, on_time. Courier ratings are never public.',
        tests: [expectStatus(201)],
      }),
      req('Review your food', 'POST', '/orders/{{orderId}}/reviews', {
        body: {
          target: 'dish',
          dishId: '{{dishId}}',
          rating: 5,
          tags: ['fresh', 'great_portion', 'delicious'],
          comment: 'Creamy burrata, sweet tomatoes and perfectly ripe avocado.',
          photoUrls: ['{{photoUrl}}'],
          isPublic: true,
        },
        desc: 'Tags: fresh, great_portion, delicious. Up to 5 `photoUrls` from POST /uploads.',
        tests: [expectStatus(201)],
      }),
      req('Rate again – already reviewed (409)', 'POST', '/orders/{{orderId}}/reviews', {
        body: { target: 'restaurant', rating: 5 },
        tests: [expectError(409, 'ALREADY_REVIEWED')],
      }),
    ],
  ),

  // ------------------------------------------------------------------
  folder('13 · Notifications', 'Screen: **Notifications ("A little heads-up.")**.', [
    req('List notifications', 'GET', '/notifications?filter=all', {
      desc: '`filter`: all | unread. `meta.unreadCount` drives the badge. Saves the newest `notificationId`.',
      tests: [expectStatus(200), data, save('notificationId', 'res.length ? res[0].id : ""')],
    }),
    req('Mark one as read', 'POST', '/notifications/{{notificationId}}/read', { tests: [expectStatus(200)] }),
    req('Mark all as read', 'POST', '/notifications/read-all', { tests: [expectStatus(200)] }),
  ]),

  // ------------------------------------------------------------------
  folder('14 · Help & Support', 'Screens: **Help center, Basil support (chat)**.', [
    req('Help center', 'GET', '/help', {
      desc: 'Latest order card, topics and quick answers.',
      tests: [expectStatus(200)],
    }),
    req('Search FAQs', 'GET', '/help/faqs?q=receipt', {
      auth: 'none',
      desc: '`q` and/or `topic` (orders_delivery, payments, account, offers_credits).',
      tests: [expectStatus(200)],
    }),
    req('Send support message', 'POST', '/support/messages', {
      body: { text: 'My order arrived, thank you! Where can I download the receipt?', orderId: '{{orderId}}' },
      tests: [expectStatus(201)],
    }),
    req('Support conversation', 'GET', '/support/messages', { tests: [expectStatus(200)] }),
  ]),

  // ------------------------------------------------------------------
  folder(
    '15 · Admin Dashboard',
    'The web dashboard frame (Dashboard, Orders, Menu, Restaurants, Customers, Payments, Settings). Uses `adminToken` ' +
      '(from **01 · Auth → Login (admin)**). Customer tokens get 403.',
    [
      req('Customer token is refused (403)', 'GET', '/admin/dashboard', { tests: [expectError(403, 'FORBIDDEN')] }),
      req('Dashboard', 'GET', '/admin/dashboard', {
        auth: 'admin',
        desc: 'KPI cards (Orders today +% vs yesterday, revenue, active orders, average order, customers) and recent orders.',
        tests: [expectStatus(200)],
      }),
      req('Orders table', 'GET', '/admin/orders?q=&status=&page=1&limit=20', {
        auth: 'admin',
        desc: '"Search orders, dishes..." — `q` matches number, customer, restaurant, items. `status` filters.',
        tests: [expectStatus(200)],
      }),
      req('Order (admin view)', 'GET', '/admin/orders/{{orderNumber}}', { auth: 'admin', tests: [expectStatus(200)] }),
      req('Customers', 'GET', '/admin/customers?q=', { auth: 'admin', tests: [expectStatus(200)] }),
      req('Payments', 'GET', '/admin/payments?status=all', { auth: 'admin', desc: '`status`: all | paid | refunded.', tests: [expectStatus(200)] }),
      req('Restaurants', 'GET', '/admin/restaurants', { auth: 'admin', tests: [expectStatus(200)] }),
      req('Create restaurant', 'POST', '/admin/restaurants', {
        auth: 'admin',
        body: {
          name: 'Nonna’s Table',
          cuisines: ['Italian'],
          categoryIds: ['cat_italian'],
          neighborhood: 'Williamsburg',
          tagline: 'Sunday sauce, every day.',
          description: 'Family recipes and fresh pasta.',
          address: '210 Grand Street, Brooklyn, NY 11211',
          phone: '+1 (718) 555-0130',
          lat: 40.7139,
          lng: -73.9590,
          deliveryMinMinutes: 20,
          deliveryMaxMinutes: 30,
          deliveryFeeCents: 199,
          minOrderCents: 1000,
          priceLevel: 2,
          dietary: ['vegetarian'],
          menuSections: ['Popular', 'Pasta'],
          hours: [{ label: 'Every day', weekdays: [1, 2, 3, 4, 5, 6, 7], opens: '11:00', closes: '22:00' }],
        },
        desc: 'Saves `newRestaurantId`.',
        tests: [expectStatus(201), data, save('newRestaurantId', 'res.id')],
      }),
      req('Pause new orders', 'PATCH', '/admin/restaurants/{{newRestaurantId}}', {
        auth: 'admin',
        body: { isAcceptingOrders: false },
        desc: 'Drives the customer "Not accepting orders" screen.',
        tests: [expectStatus(200)],
      }),
      req('Resume orders', 'PATCH', '/admin/restaurants/{{newRestaurantId}}', {
        auth: 'admin',
        body: { isAcceptingOrders: true },
        tests: [expectStatus(200)],
      }),
      req('Menu – list dishes', 'GET', '/admin/dishes?restaurantId={{restaurantId}}', { auth: 'admin', tests: [expectStatus(200)] }),
      req('Menu – create dish', 'POST', '/admin/dishes', {
        auth: 'admin',
        body: {
          restaurantId: '{{newRestaurantId}}',
          name: 'Pappardelle al ragù',
          description: 'Slow-cooked beef ragù, parmesan.',
          priceCents: 1900,
          section: 'Pasta',
          isPopular: true,
          sizes: [
            { id: 'regular', name: 'Regular', priceDeltaCents: 0 },
            { id: 'large', name: 'Large', description: 'For big appetites', priceDeltaCents: 400 },
          ],
          addOns: [{ id: 'extra_parmesan', name: 'Extra parmesan', priceDeltaCents: 150 }],
        },
        desc: 'Saves `newDishId`. Option ids: lowercase a-z, 0-9, _.',
        tests: [expectStatus(201), data, save('newDishId', 'res.id')],
      }),
      req('Menu – mark dish unavailable', 'PATCH', '/admin/dishes/{{newDishId}}', {
        auth: 'admin',
        body: { isAvailable: false },
        tests: [expectStatus(200)],
      }),
      req('Menu – delete dish', 'DELETE', '/admin/dishes/{{newDishId}}', { auth: 'admin', tests: [expectStatus(200)] }),
      req('Platform settings', 'GET', '/admin/settings', { auth: 'admin', tests: [expectStatus(200)] }),
      req('Update platform settings', 'PATCH', '/admin/settings', {
        auth: 'admin',
        body: { serviceFeeCents: 150, taxRate: 0.08875 },
        desc: 'Service fee (cents) and tax rate (0–0.25).',
        tests: [expectStatus(200)],
      }),
    ],
  ),

  // ------------------------------------------------------------------
  folder(
    '16 · Sign out & Delete account',
    'Screens: **Profile → Log out, Delete account**. "Delete account" uses the throw-away user from **01 · Auth → Register** (`tempToken`).',
    [
      req('Delete account – needs confirmation (400)', 'DELETE', '/me', {
        auth: 'temp',
        body: { confirm: false },
        tests: [expectError(400, 'CONFIRMATION_REQUIRED')],
      }),
      req('Delete account', 'DELETE', '/me', {
        auth: 'temp',
        body: { confirm: true },
        desc: '"Yes, delete my account" — permanent. Removes addresses, cards, favorites and sessions.',
        tests: [expectStatus(200)],
      }),
      req('Deleted token no longer works (401)', 'GET', '/me', { auth: 'temp', tests: [expectError(401, 'TOKEN_INVALID')] }),
      req('Log out', 'POST', '/auth/logout', {
        body: { refreshToken: '{{refreshToken}}', allDevices: false },
        desc: 'Revokes the refresh token (`allDevices: true` revokes every session). The app should also discard the access token.',
        tests: [expectStatus(200)],
      }),
    ],
  ),
];

const collection = {
  info: {
    name: 'Basil API',
    _postman_id: '6b2f1f40-8c1e-4d39-9e0a-6c1b6a0b8a01',
    description:
      '# Basil API (Dart Frog)\n\n' +
      'REST API for the **Basil** food-delivery app, built from the Figma design.\n\n' +
      '## Getting started\n' +
      '1. Start the server: `cd basil_api && dart_frog dev` (http://localhost:8080).\n' +
      '2. Select the **Basil API – Local** environment.\n' +
      '3. Run **01 · Auth → Login (customer)** (and **Login (admin)** for admin requests). Tokens are saved automatically.\n' +
      '4. Folders are ordered like the app flow — use **Run collection** to execute everything top to bottom. ' +
      'Data is in memory, so restart the server for a clean slate.\n\n' +
      '## Conventions\n' +
      '- Base path `/api/v1`. JSON in, JSON out.\n' +
      '- Success: `{"data": ..., "meta": {...}}`. Lists have `meta.page/limit/total/totalPages` (`?page=&limit=`, max 100).\n' +
      '- Errors: `{"error": {"code", "message", "details"}}` — `details` maps field → message on 422.\n' +
      '- Money is **integer cents** (USD). Times are ISO-8601 UTC.\n' +
      '- Auth: `Authorization: Bearer <accessToken>` (1 hour). Use `/auth/refresh` with the refresh token (30 days, rotating).\n\n' +
      '## Demo accounts\n' +
      '- Customer: `dara@example.com` / `Basil1234`\n' +
      '- Admin: `admin@basil.app` / `Admin1234`\n',
    schema: 'https://schema.getpostman.com/json/collection/v2.1.0/collection.json',
  },
  auth: { type: 'bearer', bearer: [{ key: 'token', value: '{{accessToken}}', type: 'string' }] },
  item: items,
};

const envVar = (key, value, type = 'default') => ({ key, value, type, enabled: true });
const environment = {
  id: '0f5d8a2e-2b5e-4c3a-9a43-5b1f2a7c9d10',
  name: 'Basil API – Local',
  values: [
    envVar('baseUrl', 'http://localhost:8080/api/v1'),
    envVar('email', 'dara@example.com'),
    envVar('password', 'Basil1234', 'secret'),
    envVar('adminEmail', 'admin@basil.app'),
    envVar('adminPassword', 'Admin1234', 'secret'),
    envVar('restaurantId', 'rest_little_napoli'),
    envVar('dishId', 'dish_burrata_salad'),
    envVar('accessToken', '', 'secret'),
    envVar('refreshToken', '', 'secret'),
    envVar('adminToken', '', 'secret'),
    envVar('tempToken', '', 'secret'),
    envVar('tempEmail', ''),
    envVar('resetToken', '', 'secret'),
    envVar('addressId', ''),
    envVar('paymentMethodId', ''),
    envVar('favoriteId', ''),
    envVar('cartItemId', ''),
    envVar('secondCartItemId', ''),
    envVar('slotDate', ''),
    envVar('slotStart', ''),
    envVar('orderId', ''),
    envVar('orderNumber', ''),
    envVar('notificationId', ''),
    envVar('uploadId', ''),
    envVar('photoUrl', ''),
    envVar('newRestaurantId', ''),
    envVar('newDishId', ''),
  ],
  _postman_variable_scope: 'environment',
};

const out = process.argv[2] ? path.resolve(process.argv[2]) : __dirname;
fs.mkdirSync(out, { recursive: true });
fs.writeFileSync(path.join(out, 'Basil-API.postman_collection.json'), json(collection));
fs.writeFileSync(path.join(out, 'Basil-API-Local.postman_environment.json'), json(environment));
const count = items.reduce((n, f) => n + f.item.length, 0);
console.log(`Wrote ${items.length} folders, ${count} requests.`);

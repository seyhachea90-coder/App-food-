import '../models/models.dart';

/// Result of checking a coupon against a restaurant and a food subtotal.
class CouponCheck {
  CouponCheck({
    required this.eligible,
    required this.foodDiscountCents,
    required this.deliveryDiscountCents,
    this.reason,
    this.amountToUnlockCents = 0,
  });

  final bool eligible;
  final int foodDiscountCents;
  final int deliveryDiscountCents;
  final String? reason;
  final int amountToUnlockCents;

  int get savingsCents => foodDiscountCents + deliveryDiscountCents;
}

/// Platform fees an admin can change at runtime.
class PlatformSettings {
  int serviceFeeCents = 150;

  /// NYC combined sales tax; applied to food after discounts.
  double taxRate = 0.08875;

  Map<String, dynamic> toJson() => {
        'serviceFeeCents': serviceFeeCents,
        'taxRate': taxRate,
        'currency': 'USD',
      };
}

String formatCents(int cents) {
  final negative = cents < 0;
  final abs = cents.abs();
  final s = '\$${abs ~/ 100}.${(abs % 100).toString().padLeft(2, '0')}';
  return negative ? '−$s' : s;
}

CouponCheck checkCoupon(Coupon coupon, Restaurant? restaurant, int subtotalCents) {
  if (coupon.isExpired) {
    return CouponCheck(
      eligible: false,
      foodDiscountCents: 0,
      deliveryDiscountCents: 0,
      reason: 'This code has expired.',
    );
  }
  if (coupon.restaurantId != null && coupon.restaurantId != restaurant?.id) {
    return CouponCheck(
      eligible: false,
      foodDiscountCents: 0,
      deliveryDiscountCents: 0,
      reason: 'Not valid for this restaurant.',
    );
  }
  if (subtotalCents < coupon.minSubtotalCents) {
    final missing = coupon.minSubtotalCents - subtotalCents;
    return CouponCheck(
      eligible: false,
      foodDiscountCents: 0,
      deliveryDiscountCents: 0,
      amountToUnlockCents: missing,
      reason: 'Add ${formatCents(missing)} in food to unlock.',
    );
  }
  int cap(int value) => coupon.maxDiscountCents == null
      ? value
      : (value > coupon.maxDiscountCents! ? coupon.maxDiscountCents! : value);

  switch (coupon.type) {
    case CouponType.percentOff:
      return CouponCheck(
        eligible: true,
        foodDiscountCents: cap((subtotalCents * coupon.value / 100).round()),
        deliveryDiscountCents: 0,
      );
    case CouponType.amountOff:
      final off = cap(coupon.value);
      return CouponCheck(
        eligible: true,
        foodDiscountCents: off > subtotalCents ? subtotalCents : off,
        deliveryDiscountCents: 0,
      );
    case CouponType.freeDelivery:
      final fee = restaurant?.deliveryFeeCents ?? 0;
      return CouponCheck(
        eligible: true,
        foodDiscountCents: 0,
        deliveryDiscountCents: cap(fee),
      );
  }
}

PriceQuote computeQuote({
  required Restaurant? restaurant,
  required int subtotalCents,
  required int itemCount,
  required PlatformSettings settings,
  Coupon? coupon,
}) {
  if (restaurant == null || itemCount == 0) {
    return PriceQuote(
      itemCount: 0,
      subtotalCents: 0,
      foodDiscountCents: 0,
      deliveryFeeCents: 0,
      deliveryDiscountCents: 0,
      serviceFeeCents: 0,
      taxCents: 0,
    );
  }
  final check = coupon == null ? null : checkCoupon(coupon, restaurant, subtotalCents);
  final applied = check != null && check.eligible;
  final foodDiscount = applied ? check.foodDiscountCents : 0;
  return PriceQuote(
    itemCount: itemCount,
    subtotalCents: subtotalCents,
    promoCode: applied ? coupon!.code : null,
    foodDiscountCents: foodDiscount,
    deliveryFeeCents: restaurant.deliveryFeeCents,
    deliveryDiscountCents: applied ? check.deliveryDiscountCents : 0,
    serviceFeeCents: settings.serviceFeeCents,
    taxCents: ((subtotalCents - foodDiscount) * settings.taxRate).round(),
  );
}

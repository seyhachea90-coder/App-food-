import 'package:basil_api/basil_api.dart';
import 'package:dart_frog/dart_frog.dart';

/// GET /api/v1/app/config — Splash / Settings → About Basil.
Future<Response> onRequest(RequestContext context) => handle(context, {
      HttpMethod.get: () => ok({
            'appName': 'Basil',
            'apiVersion': Config.apiVersion,
            'minimumAppVersion': '1.0.0',
            'currency': Config.currency,
            'languages': UserSettings.languages,
            'appearances': UserSettings.appearances,
            'legal': {
              'termsOfServiceUrl': 'https://example.com/basil/terms',
              'privacyPolicyUrl': 'https://example.com/basil/privacy',
              'communityGuidelinesUrl': 'https://example.com/basil/community-guidelines',
            },
            'passwordRule': 'At least 8 characters, including a number.',
            'maxUploadBytes': Config.maxUploadBytes,
          }),
    });

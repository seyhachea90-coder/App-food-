import 'package:dart_frog/dart_frog.dart';

import '../config.dart';
import '../data/store.dart';
import '../http/api_exception.dart';
import '../models/models.dart';
import 'crypto.dart';

/// The signed-in user for the current request (null for guests).
class AuthContext {
  const AuthContext(this.user);
  final User? user;
}

extension RequestAuth on RequestContext {
  Store get store => read<Store>();

  User? get userOrNull => read<AuthContext>().user;

  /// The signed-in user, or a 401.
  User get user => userOrNull ?? (throw ApiException.unauthorized());

  /// The signed-in admin, or a 401/403.
  User get admin {
    final u = user;
    if (u.role != UserRole.admin) {
      throw ApiException.forbidden('Admin access required.');
    }
    return u;
  }
}

/// Issues an access + refresh token pair.
Map<String, dynamic> issueSession(Store store, User user) {
  final accessToken = Config.jwt.sign(
    {'sub': user.id, 'role': user.role.name, 'type': 'access'},
    Config.accessTokenTtl,
  );
  final refreshToken = randomToken(32);
  store.refreshTokens[refreshToken] = RefreshSession(
    user.id,
    DateTime.now().toUtc().add(Config.refreshTokenTtl),
  );
  return {
    'accessToken': accessToken,
    'refreshToken': refreshToken,
    'tokenType': 'Bearer',
    'expiresIn': Config.accessTokenTtl.inSeconds,
    'user': user.toJson(),
  };
}

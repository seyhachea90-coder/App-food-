import 'package:basil_api/basil_api.dart';
import 'package:dart_frog/dart_frog.dart';

/// /api/v1/support/messages — "Basil support" chat.
///
/// Customer messages are stored and acknowledged automatically. Agent replies
/// come from your support tool / an admin console (not part of this API yet).
Future<Response> onRequest(RequestContext context) => handle(context, {
      HttpMethod.get: () {
        final user = context.user;
        final messages = context.store.supportMessages.where((m) => m.userId == user.id).toList()
          ..sort((a, b) => a.createdAt.compareTo(b.createdAt));
        return ok({
          'team': 'The Basil care team',
          'safetyNote': 'Never share your password or full card number in chat.',
          'messages': messages.map((m) => m.toJson()).toList(),
        });
      },
      HttpMethod.post: () async {
        final user = context.user;
        final store = context.store;
        final body = await Body.parse(context);
        final text = body.string('text', required: true, max: 1000);
        final orderId = body.string('orderId');
        body.validate();

        final order = orderId == null ? null : store.ownedOrder(user, orderId);
        final now = DateTime.now().toUtc();
        final isFirst = !store.supportMessages.any((m) => m.userId == user.id);
        final message = SupportMessage(
          id: newId('sup'),
          userId: user.id,
          sender: 'customer',
          authorName: user.firstName,
          text: text!,
          orderId: order?.id,
          createdAt: now,
        );
        store.supportMessages.add(message);
        if (isFirst) {
          store.supportMessages.add(
            SupportMessage(
              id: newId('sup'),
              userId: user.id,
              sender: 'system',
              authorName: 'Basil support',
              text: 'Thanks, ${user.firstName}! A member of the Basil care team will reply here shortly.',
              orderId: order?.id,
              createdAt: now,
            ),
          );
        }
        return created(message.toJson());
      },
    });

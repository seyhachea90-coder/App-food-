import 'package:basil_api/basil_api.dart';
import 'package:dart_frog/dart_frog.dart';

/// Every /api/v1/admin route requires an admin account.
Handler middleware(Handler handler) => (context) {
      context.admin; // Throws 401/403 when not an admin.
      return handler(context);
    };

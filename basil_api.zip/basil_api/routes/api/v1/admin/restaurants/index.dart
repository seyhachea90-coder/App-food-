import 'package:basil_api/basil_api.dart';
import 'package:basil_api/src/http/admin_input.dart';
import 'package:dart_frog/dart_frog.dart';

const _defaultHours = [
  OpeningHours('Every day', [1, 2, 3, 4, 5, 6, 7], '11:00', '22:00'),
];

/// /api/v1/admin/restaurants — list (incl. paused ones) and create.
Future<Response> onRequest(RequestContext context) => handle(context, {
      HttpMethod.get: () {
        final store = context.store;
        final list = store.restaurants.values.toList()..sort((a, b) => a.name.compareTo(b.name));
        return ok(
          list
              .map((r) => {
                    ...r.toDetailJson(),
                    'dishCount': store.dishes.values.where((d) => d.restaurantId == r.id).length,
                    'orderCount': store.orders.values.where((o) => o.restaurantId == r.id).length,
                  })
              .toList(),
          meta: {'total': list.length},
        );
      },
      HttpMethod.post: () async {
        final store = context.store;
        final body = await Body.parse(context);
        final r = Restaurant(
          id: newId('rest'),
          name: '',
          cuisines: const [],
          categoryIds: const [],
          neighborhood: '',
          tagline: '',
          description: '',
          address: '',
          phone: '',
          lat: 0,
          lng: 0,
          ratingBreakdown: {},
          deliveryMinMinutes: 20,
          deliveryMaxMinutes: 35,
          deliveryFeeCents: 199,
          minOrderCents: 1000,
          priceLevel: 2,
          hours: _defaultHours,
          menuSections: const ['Popular'],
          imageUrl: 'https://placehold.co/600x400?text=Restaurant',
        );
        applyRestaurantInput(body, r, creating: true);
        final unknown = r.categoryIds.where((c) => store.category(c) == null);
        if (unknown.isNotEmpty) {
          throw ApiException.validation({'categoryIds': 'Unknown: ${unknown.join(', ')}.'});
        }
        store.restaurants[r.id] = r;
        return created(r.toDetailJson());
      },
    });

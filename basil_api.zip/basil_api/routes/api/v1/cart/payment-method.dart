import 'package:basil_api/basil_api.dart';
import 'package:dart_frog/dart_frog.dart';

/// PUT /api/v1/cart/payment-method — "Use Visa •••• 1234".
Future<Response> onRequest(RequestContext context) => handle(context, {
      HttpMethod.put: () async {
        final user = context.user;
        final store = context.store;
        final body = await Body.parse(context);
        final id = body.string('paymentMethodId', required: true);
        body.validate();

        final method = store.ownedPaymentMethod(user, id!);
        if (method.isExpired) {
          throw ApiException.unprocessable('CARD_EXPIRED', 'This card has expired. Choose another.');
        }
        final cart = store.cartOf(user.id)..paymentMethodId = method.id;
        return ok(CartService(store).toJson(cart));
      },
    });

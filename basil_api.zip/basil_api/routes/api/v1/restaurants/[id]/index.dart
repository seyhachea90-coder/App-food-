import 'package:basil_api/basil_api.dart';
import 'package:dart_frog/dart_frog.dart';

/// GET /api/v1/restaurants/{id} — Restaurant overview + "Restaurant info".
/// When the kitchen has paused orders, `alternatives` lists similar places
/// ("Still craving Italian?").
Future<Response> onRequest(RequestContext context, String id) => handle(context, {
      HttpMethod.get: () {
        final store = context.store;
        final catalog = CatalogService(store);
        final r = store.restaurant(id);
        final (lat, lng) = catalog.origin(context);
        final user = context.userOrNull;

        final alternatives = r.isAcceptingOrders
            ? const <Map<String, dynamic>>[]
            : store.restaurants.values
                .where((o) => o.id != r.id && o.isAcceptingOrders)
                .where((o) => o.cuisines.any(r.cuisines.contains))
                .take(3)
                .map((o) => o.toSummaryJson(fromLat: lat, fromLng: lng))
                .toList();

        return ok({
          ...r.toDetailJson(fromLat: lat, fromLng: lng),
          'status': r.isAcceptingOrders
              ? {'code': 'accepting_orders', 'label': r.isOpenNow ? 'Open now' : 'Closed now'}
              : {
                  'code': 'paused',
                  'label': 'Not accepting orders',
                  'message': '${r.name} is catching up on orders and has temporarily paused new ones.',
                },
          'featuredDishes': store.dishes.values
              .where((d) => d.restaurantId == r.id && d.isPopular)
              .take(3)
              .map((d) => d.toSummaryJson(r))
              .toList(),
          'alternatives': alternatives,
          if (user != null) 'isFavorite': store.isFavoriteRestaurant(user.id, r.id),
        });
      },
    });

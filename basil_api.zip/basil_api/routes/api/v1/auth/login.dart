import 'package:basil_api/basil_api.dart';
import 'package:dart_frog/dart_frog.dart';

/// POST /api/v1/auth/login — "Good to see you." (Sign in)
Future<Response> onRequest(RequestContext context) => handle(context, {
      HttpMethod.post: () async {
        final body = await Body.parse(context);
        final email = body.email('email', required: true);
        final password = body.string('password', required: true);
        body.validate();

        final store = context.store;
        final user = store.userByEmail(email!);
        if (user == null || !verifyPassword(password!, user.passwordHash)) {
          throw ApiException(401, 'INVALID_CREDENTIALS', 'Email or password is incorrect.');
        }
        return ok(issueSession(store, user));
      },
    });

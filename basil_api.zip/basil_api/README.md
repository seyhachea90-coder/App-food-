# Basil API (Dart Frog)

REST API for **Basil**, the food-delivery app in the Figma file *Untitled* (60 mobile screens + admin dashboard).
Built with [Dart Frog](https://dartfrog.vgv.dev).

> **Data is in memory.** It is seeded with the content from the design (Little Napoli, Burrata & heirloom salad, BASIL10, ...)
> and resets every time the server restarts. Swap `lib/src/data/store.dart` for a database when you're ready.

## Run it

```bash
dart pub global activate dart_frog_cli   # once
cd basil_api
dart pub get
dart_frog dev                            # http://localhost:8080  (hot reload)
```

Production build:

```bash
dart_frog build
dart build/bin/server.dart               # PORT env var, default 8080
```

| Env var | Default | Notes |
|---|---|---|
| `JWT_SECRET` | dev secret | **Set a long random value outside local dev.** |
| `BASIL_ENV` | (unset) | `production` hides `devResetToken` and disables the Google sign-in mock. |
| `PORT` | 8080 | |

### Demo accounts

| Role | Email | Password |
|---|---|---|
| Customer | `dara@example.com` | `Basil1234` |
| Admin | `admin@basil.app` | `Admin1234` |

## Postman

Files in [`postman/`](postman):

- `Basil-API.postman_collection.json`: 130 requests in 17 folders, ordered like the app flow, with descriptions and tests.
- `Basil-API-Local.postman_environment.json`: `baseUrl`, demo logins and variables the tests fill in (tokens, ids).
- `sample-photo.png`: used by the upload requests. In Postman set **Settings → General → Working directory** to this folder.
- `build-collection.js`: regenerates both JSON files (`node postman/build-collection.js`).

Import both JSON files, select **Basil API – Local**, run **01 · Auth → Login (customer)** and **Login (admin)**, then
use any request. Tokens are saved automatically. **Run collection** executes everything top to bottom.

Command line (same tests):

```bash
npx newman run postman/Basil-API.postman_collection.json -e postman/Basil-API-Local.postman_environment.json --working-dir postman
```

## Conventions

- Base path: `/api/v1`. JSON in, JSON out. CORS is open for development.
- Success: `{"data": ..., "meta": {...}}`. Paged lists accept `?page=&limit=` (max 100) and return `meta.page/limit/total/totalPages`.
- Errors: `{"error": {"code": "VALIDATION_ERROR", "message": "...", "details": {"email": "Please enter a valid email."}}}`.
  Status codes: 400 bad request, 401 not signed in / token expired, 402 payment declined, 403 not allowed,
  404 not found, 405 wrong method, 409 conflict, 413/415 upload problems, 422 validation or business rule.
- Money is **integer cents** (USD). Times are ISO-8601 UTC. Delivery windows (`date`, `HH:mm`) use the server's local time.
- Auth: `Authorization: Bearer <accessToken>` (1 h). Refresh with `POST /auth/refresh` (refresh tokens last 30 days and rotate).
- Order `{id}` accepts the id (`ord_...`) or the number (`BSL-1038`).

## Endpoints

| Area (Figma screens) | Method & path |
|---|---|
| **Health** | `GET /health` · `GET /app/config` |
| **Auth** (Login, Sign up, Forgot/Reset password) | `POST /auth/register` · `POST /auth/login` · `POST /auth/google` · `POST /auth/refresh` · `POST /auth/logout` · `POST /auth/forgot-password` · `POST /auth/reset-password` |
| **Profile & settings** (Your account, Edit profile, Settings, Delete account) | `GET/PATCH/DELETE /me` · `PUT /me/password` · `POST/DELETE /me/avatar` · `GET/PATCH /me/settings` |
| **Location & addresses** | `GET /places/search?q=` · `GET /places/reverse?lat=&lng=` · `GET/POST /addresses` · `GET/PATCH/DELETE /addresses/{id}` · `POST /addresses/{id}/default` |
| **Discover** (Home, Categories, Search, Filters) | `GET /home` · `GET /categories` · `GET /search` · `GET /search/suggestions` · `GET /search/filters` · `DELETE /search/recent` |
| **Restaurants** (Restaurant, Info, Menu, Reviews, Not accepting orders) | `GET /restaurants` · `GET /restaurants/{id}` · `GET /restaurants/{id}/menu` · `GET /restaurants/{id}/reviews` |
| **Dishes** (Food details, Size, Add-ons, Instructions) | `GET /dishes/{id}` · `GET /dishes/{id}/reviews` |
| **Favorites** | `GET/POST /favorites` · `DELETE /favorites/{id}` |
| **Cart** (Your creation, Cart, Edit item) | `GET/DELETE /cart` · `POST /cart/items` · `PATCH/DELETE /cart/items/{itemId}` |
| **Checkout** (Delivery address, Delivery time, Promo, Coupons, Payment) | `PUT /cart/delivery-address` · `GET /cart/delivery-slots` · `PUT /cart/schedule` · `PUT/DELETE /cart/promo` · `GET /coupons` · `PUT /cart/payment-method` · `POST /orders` |
| **Payment methods** | `GET/POST /payment-methods` · `GET/PATCH/DELETE /payment-methods/{id}` · `POST /payment-methods/{id}/default` |
| **Orders & tracking** (Status, Courier, Live tracking, Chat, Instructions, Delivered, History, Details, Order again) | `GET /orders` · `GET /orders/{id}` · `GET /orders/{id}/tracking` · `GET/POST /orders/{id}/messages` · `PUT /orders/{id}/delivery-instructions` · `POST /orders/{id}/cancel` · `GET /orders/{id}/receipt` · `POST /orders/{id}/reorder` |
| **Reviews** (Rate restaurant/courier, Review your food) | `GET/POST /orders/{id}/reviews` · `POST /uploads` · `GET /uploads/{id}` |
| **Notifications** | `GET /notifications` · `POST /notifications/{id}/read` · `POST /notifications/read-all` |
| **Help & support** | `GET /help` · `GET /help/faqs` · `GET/POST /support/messages` |
| **Admin dashboard** (admin only) | `GET /admin/dashboard` · `GET /admin/orders` · `GET /admin/orders/{id}` · `PATCH /admin/orders/{id}/status` · `GET/POST /admin/restaurants` · `GET/PATCH /admin/restaurants/{id}` · `GET/POST /admin/dishes` · `PATCH/DELETE /admin/dishes/{id}` · `GET /admin/customers` · `GET /admin/payments` · `GET/PATCH /admin/settings` |

Order status flow: `confirmed → preparing → on_the_way → delivered` (or `cancelled`). Nothing moves an order
automatically: use `PATCH /admin/orders/{id}/status` to act as the kitchen/courier while testing tracking.

## Mocks to replace before production

| Mock | Where | Replace with |
|---|---|---|
| In-memory store | `lib/src/data/store.dart`, `seed.dart` | A database (PostgreSQL, etc.) |
| Password-reset email | `routes/api/v1/auth/forgot-password.dart` returns `devResetToken` | An email provider + deep link |
| Google sign-in | `routes/api/v1/auth/google.dart` accepts `dev:<email>:<name>` | Verify the Google ID token |
| Card tokens (`tok_visa`, ...) | `routes/api/v1/payment-methods/index.dart` | Stripe (or similar) tokens + real charges |
| Address search / reverse geocode | `routes/api/v1/places/*` | Google Places / Mapbox |
| Courier location | `OrderService.trackingJson` simulates movement | Courier app GPS updates |
| Image placeholders | `placehold.co` URLs in seed data | Your CDN / uploaded images |
| Uploads stored in memory | `routes/api/v1/uploads` | Object storage (S3, GCS) |
| Legal links | `routes/api/v1/app/config.dart` (example.com) | Real Terms/Privacy URLs |

## Project layout

```
lib/
  basil_api.dart            # one import for routes
  src/config.dart           # env + token lifetimes
  src/data/                 # in-memory store + seed data from the design
  src/http/                 # error type, JSON body validation, pagination, uploads
  src/models/               # User, Address, Restaurant, Dish, Cart, Order, Review, ...
  src/security/             # JWT (HS256), password hashing, auth context
  src/services/             # pricing, cart, catalog/search, orders/tracking, reviews
routes/                     # one file per endpoint (Dart Frog file-based routing)
  _middleware.dart          # CORS, errors → JSON, logging, store, bearer auth
  api/v1/admin/_middleware.dart  # admin-only guard
postman/                    # collection, environment, generator
```

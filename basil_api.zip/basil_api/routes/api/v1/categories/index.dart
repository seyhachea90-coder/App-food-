import 'package:basil_api/basil_api.dart';
import 'package:dart_frog/dart_frog.dart';

/// GET /api/v1/categories — "Follow your craving." (all categories + place counts)
/// Restaurants in a category: GET /api/v1/restaurants?categoryId=cat_pizza
Future<Response> onRequest(RequestContext context) => handle(context, {
      HttpMethod.get: () {
        final store = context.store;
        return ok(
          store.categories.map((c) => c.toJson(placeCount: store.placeCount(c.id))).toList(),
        );
      },
    });

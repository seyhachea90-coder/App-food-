import 'package:basil_api/basil_api.dart';
import 'package:dart_frog/dart_frog.dart';

/// GET /api/v1/admin/customers?q= — customer list with order stats.
Future<Response> onRequest(RequestContext context) => handle(context, {
      HttpMethod.get: () {
        final store = context.store;
        final q = context.queryString('q')?.toLowerCase();
        final page = Pagination.of(context);
        final list = store.users.values
            .where((u) => u.role == UserRole.customer)
            .where((u) => q == null || '${u.fullName} ${u.email}'.toLowerCase().contains(q))
            .toList()
          ..sort((a, b) => a.fullName.compareTo(b.fullName));
        return ok(
          page.slice(list).map((u) {
            final orders = store.ordersOf(u.id);
            return {
              'id': u.id,
              'fullName': u.fullName,
              'email': u.email,
              'phone': u.phone,
              'joinedAt': iso(u.createdAt),
              'orderCount': orders.length,
              'totalSpentCents': orders
                  .where((o) => o.status != OrderStatus.cancelled)
                  .fold(0, (sum, o) => sum + o.quote.totalCents),
              'lastOrderAt': orders.isEmpty ? null : iso(orders.first.createdAt),
            };
          }).toList(),
          meta: page.meta(list.length),
        );
      },
    });

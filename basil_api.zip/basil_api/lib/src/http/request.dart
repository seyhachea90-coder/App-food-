import 'dart:async';
import 'dart:convert';

import 'package:dart_frog/dart_frog.dart';

import 'api_exception.dart';

final _emailPattern = RegExp(r'^[^\s@]+@[^\s@]+\.[^\s@]+$');
final _hasDigit = RegExp(r'\d');

/// Success envelope: `{"data": ..., "meta": {...}}`.
Response ok(Object? data, {Map<String, dynamic>? meta, int status = 200}) =>
    Response.json(
      statusCode: status,
      body: {'data': data, if (meta != null) 'meta': meta},
    );

Response created(Object? data) => ok(data, status: 201);

/// Dispatches on the HTTP method and answers 405 for anything else.
Future<Response> handle(
  RequestContext context,
  Map<HttpMethod, FutureOr<Response> Function()> handlers,
) async {
  final handler = handlers[context.request.method];
  if (handler == null) {
    throw ApiException.methodNotAllowed(
      handlers.keys.map((m) => m.value).toList(),
    );
  }
  return handler();
}

extension QueryParams on RequestContext {
  Map<String, String> get query => request.uri.queryParameters;

  String? queryString(String key) {
    final value = query[key]?.trim();
    return (value == null || value.isEmpty) ? null : value;
  }

  List<String> queryList(String key) =>
      (queryString(key) ?? '')
          .split(',')
          .map((e) => e.trim())
          .where((e) => e.isNotEmpty)
          .toList();

  bool queryBool(String key) {
    final v = queryString(key)?.toLowerCase();
    return v == 'true' || v == '1' || v == 'yes';
  }

  double? queryDouble(String key) {
    final v = queryString(key);
    if (v == null) return null;
    final parsed = double.tryParse(v);
    if (parsed == null) {
      throw ApiException.validation({key: 'Must be a number.'});
    }
    return parsed;
  }

  int? queryInt(String key) {
    final v = queryString(key);
    if (v == null) return null;
    final parsed = int.tryParse(v);
    if (parsed == null) {
      throw ApiException.validation({key: 'Must be a whole number.'});
    }
    return parsed;
  }

  String queryEnum(String key, List<String> allowed, String fallback) {
    final v = queryString(key);
    if (v == null) return fallback;
    if (!allowed.contains(v)) {
      throw ApiException.validation(
        {key: 'Must be one of: ${allowed.join(', ')}.'},
      );
    }
    return v;
  }
}

/// `?page=1&limit=20` pagination.
class Pagination {
  Pagination(this.page, this.limit);

  factory Pagination.of(RequestContext context) {
    final page = context.queryInt('page') ?? 1;
    final limit = context.queryInt('limit') ?? 20;
    if (page < 1) throw ApiException.validation({'page': 'Must be 1 or more.'});
    if (limit < 1 || limit > 100) {
      throw ApiException.validation({'limit': 'Must be between 1 and 100.'});
    }
    return Pagination(page, limit);
  }

  final int page;
  final int limit;

  List<T> slice<T>(List<T> items) =>
      items.skip((page - 1) * limit).take(limit).toList();

  Map<String, dynamic> meta(int total) => {
        'page': page,
        'limit': limit,
        'total': total,
        'totalPages': total == 0 ? 0 : (total / limit).ceil(),
      };
}

/// Reads and validates a JSON request body, collecting all field errors so the
/// client can show them next to the right inputs at once.
class Body {
  Body._(this.raw);

  /// Validates a nested JSON object with the same helpers.
  factory Body.fromMap(Map<String, dynamic> map) => Body._(map);

  static Future<Body> parse(RequestContext context) async {
    final text = await context.request.body();
    if (text.trim().isEmpty) return Body._(<String, dynamic>{});
    Object? decoded;
    try {
      decoded = jsonDecode(text);
    } on FormatException {
      throw ApiException.badRequest('Request body is not valid JSON.');
    }
    if (decoded is! Map<String, dynamic>) {
      throw ApiException.badRequest('Request body must be a JSON object.');
    }
    return Body._(decoded);
  }

  final Map<String, dynamic> raw;
  final Map<String, String> errors = {};

  bool has(String key) => raw.containsKey(key);

  String? string(
    String key, {
    bool required = false,
    int min = 0,
    int? max,
    List<String>? oneOf,
    bool allowEmpty = false,
  }) {
    final v = raw[key];
    if (v == null || (v is String && v.trim().isEmpty && !allowEmpty)) {
      if (required) errors[key] = 'This field is required.';
      return null;
    }
    if (v is! String) {
      errors[key] = 'Must be text.';
      return null;
    }
    final s = v.trim();
    if (s.length < min) {
      errors[key] = 'Must be at least $min characters.';
      return null;
    }
    if (max != null && s.length > max) {
      errors[key] = 'Must be $max characters or fewer.';
      return null;
    }
    if (oneOf != null && !oneOf.contains(s)) {
      errors[key] = 'Must be one of: ${oneOf.join(', ')}.';
      return null;
    }
    return s;
  }

  String? email(String key, {bool required = false}) {
    final s = string(key, required: required, max: 254);
    if (s == null) return null;
    if (!_emailPattern.hasMatch(s)) {
      errors[key] = 'Please enter a valid email.';
      return null;
    }
    return s.toLowerCase();
  }

  /// Basil's rule from the sign-up screen: 8+ characters and a number.
  String? password(String key) {
    final v = raw[key];
    if (v is! String || v.isEmpty) {
      errors[key] = 'This field is required.';
      return null;
    }
    if (v.length < 8 || !_hasDigit.hasMatch(v)) {
      errors[key] = 'At least 8 characters, including a number.';
      return null;
    }
    if (v.length > 128) {
      errors[key] = 'Must be 128 characters or fewer.';
      return null;
    }
    return v;
  }

  int? integer(String key, {bool required = false, int? min, int? max}) {
    final v = raw[key];
    if (v == null) {
      if (required) errors[key] = 'This field is required.';
      return null;
    }
    if (v is! int) {
      errors[key] = 'Must be a whole number.';
      return null;
    }
    if (min != null && v < min) {
      errors[key] = 'Must be $min or more.';
      return null;
    }
    if (max != null && v > max) {
      errors[key] = 'Must be $max or less.';
      return null;
    }
    return v;
  }

  double? number(String key, {bool required = false, num? min, num? max}) {
    final v = raw[key];
    if (v == null) {
      if (required) errors[key] = 'This field is required.';
      return null;
    }
    if (v is! num) {
      errors[key] = 'Must be a number.';
      return null;
    }
    if ((min != null && v < min) || (max != null && v > max)) {
      errors[key] = 'Must be between $min and $max.';
      return null;
    }
    return v.toDouble();
  }

  bool? boolean(String key, {bool required = false}) {
    final v = raw[key];
    if (v == null) {
      if (required) errors[key] = 'This field is required.';
      return null;
    }
    if (v is! bool) {
      errors[key] = 'Must be true or false.';
      return null;
    }
    return v;
  }

  List<String>? strings(String key, {bool required = false, int? maxItems}) {
    final v = raw[key];
    if (v == null) {
      if (required) errors[key] = 'This field is required.';
      return null;
    }
    if (v is! List || v.any((e) => e is! String)) {
      errors[key] = 'Must be a list of text values.';
      return null;
    }
    if (maxItems != null && v.length > maxItems) {
      errors[key] = 'Must have $maxItems items or fewer.';
      return null;
    }
    return v.cast<String>().map((e) => e.trim()).toSet().toList();
  }

  Map<String, dynamic>? object(String key, {bool required = false}) {
    final v = raw[key];
    if (v == null) {
      if (required) errors[key] = 'This field is required.';
      return null;
    }
    if (v is! Map<String, dynamic>) {
      errors[key] = 'Must be an object.';
      return null;
    }
    return v;
  }

  void fail(String key, String message) => errors[key] = message;

  /// Throws a 422 with every collected field error.
  void validate() {
    if (errors.isNotEmpty) throw ApiException.validation(Map.of(errors));
  }
}

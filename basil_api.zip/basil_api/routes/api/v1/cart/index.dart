import 'package:basil_api/basil_api.dart';
import 'package:dart_frog/dart_frog.dart';

/// /api/v1/cart — "Your cart" / "Good things in the bag." / checkout summary.
///
/// The cart starts with the user's default address and payment method; the
/// `pricing` block is the payment summary and `blockers` lists anything that
/// stops checkout.
Future<Response> onRequest(RequestContext context) => handle(context, {
      HttpMethod.get: () {
        final user = context.user;
        final carts = CartService(context.store);
        return ok(carts.toJson(context.store.cartOf(user.id)));
      },
      // Empty the bag.
      HttpMethod.delete: () {
        final user = context.user;
        final cart = context.store.cartOf(user.id)..clearItems();
        return ok(CartService(context.store).toJson(cart));
      },
    });

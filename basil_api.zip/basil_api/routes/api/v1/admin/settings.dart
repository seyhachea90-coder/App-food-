import 'package:basil_api/basil_api.dart';
import 'package:dart_frog/dart_frog.dart';

/// /api/v1/admin/settings — platform fees (service fee, tax rate).
Future<Response> onRequest(RequestContext context) => handle(context, {
      HttpMethod.get: () => ok(context.store.settings.toJson()),
      HttpMethod.patch: () async {
        final settings = context.store.settings;
        final body = await Body.parse(context);
        final fee = body.integer('serviceFeeCents', min: 0, max: 2000);
        final tax = body.number('taxRate', min: 0, max: 0.25);
        body.validate();
        if (fee != null) settings.serviceFeeCents = fee;
        if (tax != null) settings.taxRate = tax;
        return ok(settings.toJson());
      },
    });

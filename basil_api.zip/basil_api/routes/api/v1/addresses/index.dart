import 'package:basil_api/basil_api.dart';
import 'package:basil_api/src/http/address_input.dart';
import 'package:dart_frog/dart_frog.dart';

/// /api/v1/addresses — "Saved addresses", "Add address".
Future<Response> onRequest(RequestContext context) => handle(context, {
      HttpMethod.get: () {
        final list = context.store.addressesOf(context.user.id);
        return ok(list.map((a) => a.toJson()).toList(), meta: {'total': list.length});
      },
      HttpMethod.post: () async {
        final user = context.user;
        final store = context.store;
        final input = AddressInput.read(await Body.parse(context), partial: false);
        if (store.addressesOf(user.id).length >= 20) {
          throw ApiException.unprocessable('ADDRESS_LIMIT', 'You can save up to 20 addresses.');
        }
        final address = Address(
          id: newId('addr'),
          userId: user.id,
          label: input.label!,
          street: input.street!,
          city: input.city!,
          state: input.state!.toUpperCase(),
          zip: input.zip!,
        );
        input.applyTo(address);
        final isFirst = store.addressesOf(user.id).isEmpty;
        if (isFirst || (input.isDefault ?? false)) {
          for (final a in store.addressesOf(user.id)) {
            a.isDefault = false;
          }
          address.isDefault = true;
        }
        store.addresses[address.id] = address;
        return created(address.toJson());
      },
    });

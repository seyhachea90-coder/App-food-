import '../models/models.dart';
import '../security/crypto.dart';
import '../services/pricing.dart';
import 'store.dart';

/// Demo accounts (also documented in README and the Postman environment).
abstract final class DemoAccounts {
  static const customerEmail = 'dara@example.com';
  static const customerPassword = 'Basil1234';
  static const adminEmail = 'admin@basil.app';
  static const adminPassword = 'Admin1234';
}

String _img(String text) =>
    'https://placehold.co/600x400/D9534F/FFFFFF?text=${Uri.encodeComponent(text)}';

DishOption _regular([String? description]) => DishOption(
      id: 'regular',
      name: 'Regular',
      description: description,
      priceDeltaCents: 0,
    );

const _weekdays = [1, 2, 3, 4, 5, 6, 7];

/// Seeds data that mirrors the content shown in the Basil Figma design.
void seedStore(Store s) {
  final now = DateTime.now();

  // ---------------- Users ----------------
  User user(String id, String name, String email, String password, {UserRole role = UserRole.customer}) {
    final u = User(
      id: id,
      fullName: name,
      email: email,
      passwordHash: hashPassword(password),
      role: role,
      emailVerified: true,
      createdAt: DateTime.utc(2026, 9),
    );
    s.users[id] = u;
    return u;
  }

  final dara = user('usr_dara', 'Dara Sok', DemoAccounts.customerEmail, DemoAccounts.customerPassword)
    ..recentSearches.addAll(['Pizza', 'Verde Kitchen', 'Burrata']);
  user('usr_admin', 'Vannak Chea', DemoAccounts.adminEmail, DemoAccounts.adminPassword, role: UserRole.admin);
  final sokha = user('usr_sokha', 'Sokha Chan', 'sokha@example.com', 'Sokha1234');
  final chanthy = user('usr_chanthy', 'Chanthy Keo', 'chanthy@example.com', 'Chanthy1234');
  final rithy = user('usr_rithy', 'Rithy Meas', 'rithy@example.com', 'Rithy1234');

  // ---------------- Categories ----------------
  for (final c in [
    ('cat_pizza', 'Pizza'),
    ('cat_burgers', 'Burgers'),
    ('cat_healthy', 'Healthy'),
    ('cat_mexican', 'Mexican'),
    ('cat_italian', 'Italian'),
    ('cat_breakfast', 'Breakfast'),
  ]) {
    s.categories.add(Category(id: c.$1, name: c.$2, imageUrl: _img(c.$2)));
  }

  // ---------------- Restaurants ----------------
  const standardHours = [
    OpeningHours('Monday–Thursday', [1, 2, 3, 4], '11:00', '22:00'),
    OpeningHours('Friday–Saturday', [5, 6], '11:00', '23:00'),
    OpeningHours('Sunday', [7], '12:00', '22:00'),
  ];

  void restaurant(Restaurant r) => s.restaurants[r.id] = r;

  restaurant(
    Restaurant(
      id: 'rest_little_napoli',
      name: 'Little Napoli',
      cuisines: ['Pizza', 'Italian'],
      categoryIds: ['cat_pizza', 'cat_italian', 'cat_healthy'],
      neighborhood: 'Williamsburg',
      tagline: 'A little taste of Italy, right around the corner. Seasonal ingredients, handmade favorites.',
      description:
          'From wood-fired pizza to creamy burrata, we bring the comfort of an Italian table to Williamsburg. Fresh, seasonal, always generous.',
      address: '184 Bedford Avenue, Brooklyn, NY 11211',
      phone: '+1 (718) 555-0142',
      lat: 40.7172,
      lng: -73.9577,
      ratingBreakdown: {5: 207, 4: 28, 3: 8, 2: 3, 1: 2},
      deliveryMinMinutes: 20,
      deliveryMaxMinutes: 30,
      deliveryFeeCents: 199,
      minOrderCents: 1000,
      priceLevel: 2,
      hours: standardHours,
      menuSections: ['Popular', 'Salads', 'Pizza', 'Pasta', 'Desserts'],
      imageUrl: _img('Little Napoli'),
      dietary: ['vegetarian'],
    ),
  );
  restaurant(
    Restaurant(
      id: 'rest_verde_kitchen',
      name: 'Verde Kitchen',
      cuisines: ['Mexican', 'Healthy'],
      categoryIds: ['cat_mexican', 'cat_healthy'],
      neighborhood: 'Greenpoint',
      tagline: 'Bright, fresh Mexican plates made with local produce.',
      description: 'Tacos, bowls and salsas made fresh every morning in Greenpoint.',
      address: '92 Franklin Street, Brooklyn, NY 11222',
      phone: '+1 (718) 555-0177',
      lat: 40.7262,
      lng: -73.9573,
      ratingBreakdown: {5: 280, 4: 26, 3: 4},
      deliveryMinMinutes: 15,
      deliveryMaxMinutes: 25,
      deliveryFeeCents: 0,
      minOrderCents: 1000,
      priceLevel: 2,
      hours: standardHours,
      menuSections: ['Popular', 'Tacos', 'Bowls', 'Sides'],
      imageUrl: _img('Verde Kitchen'),
      dietary: ['vegetarian', 'vegan', 'gluten_free'],
    ),
  );
  restaurant(
    Restaurant(
      id: 'rest_lolivo',
      name: 'L’Olivo',
      cuisines: ['Italian'],
      categoryIds: ['cat_italian', 'cat_pizza'],
      neighborhood: 'Williamsburg',
      tagline: 'Roman classics and slow Sunday sauces.',
      description: 'Handmade pasta and Roman-style pizza with a long, slow approach.',
      address: '250 Grand Street, Brooklyn, NY 11211',
      phone: '+1 (718) 555-0190',
      lat: 40.7137,
      lng: -73.9600,
      ratingBreakdown: {5: 140, 4: 34, 3: 8, 2: 2, 1: 2},
      deliveryMinMinutes: 25,
      deliveryMaxMinutes: 35,
      deliveryFeeCents: 249,
      minOrderCents: 1500,
      priceLevel: 3,
      hours: standardHours,
      menuSections: ['Popular', 'Pasta', 'Pizza'],
      imageUrl: _img('L’Olivo'),
      dietary: ['vegetarian'],
      offer: r'$5 off your first order',
    ),
  );
  restaurant(
    Restaurant(
      id: 'rest_bedford_pizza',
      name: 'Bedford Pizza Co.',
      cuisines: ['Pizza', 'Wood-fired'],
      categoryIds: ['cat_pizza'],
      neighborhood: 'Williamsburg',
      tagline: 'Wood-fired pies by the slice or the whole.',
      description: 'A neighborhood pizzeria with a 900°F oven and a soft spot for garlic knots.',
      address: '130 Bedford Avenue, Brooklyn, NY 11249',
      phone: '+1 (718) 555-0123',
      lat: 40.7190,
      lng: -73.9567,
      ratingBreakdown: {5: 230, 4: 70, 3: 16, 2: 5, 1: 3},
      deliveryMinMinutes: 15,
      deliveryMaxMinutes: 25,
      deliveryFeeCents: 0,
      minOrderCents: 1000,
      priceLevel: 1,
      hours: standardHours,
      menuSections: ['Popular', 'Pizza', 'Sides'],
      imageUrl: _img('Bedford Pizza Co.'),
      dietary: ['vegetarian'],
      badge: 'Neighborhood favorite',
    ),
  );
  restaurant(
    Restaurant(
      id: 'rest_kent_burger',
      name: 'Kent Ave Burger Bar',
      cuisines: ['Burgers', 'American'],
      categoryIds: ['cat_burgers'],
      neighborhood: 'Williamsburg',
      tagline: 'Smashed, stacked and sauced.',
      description: 'Smash burgers on potato buns with hand-cut fries.',
      address: '300 Kent Avenue, Brooklyn, NY 11249',
      phone: '+1 (718) 555-0155',
      lat: 40.7128,
      lng: -73.9680,
      ratingBreakdown: {5: 100, 4: 40, 3: 8, 2: 2, 1: 2},
      deliveryMinMinutes: 20,
      deliveryMaxMinutes: 35,
      deliveryFeeCents: 149,
      minOrderCents: 1000,
      priceLevel: 2,
      hours: standardHours,
      menuSections: ['Popular', 'Burgers', 'Sides'],
      imageUrl: _img('Kent Ave Burger Bar'),
      dietary: ['halal'],
    ),
  );
  restaurant(
    Restaurant(
      id: 'rest_sunrise_cafe',
      name: 'Sunrise Café',
      cuisines: ['Breakfast', 'Coffee'],
      categoryIds: ['cat_breakfast', 'cat_healthy'],
      neighborhood: 'Williamsburg',
      tagline: 'Good mornings, all day.',
      description: 'Breakfast plates, toasts and coffee from 7 am.',
      address: '45 N 6th Street, Brooklyn, NY 11249',
      phone: '+1 (718) 555-0111',
      lat: 40.7210,
      lng: -73.9610,
      ratingBreakdown: {5: 120, 4: 30, 3: 6},
      deliveryMinMinutes: 10,
      deliveryMaxMinutes: 20,
      deliveryFeeCents: 99,
      minOrderCents: 800,
      priceLevel: 1,
      hours: const [OpeningHours('Every day', _weekdays, '07:00', '16:00')],
      menuSections: ['Popular', 'Breakfast', 'Coffee'],
      imageUrl: _img('Sunrise Café'),
      dietary: ['vegetarian', 'vegan'],
    ),
  );
  restaurant(
    Restaurant(
      id: 'rest_green_bowl',
      name: 'Green Bowl Co.',
      cuisines: ['Healthy', 'Bowls'],
      categoryIds: ['cat_healthy'],
      neighborhood: 'Greenpoint',
      tagline: 'Big bowls, bright greens.',
      description: 'Grain bowls and poke built to order.',
      address: '15 Nassau Avenue, Brooklyn, NY 11222',
      phone: '+1 (718) 555-0166',
      lat: 40.7235,
      lng: -73.9510,
      ratingBreakdown: {5: 90, 4: 30, 3: 6, 2: 1},
      deliveryMinMinutes: 15,
      deliveryMaxMinutes: 25,
      deliveryFeeCents: 199,
      minOrderCents: 1000,
      priceLevel: 2,
      hours: standardHours,
      menuSections: ['Popular', 'Bowls'],
      imageUrl: _img('Green Bowl Co.'),
      dietary: ['vegan', 'gluten_free'],
    ),
  );

  // ---------------- Dishes ----------------
  void dish(Dish d) => s.dishes[d.id] = d;

  dish(
    Dish(
      id: 'dish_burrata_salad',
      restaurantId: 'rest_little_napoli',
      name: 'Burrata & heirloom salad',
      description: 'Heirloom tomatoes, basil, olive oil.',
      details:
          'Creamy burrata, sun-ripened heirloom tomatoes and fresh basil, finished with extra virgin olive oil.',
      priceCents: 1250,
      section: 'Salads',
      imageUrl: _img('Burrata salad'),
      isPopular: true,
      dietary: ['vegetarian'],
      tags: ['salad', 'burrata', 'healthy'],
      allergens: 'Contains milk · Bread add-on contains wheat',
      ratingBreakdown: {5: 76, 4: 8, 3: 2},
      sizes: [
        DishOption(id: 'regular', name: 'Regular', description: 'A light lunch · serves 1', priceDeltaCents: 0),
        DishOption(id: 'large', name: 'Large', description: 'A generous lunch · serves 1', priceDeltaCents: 300),
        DishOption(id: 'to_share', name: 'To share', description: 'For the table · serves 2', priceDeltaCents: 600),
      ],
      addOns: [
        DishOption(id: 'avocado', name: 'Avocado', description: 'Freshly sliced · per salad', priceDeltaCents: 200),
        DishOption(id: 'sourdough', name: 'Toasted sourdough', description: 'Two slices · per salad', priceDeltaCents: 150),
        DishOption(id: 'grilled_chicken', name: 'Grilled chicken', description: 'Herb-marinated · per salad', priceDeltaCents: 400),
        DishOption(id: 'pine_nuts', name: 'Toasted pine nuts', description: 'A little extra crunch · per salad', priceDeltaCents: 100),
      ],
    ),
  );
  dish(
    Dish(
      id: 'dish_burrata_margherita',
      restaurantId: 'rest_little_napoli',
      name: 'Burrata margherita',
      description: 'Wood-fired, tomato, basil, burrata.',
      priceCents: 1600,
      section: 'Pizza',
      imageUrl: _img('Burrata margherita'),
      isPopular: true,
      dietary: ['vegetarian'],
      tags: ['pizza', 'wood-fired', 'burrata'],
      allergens: 'Contains milk and wheat',
      ratingBreakdown: {5: 50, 4: 10},
      sizes: [
        DishOption(id: 'regular', name: '12-inch', priceDeltaCents: 0),
        DishOption(id: 'large', name: '16-inch', priceDeltaCents: 600),
      ],
      addOns: [
        DishOption(id: 'extra_burrata', name: 'Extra burrata', priceDeltaCents: 300),
        DishOption(id: 'spicy_salami', name: 'Spicy salami', priceDeltaCents: 250),
      ],
    ),
  );
  dish(
    Dish(
      id: 'dish_rigatoni',
      restaurantId: 'rest_little_napoli',
      name: 'Rigatoni al pomodoro',
      description: 'Slow-cooked tomato, basil, burrata.',
      priceCents: 1750,
      section: 'Pasta',
      imageUrl: _img('Rigatoni'),
      isPopular: true,
      dietary: ['vegetarian'],
      tags: ['pasta'],
      allergens: 'Contains milk and wheat',
      ratingBreakdown: {5: 40, 4: 6},
      sizes: [_regular()],
      addOns: [DishOption(id: 'extra_burrata', name: 'Extra burrata', priceDeltaCents: 300)],
    ),
  );
  dish(
    Dish(
      id: 'dish_burrata_pasta',
      restaurantId: 'rest_little_napoli',
      name: 'Burrata pasta',
      description: 'Spaghetti, cherry tomatoes, burrata, basil.',
      priceCents: 1400,
      section: 'Pasta',
      imageUrl: _img('Burrata pasta'),
      dietary: ['vegetarian'],
      tags: ['pasta', 'burrata'],
      ratingBreakdown: {5: 30, 4: 5},
      sizes: [_regular()],
    ),
  );
  dish(
    Dish(
      id: 'dish_tiramisu',
      restaurantId: 'rest_little_napoli',
      name: 'Tiramisu',
      description: 'Espresso-soaked ladyfingers, mascarpone, cocoa.',
      priceCents: 800,
      section: 'Desserts',
      imageUrl: _img('Tiramisu'),
      dietary: ['vegetarian'],
      tags: ['dessert'],
      ratingBreakdown: {5: 25, 4: 4},
      sizes: [_regular()],
    ),
  );
  dish(
    Dish(
      id: 'dish_tacos_pastor',
      restaurantId: 'rest_verde_kitchen',
      name: 'Tacos al pastor',
      description: 'Three tacos, marinated pork, pineapple, salsa verde.',
      priceCents: 1150,
      section: 'Tacos',
      imageUrl: _img('Tacos al pastor'),
      isPopular: true,
      tags: ['tacos', 'mexican'],
      ratingBreakdown: {5: 60, 4: 8},
      sizes: [_regular('Three tacos'), DishOption(id: 'large', name: 'Five tacos', priceDeltaCents: 600)],
      addOns: [DishOption(id: 'guacamole', name: 'Guacamole', priceDeltaCents: 250)],
    ),
  );
  dish(
    Dish(
      id: 'dish_green_goddess_bowl',
      restaurantId: 'rest_verde_kitchen',
      name: 'Green goddess bowl',
      description: 'Black beans, rice, greens, pickled onion, avocado.',
      priceCents: 1350,
      section: 'Bowls',
      imageUrl: _img('Green goddess bowl'),
      isPopular: true,
      dietary: ['vegan', 'gluten_free'],
      tags: ['healthy bowls', 'bowl', 'healthy'],
      ratingBreakdown: {5: 44, 4: 5},
      sizes: [_regular()],
      addOns: [DishOption(id: 'chicken', name: 'Grilled chicken', priceDeltaCents: 400)],
    ),
  );
  dish(
    Dish(
      id: 'dish_chips_guac',
      restaurantId: 'rest_verde_kitchen',
      name: 'Chips & guacamole',
      description: 'Warm tortilla chips, fresh guacamole.',
      priceCents: 700,
      section: 'Sides',
      imageUrl: _img('Chips & guac'),
      dietary: ['vegan', 'gluten_free'],
      tags: ['snack', r'under $15'],
      sizes: [_regular()],
    ),
  );
  dish(
    Dish(
      id: 'dish_cacio_pepe',
      restaurantId: 'rest_lolivo',
      name: 'Cacio e pepe',
      description: 'Tonnarelli, pecorino romano, black pepper.',
      priceCents: 1800,
      section: 'Pasta',
      imageUrl: _img('Cacio e pepe'),
      isPopular: true,
      dietary: ['vegetarian'],
      tags: ['pasta'],
      sizes: [_regular()],
    ),
  );
  dish(
    Dish(
      id: 'dish_lolivo_margherita',
      restaurantId: 'rest_lolivo',
      name: 'Roman margherita',
      description: 'Thin, crisp, wood-fired.',
      priceCents: 1500,
      section: 'Pizza',
      imageUrl: _img('Roman margherita'),
      dietary: ['vegetarian'],
      tags: ['pizza', 'wood-fired'],
      sizes: [_regular()],
    ),
  );
  dish(
    Dish(
      id: 'dish_wood_fired_pizza',
      restaurantId: 'rest_bedford_pizza',
      name: 'Wood-fired pizza',
      description: 'San Marzano tomato, fior di latte, basil.',
      priceCents: 1250,
      section: 'Pizza',
      imageUrl: _img('Wood-fired pizza'),
      isPopular: true,
      dietary: ['vegetarian'],
      tags: ['pizza', 'wood-fired', r'under $15'],
      ratingBreakdown: {5: 80, 4: 20},
      sizes: [_regular('12-inch'), DishOption(id: 'large', name: '16-inch', priceDeltaCents: 500)],
      addOns: [DishOption(id: 'pepperoni', name: 'Pepperoni', priceDeltaCents: 250)],
    ),
  );
  dish(
    Dish(
      id: 'dish_pepperoni_pie',
      restaurantId: 'rest_bedford_pizza',
      name: 'Pepperoni pie',
      description: 'Cup-and-char pepperoni, hot honey.',
      priceCents: 1499,
      section: 'Pizza',
      imageUrl: _img('Pepperoni pie'),
      isPopular: true,
      tags: ['pizza', 'wood-fired', r'under $15'],
      sizes: [_regular('12-inch'), DishOption(id: 'large', name: '16-inch', priceDeltaCents: 500)],
    ),
  );
  dish(
    Dish(
      id: 'dish_garlic_knots',
      restaurantId: 'rest_bedford_pizza',
      name: 'Garlic knots',
      description: 'Six knots, garlic butter, parmesan.',
      priceCents: 650,
      section: 'Sides',
      imageUrl: _img('Garlic knots'),
      dietary: ['vegetarian'],
      tags: [r'under $15'],
      sizes: [_regular()],
    ),
  );
  dish(
    Dish(
      id: 'dish_smash_burger',
      restaurantId: 'rest_kent_burger',
      name: 'Classic smash burger',
      description: 'Two patties, American cheese, pickles, house sauce.',
      priceCents: 1300,
      section: 'Burgers',
      imageUrl: _img('Smash burger'),
      isPopular: true,
      tags: ['burger', r'under $15'],
      sizes: [_regular('Double'), DishOption(id: 'large', name: 'Triple', priceDeltaCents: 300)],
      addOns: [DishOption(id: 'bacon', name: 'Bacon', priceDeltaCents: 200)],
    ),
  );
  dish(
    Dish(
      id: 'dish_truffle_fries',
      restaurantId: 'rest_kent_burger',
      name: 'Truffle fries',
      description: 'Hand-cut fries, truffle salt, parmesan.',
      priceCents: 700,
      section: 'Sides',
      imageUrl: _img('Truffle fries'),
      dietary: ['vegetarian'],
      tags: ['fries'],
      sizes: [_regular()],
    ),
  );
  dish(
    Dish(
      id: 'dish_avocado_toast',
      restaurantId: 'rest_sunrise_cafe',
      name: 'Avocado toast',
      description: 'Sourdough, smashed avocado, chili, lemon.',
      priceCents: 1100,
      section: 'Breakfast',
      imageUrl: _img('Avocado toast'),
      isPopular: true,
      dietary: ['vegan'],
      tags: ['breakfast', 'healthy', r'under $15'],
      sizes: [_regular()],
      addOns: [DishOption(id: 'egg', name: 'Poached egg', priceDeltaCents: 200)],
    ),
  );
  dish(
    Dish(
      id: 'dish_oat_latte',
      restaurantId: 'rest_sunrise_cafe',
      name: 'Oat milk latte',
      description: 'Double shot, oat milk.',
      priceCents: 550,
      section: 'Coffee',
      imageUrl: _img('Oat milk latte'),
      dietary: ['vegan'],
      tags: ['coffee'],
      sizes: [_regular('12 oz'), DishOption(id: 'large', name: '16 oz', priceDeltaCents: 100)],
    ),
  );
  dish(
    Dish(
      id: 'dish_harvest_bowl',
      restaurantId: 'rest_green_bowl',
      name: 'Harvest bowl',
      description: 'Farro, roasted squash, kale, tahini.',
      priceCents: 1450,
      section: 'Bowls',
      imageUrl: _img('Harvest bowl'),
      isPopular: true,
      dietary: ['vegan'],
      tags: ['healthy bowls', 'bowl', 'healthy', r'under $15'],
      sizes: [_regular()],
    ),
  );
  dish(
    Dish(
      id: 'dish_salmon_poke',
      restaurantId: 'rest_green_bowl',
      name: 'Salmon poke bowl',
      description: 'Sushi rice, salmon, edamame, cucumber, sesame.',
      priceCents: 1695,
      section: 'Bowls',
      imageUrl: _img('Salmon poke'),
      dietary: ['gluten_free'],
      tags: ['healthy bowls', 'bowl', 'healthy'],
      sizes: [_regular()],
    ),
  );

  // ---------------- Couriers ----------------
  s.couriers['cour_sophal'] = Courier(
    id: 'cour_sophal',
    name: 'Sophal L.',
    vehicle: 'Bicycle',
    rating: 4.9,
    deliveries: 1240,
    proxyPhone: '+1 (718) 555-0199',
  );

  // ---------------- Addresses & payment methods ----------------
  final home = Address(
    id: 'addr_home',
    userId: dara.id,
    label: 'home',
    street: '120 Bedford Avenue',
    apt: 'Apt 4B',
    city: 'Brooklyn',
    state: 'NY',
    zip: '11249',
    instructions: 'Ring buzzer 4B. Take the stairs.',
    lat: 40.7196,
    lng: -73.9566,
    isDefault: true,
  );
  s.addresses[home.id] = home;
  s.addresses['addr_work'] = Address(
    id: 'addr_work',
    userId: dara.id,
    label: 'work',
    street: '55 Water Street',
    apt: 'Floor 6',
    city: 'Brooklyn',
    state: 'NY',
    zip: '11201',
    instructions: 'Meet at the lobby.',
    lat: 40.7033,
    lng: -73.9903,
  );
  final sokhaHome = Address(
    id: 'addr_sokha_home',
    userId: sokha.id,
    label: 'home',
    street: '200 Kent Avenue',
    apt: 'Apt 2C',
    city: 'Brooklyn',
    state: 'NY',
    zip: '11249',
    lat: 40.7155,
    lng: -73.9650,
    isDefault: true,
  );
  s.addresses[sokhaHome.id] = sokhaHome;

  final visa = PaymentMethod(
    id: 'pm_visa_4242',
    userId: dara.id,
    type: 'card',
    brand: 'visa',
    last4: '4242',
    expMonth: 8,
    expYear: 2028,
    holderName: 'Dara Sok',
    isDefault: true,
  );
  s.paymentMethods[visa.id] = visa;
  s.paymentMethods['pm_mc_8319'] = PaymentMethod(
    id: 'pm_mc_8319',
    userId: dara.id,
    type: 'card',
    brand: 'mastercard',
    last4: '8319',
    expMonth: 11,
    expYear: 2027,
    holderName: 'Dara Sok',
  );
  final sokhaCard = PaymentMethod(
    id: 'pm_sokha_visa',
    userId: sokha.id,
    type: 'card',
    brand: 'visa',
    last4: '1881',
    expMonth: 3,
    expYear: 2029,
    holderName: 'Sokha Chan',
    isDefault: true,
  );
  s.paymentMethods[sokhaCard.id] = sokhaCard;

  // ---------------- Coupons ----------------
  final designExpiry = DateTime(2026, 11, 30, 23, 59, 59);
  final minExpiry = now.add(const Duration(days: 30));
  final validUntil = designExpiry.isAfter(minExpiry) ? designExpiry : minExpiry;
  for (final c in [
    Coupon(
      code: 'BASIL10',
      title: '10% off food',
      type: CouponType.percentOff,
      value: 10,
      minSubtotalCents: 2500,
      maxDiscountCents: 500,
      validUntil: validUntil,
    ),
    Coupon(
      code: 'DELIVERJOY',
      title: 'Free delivery',
      type: CouponType.freeDelivery,
      value: 0,
      minSubtotalCents: 3000,
      maxDiscountCents: 199,
      validUntil: validUntil,
    ),
    Coupon(
      code: 'LUNCH5',
      title: r'$5 off food',
      type: CouponType.amountOff,
      value: 500,
      minSubtotalCents: 5000,
      restaurantId: 'rest_little_napoli',
      validUntil: validUntil,
    ),
  ]) {
    s.coupons[c.code] = c;
  }

  // ---------------- Past orders ----------------
  OrderItem item(String dishId, int qty, {String size = 'regular', List<String> addOns = const [], String? note}) {
    final d = s.dishes[dishId]!;
    final sz = d.sizeById(size)!;
    return OrderItem(
      dishId: d.id,
      name: d.name,
      imageUrl: d.imageUrl,
      basePriceCents: d.priceCents,
      size: {'id': sz.id, 'name': sz.name, 'priceDeltaCents': sz.priceDeltaCents},
      addOns: [
        for (final id in addOns)
          {'id': id, 'name': d.addOnById(id)!.name, 'priceDeltaCents': d.addOnById(id)!.priceDeltaCents},
      ],
      quantity: qty,
      note: note,
    );
  }

  Order order({
    required String number,
    required User customer,
    required String restaurantId,
    required List<OrderItem> items,
    required Address address,
    required PaymentMethod payment,
    required DateTime placedAt,
    required OrderStatus status,
    String? promo,
  }) {
    final r = s.restaurants[restaurantId]!;
    final quote = computeQuote(
      restaurant: r,
      subtotalCents: items.fold(0, (sum, i) => sum + i.totalCents),
      itemCount: items.fold(0, (sum, i) => sum + i.quantity),
      settings: s.settings,
      coupon: promo == null ? null : s.coupons[promo],
    );
    final o = Order(
      id: 'ord_${number.toLowerCase().replaceAll('-', '_')}',
      number: number,
      userId: customer.id,
      customerName: customer.fullName,
      restaurantId: r.id,
      restaurantName: r.name,
      items: items,
      quote: quote,
      address: {'addressId': address.id, ...address.toJson()},
      schedule: const DeliverySchedule.asap(),
      payment: payment.toSnapshot(),
      createdAt: placedAt.toUtc(),
      status: status,
    )..dropoffNote = address.instructions;
    o.events.add(OrderEvent(OrderStatus.confirmed, 'Order accepted', 'Accepted by the kitchen.', placedAt));
    if (status != OrderStatus.confirmed) {
      o.courierId = 'cour_sophal';
      o.events.add(
        OrderEvent(OrderStatus.preparing, 'Preparing your order', 'Made fresh by ${r.name}.', placedAt.add(const Duration(minutes: 2))),
      );
    }
    if (status == OrderStatus.delivered) {
      o
        ..pickedUpAt = placedAt.add(const Duration(minutes: 15))
        ..deliveredAt = placedAt.add(const Duration(minutes: 27));
      o.events
        ..add(OrderEvent(OrderStatus.onTheWay, 'Picked up', 'Sophal picked up your order.', o.pickedUpAt!))
        ..add(OrderEvent(OrderStatus.delivered, 'Delivered', 'Handed to ${customer.firstName} by Sophal L.', o.deliveredAt!));
    }
    s.orders[o.id] = o;
    return o;
  }

  order(
    number: 'BSL-1012',
    customer: dara,
    restaurantId: 'rest_verde_kitchen',
    items: [item('dish_tacos_pastor', 1), item('dish_green_goddess_bowl', 1)],
    address: home,
    payment: visa,
    placedAt: DateTime(2026, 10, 29, 12, 10),
    status: OrderStatus.delivered,
  );
  order(
    number: 'BSL-0986',
    customer: dara,
    restaurantId: 'rest_bedford_pizza',
    items: [item('dish_pepperoni_pie', 1)],
    address: home,
    payment: visa,
    placedAt: DateTime(2026, 10, 24, 19, 5),
    status: OrderStatus.delivered,
  );
  order(
    number: 'BSL-1031',
    customer: sokha,
    restaurantId: 'rest_little_napoli',
    items: [item('dish_burrata_pasta', 2), item('dish_tiramisu', 1)],
    address: sokhaHome,
    payment: sokhaCard,
    placedAt: now.subtract(const Duration(hours: 2)),
    status: OrderStatus.delivered,
  );
  order(
    number: 'BSL-1034',
    customer: sokha,
    restaurantId: 'rest_kent_burger',
    items: [item('dish_smash_burger', 1), item('dish_truffle_fries', 1)],
    address: sokhaHome,
    payment: sokhaCard,
    placedAt: now.subtract(const Duration(minutes: 10)),
    status: OrderStatus.preparing,
  );

  // ---------------- Reviews ----------------
  s.reviews.addAll([
    Review(
      id: 'rev_chanthy',
      target: 'restaurant',
      userId: chanthy.id,
      authorName: chanthy.publicName,
      restaurantId: 'rest_little_napoli',
      dishId: 'dish_burrata_salad',
      orderedItem: 'Burrata & heirloom salad',
      rating: 5,
      comment: 'The burrata was so creamy and the tomatoes tasted like summer. Loved the sourdough on the side!',
      photoUrls: [_img('Chanthy photo')],
      createdAt: DateTime.utc(2026, 10, 30, 18),
    ),
    Review(
      id: 'rev_rithy',
      target: 'restaurant',
      userId: rithy.id,
      authorName: rithy.publicName,
      restaurantId: 'rest_little_napoli',
      dishId: 'dish_burrata_salad',
      orderedItem: 'Burrata & heirloom salad',
      rating: 4,
      comment: 'Fresh ingredients and a generous large salad. Arrived in 25 minutes. A little more basil next time!',
      createdAt: DateTime.utc(2026, 10, 28, 13),
    ),
    Review(
      id: 'rev_sokha',
      target: 'dish',
      userId: sokha.id,
      authorName: sokha.publicName,
      restaurantId: 'rest_little_napoli',
      dishId: 'dish_burrata_salad',
      orderedItem: 'Burrata & heirloom salad',
      rating: 5,
      tags: ['fresh', 'great_portion'],
      comment: 'Perfect lunch. The large size is worth it.',
      createdAt: DateTime.utc(2026, 10, 20, 12),
    ),
  ]);

  // ---------------- Favorites ----------------
  final created = DateTime.utc(2026, 10, 30);
  for (final f in [
    Favorite(id: 'fav_napoli', userId: dara.id, type: 'restaurant', restaurantId: 'rest_little_napoli', createdAt: created),
    Favorite(id: 'fav_verde', userId: dara.id, type: 'restaurant', restaurantId: 'rest_verde_kitchen', createdAt: created),
    Favorite(
      id: 'fav_burrata',
      userId: dara.id,
      type: 'dish',
      restaurantId: 'rest_little_napoli',
      dishId: 'dish_burrata_salad',
      createdAt: created,
    ),
    Favorite(
      id: 'fav_burrata_custom',
      userId: dara.id,
      type: 'dish',
      restaurantId: 'rest_little_napoli',
      dishId: 'dish_burrata_salad',
      sizeId: 'large',
      addOnIds: ['avocado', 'sourdough'],
      note: 'Dressing on the side, please.',
      createdAt: created.add(const Duration(minutes: 1)),
    ),
  ]) {
    s.favorites[f.id] = f;
  }

  // ---------------- Notifications ----------------
  s.notifications.add(
    AppNotification(
      id: 'ntf_welcome_favorites',
      userId: dara.id,
      type: 'favorites',
      title: 'Your favorites, close by',
      body: 'Little Napoli and Verde Kitchen are saved for your next good-food moment.',
      createdAt: DateTime(2026, 11, 2, 18, 15).toUtc(),
      readAt: DateTime(2026, 11, 2, 19).toUtc(),
    ),
  );

  // ---------------- Address search (mock geocoder) ----------------
  s.places.addAll(const [
    Place('plc_120_bedford', '120 Bedford Avenue', 'Brooklyn', 'NY', '11249', 40.7196, -73.9566, null),
    Place('plc_130_bedford', '130 Bedford Avenue', 'Brooklyn', 'NY', '11249', 40.7190, -73.9567, null),
    Place('plc_184_bedford', '184 Bedford Avenue', 'Brooklyn', 'NY', '11211', 40.7172, -73.9577, null),
    Place('plc_68_jay', '68 Jay Street', 'Brooklyn', 'NY', '11201', 40.7025, -73.9866, null),
    Place('plc_55_water', '55 Water Street', 'Brooklyn', 'NY', '11201', 40.7033, -73.9903, null),
    Place('plc_mccarren', '776 Lorimer Street', 'Brooklyn', 'NY', '11222', 40.7208, -73.9520, 'McCarren Park'),
    Place('plc_200_kent', '200 Kent Avenue', 'Brooklyn', 'NY', '11249', 40.7155, -73.9650, null),
    Place('plc_45_n6th', '45 N 6th Street', 'Brooklyn', 'NY', '11249', 40.7210, -73.9610, null),
  ]);

  // ---------------- Search & help content ----------------
  s.trendingSearches.addAll(['Wood-fired pizza', 'Healthy bowls', 'Tacos', 'Coffee', r'Under $15']);

  s.faqs.addAll(const [
    FaqEntry('faq_receipt', 'orders_delivery', 'Where can I find my receipt?',
        'Open Your orders, choose an order, then tap Download receipt in order details.'),
    FaqEntry('faq_missing', 'orders_delivery', 'Something missing from my order?',
        'Open the order, tap Get help with this order and tell us what was missing. We will make it right.'),
    FaqEntry('faq_track', 'orders_delivery', 'How do I track my courier?',
        'Open the order and tap Open live tracking to see your courier on the map.'),
    FaqEntry('faq_charge', 'payments', 'When am I charged?',
        'You are charged when you place your order. Adding a payment method never charges you.'),
    FaqEntry('faq_refund', 'payments', 'How do refunds work?',
        'Refunds go back to the original payment method within 5–10 business days.'),
    FaqEntry('faq_delete', 'account', 'How do I delete my account?',
        'Go to Settings → Account & security → Delete account. Deletion is permanent.'),
    FaqEntry('faq_password', 'account', 'I forgot my password.',
        'On the sign-in screen tap Forgot password? and we will email you a reset link.'),
    FaqEntry('faq_promo', 'offers_credits', 'Can I combine promo codes?',
        'One coupon per order. Applying another offer replaces the current one.'),
  ]);
}

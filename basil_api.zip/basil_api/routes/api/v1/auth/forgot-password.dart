import 'package:basil_api/basil_api.dart';
import 'package:dart_frog/dart_frog.dart';

/// POST /api/v1/auth/forgot-password — "Forgot your password?" (Send reset link)
///
/// Always answers the same way so nobody can probe which emails have accounts.
/// No email service is wired up yet: outside production the reset token is
/// returned as `devResetToken` so the flow can be tested.
Future<Response> onRequest(RequestContext context) => handle(context, {
      HttpMethod.post: () async {
        final body = await Body.parse(context);
        final email = body.email('email', required: true);
        body.validate();

        final store = context.store;
        final user = store.userByEmail(email!);
        String? token;
        if (user != null) {
          store.resetTokens.removeWhere((_, t) => t.userId == user.id);
          token = randomToken(32);
          store.resetTokens[token] = ResetTicket(
            user.id,
            DateTime.now().toUtc().add(Config.resetTokenTtl),
          );
          // TODO: email a deep link (basil://reset-password?token=...) here.
        }
        return ok({
          'message': 'If an account exists for $email, we sent a link to reset the password.',
          if (!Config.isProduction && token != null) 'devResetToken': token,
        });
      },
    });

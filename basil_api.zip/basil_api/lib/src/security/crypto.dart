import 'dart:convert';
import 'dart:math';

import 'package:crypto/crypto.dart';

final _rng = Random.secure();

/// URL-safe random token (refresh tokens, reset tokens).
String randomToken([int bytes = 24]) => base64Url
    .encode(List<int>.generate(bytes, (_) => _rng.nextInt(256)))
    .replaceAll('=', '');

/// Short prefixed id, e.g. `ord_3f9a1c0b2d4e`.
String newId(String prefix) =>
    '${prefix}_${List.generate(12, (_) => _rng.nextInt(16).toRadixString(16)).join()}';

String iso(DateTime d) => d.toUtc().toIso8601String();

bool constantTimeEquals(String a, String b) {
  if (a.length != b.length) return false;
  var result = 0;
  for (var i = 0; i < a.length; i++) {
    result |= a.codeUnitAt(i) ^ b.codeUnitAt(i);
  }
  return result == 0;
}

/// Salted, iterated HMAC-SHA256 password hash stored as `salt$hash`.
///
/// Fine for this in-memory server. For production use a dedicated password
/// hashing algorithm such as Argon2id or bcrypt.
String hashPassword(String password, {String? salt}) {
  final s = salt ?? randomToken(16);
  final hmac = Hmac(sha256, utf8.encode(s));
  List<int> digest = utf8.encode('$s:$password');
  for (var i = 0; i < 10000; i++) {
    digest = hmac.convert(digest).bytes;
  }
  return '$s\$${base64Url.encode(digest)}';
}

bool verifyPassword(String password, String stored) {
  final i = stored.indexOf(r'$');
  if (i <= 0) return false;
  return constantTimeEquals(
    hashPassword(password, salt: stored.substring(0, i)),
    stored,
  );
}

/// Minimal HS256 JSON Web Token signer/verifier.
class JwtService {
  JwtService(String secret) : _key = utf8.encode(secret);

  final List<int> _key;

  String _b64(List<int> bytes) => base64Url.encode(bytes).replaceAll('=', '');

  String _signature(String input) =>
      _b64(Hmac(sha256, _key).convert(utf8.encode(input)).bytes);

  String sign(Map<String, dynamic> claims, Duration ttl) {
    final now = DateTime.now().toUtc().millisecondsSinceEpoch ~/ 1000;
    final header = _b64(utf8.encode(jsonEncode({'alg': 'HS256', 'typ': 'JWT'})));
    final payload = _b64(
      utf8.encode(
        jsonEncode({...claims, 'iat': now, 'exp': now + ttl.inSeconds}),
      ),
    );
    return '$header.$payload.${_signature('$header.$payload')}';
  }

  /// Returns the claims, or null when the token is malformed, tampered with or
  /// expired.
  Map<String, dynamic>? verify(String token) {
    final parts = token.split('.');
    if (parts.length != 3) return null;
    if (!constantTimeEquals(_signature('${parts[0]}.${parts[1]}'), parts[2])) {
      return null;
    }
    try {
      final claims = jsonDecode(
        utf8.decode(base64Url.decode(base64Url.normalize(parts[1]))),
      );
      if (claims is! Map<String, dynamic>) return null;
      final exp = claims['exp'];
      final now = DateTime.now().toUtc().millisecondsSinceEpoch ~/ 1000;
      if (exp is! int || exp <= now) return null;
      return claims;
    } on Object {
      return null;
    }
  }
}

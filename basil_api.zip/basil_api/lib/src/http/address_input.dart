import '../models/models.dart';
import 'request.dart';

final _zip = RegExp(r'^\d{5}(-\d{4})?$');
final _state = RegExp(r'^[A-Za-z]{2}$');

/// Validated fields from the "Add address" form. Null = not sent.
class AddressInput {
  AddressInput._(this.body, {required this.partial});

  /// Reads and validates the body. With [partial] (PATCH) every field is
  /// optional; otherwise street/city/state/zip are required.
  factory AddressInput.read(Body body, {required bool partial}) {
    final input = AddressInput._(body, partial: partial)
      ..label = body.string('label', required: !partial, oneOf: Address.labels)
      ..customLabel = body.string('customLabel', max: 30)
      ..street = body.string('street', required: !partial, max: 120)
      ..apt = body.string('apt', max: 40)
      ..city = body.string('city', required: !partial, max: 60)
      ..state = body.string('state', required: !partial)
      ..zip = body.string('zip', required: !partial)
      ..instructions = body.string('instructions', max: 250)
      ..dropoff = body.string('dropoff', oneOf: Address.dropoffs)
      ..lat = body.number('lat', min: -90, max: 90)
      ..lng = body.number('lng', min: -180, max: 180)
      ..isDefault = body.boolean('isDefault');
    if (input.state != null && !_state.hasMatch(input.state!)) {
      body.fail('state', 'Use the 2-letter state code, e.g. NY.');
    }
    if (input.zip != null && !_zip.hasMatch(input.zip!)) {
      body.fail('zip', 'Please enter a valid ZIP code.');
    }
    if ((input.lat == null) != (input.lng == null) && !partial) {
      body.fail('lat', 'Send both lat and lng, or neither.');
    }
    body.validate();
    return input;
  }

  final Body body;
  final bool partial;
  String? label;
  String? customLabel;
  String? street;
  String? apt;
  String? city;
  String? state;
  String? zip;
  String? instructions;
  String? dropoff;
  double? lat;
  double? lng;
  bool? isDefault;

  /// Applies sent fields. Optional text fields can be cleared with `null`.
  void applyTo(Address a) {
    if (label != null) a.label = label!;
    if (body.has('customLabel')) a.customLabel = customLabel;
    if (street != null) a.street = street!;
    if (body.has('apt')) a.apt = apt;
    if (city != null) a.city = city!;
    if (state != null) a.state = state!.toUpperCase();
    if (zip != null) a.zip = zip!;
    if (body.has('instructions')) a.instructions = instructions;
    if (dropoff != null) a.dropoff = dropoff!;
    if (lat != null) a.lat = lat;
    if (lng != null) a.lng = lng;
  }
}

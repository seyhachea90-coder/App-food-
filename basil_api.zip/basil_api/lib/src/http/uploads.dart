import 'package:dart_frog/dart_frog.dart';

import '../config.dart';
import '../models/models.dart';
import '../security/crypto.dart';
import 'api_exception.dart';

/// Detects JPEG/PNG from the file's first bytes (the client's declared
/// content type is not trusted).
String? sniffImageType(List<int> b) {
  if (b.length >= 8 &&
      b[0] == 0x89 && b[1] == 0x50 && b[2] == 0x4E && b[3] == 0x47) {
    return 'image/png';
  }
  if (b.length >= 3 && b[0] == 0xFF && b[1] == 0xD8 && b[2] == 0xFF) {
    return 'image/jpeg';
  }
  return null;
}

/// Reads one JPG/PNG (max 5 MB) from a `multipart/form-data` field.
Future<Upload> readImageUpload(
  RequestContext context, {
  required String ownerId,
  String field = 'file',
}) async {
  final contentType = context.request.headers['content-type'] ?? '';
  if (!contentType.toLowerCase().startsWith('multipart/form-data')) {
    throw ApiException.badRequest(
      'Send the image as multipart/form-data in a "$field" field.',
    );
  }
  final declared = int.tryParse(context.request.headers['content-length'] ?? '');
  if (declared != null && declared > Config.maxUploadBytes + 64 * 1024) {
    throw ApiException(413, 'FILE_TOO_LARGE', 'Images can be up to 5 MB.');
  }
  final form = await context.request.formData();
  final file = form.files[field];
  if (file == null) {
    throw ApiException.validation({field: 'Attach a JPG or PNG image.'});
  }
  final bytes = await file.readAsBytes();
  if (bytes.length > Config.maxUploadBytes) {
    throw ApiException(413, 'FILE_TOO_LARGE', 'Images can be up to 5 MB.');
  }
  final type = sniffImageType(bytes);
  if (type == null) {
    throw ApiException(415, 'UNSUPPORTED_FILE_TYPE', 'JPG or PNG only.');
  }
  return Upload(
    id: newId('upl'),
    ownerId: ownerId,
    contentType: type,
    bytes: bytes,
    createdAt: DateTime.now().toUtc(),
  );
}

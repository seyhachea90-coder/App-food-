import 'package:basil_api/basil_api.dart';
import 'package:dart_frog/dart_frog.dart';

const _maxItemsInCart = 50;

/// POST /api/v1/cart/items — "Add 2 to bag".
///
/// A cart holds dishes from one restaurant. Adding from another restaurant
/// answers 409 `CART_HAS_OTHER_RESTAURANT`; resend with `replaceCart: true`
/// to start a new bag. Identical lines (same dish, size, add-ons, note) merge.
Future<Response> onRequest(RequestContext context) => handle(context, {
      HttpMethod.post: () async {
        final user = context.user;
        final store = context.store;
        final carts = CartService(store);
        final body = await Body.parse(context);
        final dishId = body.string('dishId', required: true);
        final sizeId = body.string('sizeId');
        final addOnIds = body.strings('addOnIds', maxItems: 10) ?? <String>[];
        final note = body.string('note', max: 200);
        final quantity = body.integer('quantity', min: 1, max: 20) ?? 1;
        final replaceCart = body.boolean('replaceCart') ?? false;
        body.validate();

        final dish = store.dish(dishId!);
        final restaurant = store.restaurant(dish.restaurantId);
        final (size, addOns) = carts.validateSelection(body, dish, sizeId: sizeId, addOnIds: addOnIds);
        body.validate();
        if (!dish.isAvailable) {
          throw ApiException.conflict('DISH_UNAVAILABLE', '${dish.name} is not available right now.');
        }
        if (!restaurant.isAcceptingOrders) {
          throw ApiException.conflict(
            'RESTAURANT_NOT_ACCEPTING_ORDERS',
            '${restaurant.name} has temporarily paused new orders.',
          );
        }

        final cart = store.cartOf(user.id);
        if (cart.items.isNotEmpty && cart.restaurantId != restaurant.id) {
          if (!replaceCart) {
            final current = store.restaurants[cart.restaurantId]?.name ?? 'another restaurant';
            throw ApiException.conflict(
              'CART_HAS_OTHER_RESTAURANT',
              'Your bag has items from $current. Send replaceCart: true to start a new bag.',
            );
          }
          cart.clearItems();
        }
        if (carts.itemCount(cart) + quantity > _maxItemsInCart) {
          throw ApiException.unprocessable('CART_LIMIT', 'A bag can hold up to $_maxItemsInCart items.');
        }
        cart.restaurantId = restaurant.id;

        final sortedAddOns = addOns.map((a) => a.id).toList()..sort();
        final existing = cart.items.where((i) {
          final ids = [...i.addOnIds]..sort();
          return i.dishId == dish.id &&
              i.sizeId == size!.id &&
              i.note == note &&
              ids.join(',') == sortedAddOns.join(',');
        }).firstOrNull;

        if (existing != null) {
          if (existing.quantity + quantity > 20) {
            throw ApiException.validation({'quantity': 'You can add up to 20 of the same item.'});
          }
          existing.quantity += quantity;
        } else {
          cart.items.add(
            CartItem(
              id: newId('ci'),
              dishId: dish.id,
              sizeId: size!.id,
              addOnIds: sortedAddOns,
              note: note,
              quantity: quantity,
            ),
          );
        }
        return created(carts.toJson(cart));
      },
    });

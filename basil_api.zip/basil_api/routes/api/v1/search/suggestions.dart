import 'package:basil_api/basil_api.dart';
import 'package:dart_frog/dart_frog.dart';

/// GET /api/v1/search/suggestions — "Find your next favorite."
/// Recent searches (signed-in only), trending nearby and an inspiration card.
Future<Response> onRequest(RequestContext context) => handle(context, {
      HttpMethod.get: () {
        final user = context.userOrNull;
        return ok({
          'recent': user?.recentSearches ?? const <String>[],
          'trending': context.store.trendingSearches,
          'inspiration': {
            'eyebrow': 'COMFORT CALLING',
            'title': 'A pasta kind of day.',
            'cta': 'Explore Italian →',
            'categoryId': 'cat_italian',
          },
        });
      },
    });

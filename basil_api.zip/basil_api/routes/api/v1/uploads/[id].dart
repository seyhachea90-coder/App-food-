import 'package:basil_api/basil_api.dart';
import 'package:dart_frog/dart_frog.dart';

/// GET /api/v1/uploads/{id} — serves an uploaded image (public).
Future<Response> onRequest(RequestContext context, String id) => handle(context, {
      HttpMethod.get: () {
        final upload = context.store.uploads[id] ?? (throw ApiException.notFound('File'));
        return Response.bytes(
          body: upload.bytes,
          headers: {
            'Content-Type': upload.contentType,
            'Cache-Control': 'public, max-age=86400',
            'X-Content-Type-Options': 'nosniff',
          },
        );
      },
    });

import 'package:basil_api/basil_api.dart';
import 'package:basil_api/src/http/admin_input.dart';
import 'package:dart_frog/dart_frog.dart';

/// /api/v1/admin/restaurants/{id} — update a restaurant, e.g. pause new orders
/// with `{"isAcceptingOrders": false}` ("Not accepting orders" screen).
Future<Response> onRequest(RequestContext context, String id) => handle(context, {
      HttpMethod.get: () => ok(context.store.restaurant(id).toDetailJson()),
      HttpMethod.patch: () async {
        final store = context.store;
        final r = store.restaurant(id);
        final body = await Body.parse(context);
        applyRestaurantInput(body, r, creating: false);
        final unknown = r.categoryIds.where((c) => store.category(c) == null);
        if (unknown.isNotEmpty) {
          throw ApiException.validation({'categoryIds': 'Unknown: ${unknown.join(', ')}.'});
        }
        return ok(r.toDetailJson());
      },
    });

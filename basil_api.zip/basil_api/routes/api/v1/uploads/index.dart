import 'package:basil_api/basil_api.dart';
import 'package:basil_api/src/http/uploads.dart';
import 'package:dart_frog/dart_frog.dart';

/// POST /api/v1/uploads — upload a review photo ("Add photos").
/// `multipart/form-data` with the image in the `file` field. Use the returned
/// `url` in `photoUrls` when posting a review.
Future<Response> onRequest(RequestContext context) => handle(context, {
      HttpMethod.post: () async {
        final user = context.user;
        final upload = await readImageUpload(context, ownerId: user.id);
        context.store.uploads[upload.id] = upload;
        return created({
          'id': upload.id,
          'url': upload.url,
          'contentType': upload.contentType,
          'sizeBytes': upload.bytes.length,
        });
      },
    });

import 'package:basil_api/basil_api.dart';
import 'package:dart_frog/dart_frog.dart';

/// /api/v1/me — "Your account", "Edit profile", "Delete account".
Future<Response> onRequest(RequestContext context) => handle(context, {
      HttpMethod.get: () => ok(_profile(context.store, context.user)),

      // Edit profile: fullName, email, phone (send null to remove the phone).
      HttpMethod.patch: () async {
        final user = context.user;
        final store = context.store;
        final body = await Body.parse(context);
        final fullName = body.string('fullName', min: 2, max: 80);
        final email = body.email('email');
        String? phone;
        if (body.raw['phone'] != null) {
          phone = body.string('phone', max: 20);
          if (phone != null && !RegExp(r'^\+?[0-9 ()\-]{7,20}$').hasMatch(phone)) {
            body.fail('phone', 'Please enter a valid phone number.');
          }
        }
        if (email != null && email != user.email && store.userByEmail(email) != null) {
          body.fail('email', 'Another account already uses this email.');
        }
        body.validate();

        if (fullName != null) user.fullName = fullName;
        if (email != null && email != user.email) {
          user
            ..email = email
            ..emailVerified = false; // Needs verification again.
        }
        if (body.has('phone')) user.phone = phone;
        return ok(_profile(store, user));
      },

      // "Yes, delete my account" — permanent.
      HttpMethod.delete: () async {
        final user = context.user;
        final body = await Body.parse(context);
        final confirm = body.boolean('confirm', required: true);
        body.validate();
        if (confirm != true) {
          throw ApiException.badRequest(
            'Send {"confirm": true} to delete the account.',
            code: 'CONFIRMATION_REQUIRED',
          );
        }
        final active = context.store.ordersOf(user.id).where((o) => o.status.isActive);
        if (active.isNotEmpty) {
          throw ApiException.conflict(
            'ACTIVE_ORDERS',
            'You have an order on the way. You can delete your account once it is delivered.',
          );
        }
        context.store.deleteUser(user);
        return ok({'message': 'Your account has been deleted.'});
      },
    });

Map<String, dynamic> _profile(Store store, User user) => {
      ...user.toJson(),
      'counts': {
        'favorites': store.favoritesOf(user.id).length,
        'addresses': store.addressesOf(user.id).length,
        'paymentMethods': store.paymentMethodsOf(user.id).length,
        'orders': store.ordersOf(user.id).length,
        'unreadNotifications':
            store.notificationsOf(user.id).where((n) => n.readAt == null).length,
      },
      'settings': user.settings.toJson(),
    };

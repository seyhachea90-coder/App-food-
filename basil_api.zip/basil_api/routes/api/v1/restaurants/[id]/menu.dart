import 'package:basil_api/basil_api.dart';
import 'package:dart_frog/dart_frog.dart';

/// GET /api/v1/restaurants/{id}/menu?q= — "Made fresh. Made for your kind of hungry."
/// Sections in menu order; "Popular" holds the local favorites.
Future<Response> onRequest(RequestContext context, String id) => handle(context, {
      HttpMethod.get: () {
        final store = context.store;
        final r = store.restaurant(id);
        final catalog = CatalogService(store);
        final q = context.queryString('q');
        final dishes = store.dishes.values
            .where((d) => d.restaurantId == r.id)
            .where((d) => q == null || catalog.dishMatchesText(d, q))
            .toList();

        final sections = <Map<String, dynamic>>[];
        for (final name in r.menuSections) {
          final items = name == 'Popular'
              ? dishes.where((d) => d.isPopular).toList()
              : dishes.where((d) => d.section == name).toList();
          if (items.isEmpty) continue;
          sections.add({
            'name': name,
            'title': name == 'Popular' ? 'The local favorites' : name,
            'count': items.length,
            'dishes': items.map((d) => d.toSummaryJson(r)).toList(),
          });
        }
        return ok({
          'restaurant': {
            'id': r.id,
            'name': r.name,
            'isAcceptingOrders': r.isAcceptingOrders,
          },
          'query': q,
          'sections': sections,
          'note': 'Tap + to choose sizes and add-ons. All prices in USD.',
        });
      },
    });

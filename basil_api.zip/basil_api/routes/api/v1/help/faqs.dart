import 'package:basil_api/basil_api.dart';
import 'package:dart_frog/dart_frog.dart';

/// GET /api/v1/help/faqs?q=&topic= — "Search questions or topics".
Future<Response> onRequest(RequestContext context) => handle(context, {
      HttpMethod.get: () {
        final q = context.queryString('q')?.toLowerCase();
        final topic = context.queryString('topic');
        final list = context.store.faqs
            .where((f) => topic == null || f.topic == topic)
            .where((f) => q == null || '${f.question} ${f.answer}'.toLowerCase().contains(q))
            .map((f) => f.toJson())
            .toList();
        return ok(list, meta: {'total': list.length});
      },
    });

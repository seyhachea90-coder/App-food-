import 'package:basil_api/basil_api.dart';
import 'package:dart_frog/dart_frog.dart';

/// PUT /api/v1/cart/delivery-address — "Where’s lunch headed?" (Deliver here)
Future<Response> onRequest(RequestContext context) => handle(context, {
      HttpMethod.put: () async {
        final user = context.user;
        final store = context.store;
        final carts = CartService(store);
        final body = await Body.parse(context);
        final addressId = body.string('addressId', required: true);
        body.validate();

        final address = store.ownedAddress(user, addressId!);
        final cart = store.cartOf(user.id);
        final delivery = carts.deliverability(carts.restaurantOf(cart), address);
        if (delivery != null && delivery['deliversHere'] == false) {
          throw ApiException.unprocessable('ADDRESS_OUT_OF_RANGE', delivery['message'] as String);
        }
        cart.addressId = address.id;
        return ok(carts.toJson(cart));
      },
    });

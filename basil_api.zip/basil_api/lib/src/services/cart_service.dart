import '../config.dart';
import '../data/store.dart';
import '../http/request.dart';
import '../models/models.dart';
import 'pricing.dart';

/// A cart line with its dish and chosen options resolved.
class ResolvedLine {
  ResolvedLine(this.item, this.dish, this.size, this.addOns);

  final CartItem item;
  final Dish dish;
  final DishOption size;
  final List<DishOption> addOns;

  int get unitPriceCents =>
      dish.priceCents +
      size.priceDeltaCents +
      addOns.fold(0, (sum, a) => sum + a.priceDeltaCents);

  int get totalCents => unitPriceCents * item.quantity;

  /// "Large · 2 add-ons · Qty 2" (as on the cart screens).
  String get summary {
    final parts = <String>[size.name];
    if (addOns.isNotEmpty) {
      parts.add('${addOns.length} add-on${addOns.length == 1 ? '' : 's'}');
    }
    parts.add('Qty ${item.quantity}');
    return parts.join(' · ');
  }

  OrderItem toOrderItem() => OrderItem(
        dishId: dish.id,
        name: dish.name,
        imageUrl: dish.imageUrl,
        basePriceCents: dish.priceCents,
        size: {
          'id': size.id,
          'name': size.name,
          'priceDeltaCents': size.priceDeltaCents,
        },
        addOns: addOns
            .map((a) => {'id': a.id, 'name': a.name, 'priceDeltaCents': a.priceDeltaCents})
            .toList(),
        quantity: item.quantity,
        note: item.note,
      );

  Map<String, dynamic> toJson() => {
        'id': item.id,
        'dish': {
          'id': dish.id,
          'name': dish.name,
          'imageUrl': dish.imageUrl,
          'isAvailable': dish.isAvailable,
        },
        'basePriceCents': dish.priceCents,
        'size': size.toJson(),
        'addOns': addOns.map((a) => a.toJson()).toList(),
        'note': item.note,
        'quantity': item.quantity,
        'unitPriceCents': unitPriceCents,
        'totalCents': totalCents,
        'summary': summary,
      };
}

class CartService {
  CartService(this.store);

  final Store store;

  /// Validates a size/add-on selection for [dish]; collects errors in [body].
  (DishOption?, List<DishOption>) validateSelection(
    Body body,
    Dish dish, {
    String? sizeId,
    List<String>? addOnIds,
  }) {
    final size = sizeId == null ? dish.sizes.first : dish.sizeById(sizeId);
    if (size == null) {
      body.fail('sizeId', 'Choose one of: ${dish.sizes.map((s) => s.id).join(', ')}.');
    }
    final addOns = <DishOption>[];
    for (final id in addOnIds ?? const <String>[]) {
      final a = dish.addOnById(id);
      if (a == null) {
        body.fail(
          'addOnIds',
          dish.addOns.isEmpty
              ? 'This dish has no add-ons.'
              : 'Unknown add-on "$id". Choose from: ${dish.addOns.map((a) => a.id).join(', ')}.',
        );
      } else {
        addOns.add(a);
      }
    }
    return (size, addOns);
  }

  ResolvedLine resolve(CartItem item) {
    final dish = store.dish(item.dishId);
    return ResolvedLine(
      item,
      dish,
      dish.sizeById(item.sizeId) ?? dish.sizes.first,
      item.addOnIds.map(dish.addOnById).whereType<DishOption>().toList(),
    );
  }

  List<ResolvedLine> lines(Cart cart) => cart.items.map(resolve).toList();

  int subtotal(Cart cart) => lines(cart).fold(0, (sum, l) => sum + l.totalCents);

  int itemCount(Cart cart) => cart.items.fold(0, (sum, i) => sum + i.quantity);

  Restaurant? restaurantOf(Cart cart) =>
      cart.restaurantId == null ? null : store.restaurants[cart.restaurantId];

  Address? addressOf(Cart cart) {
    if (cart.addressId != null) {
      final a = store.addresses[cart.addressId];
      if (a != null && a.userId == cart.userId) return a;
      cart.addressId = null;
    }
    return store.defaultAddressOf(cart.userId);
  }

  PaymentMethod? paymentOf(Cart cart) {
    if (cart.paymentMethodId != null) {
      final p = store.paymentMethods[cart.paymentMethodId];
      if (p != null && p.userId == cart.userId) return p;
      cart.paymentMethodId = null;
    }
    return store.defaultPaymentMethodOf(cart.userId);
  }

  PriceQuote quote(Cart cart) => computeQuote(
        restaurant: restaurantOf(cart),
        subtotalCents: subtotal(cart),
        itemCount: itemCount(cart),
        settings: store.settings,
        coupon: cart.promoCode == null ? null : store.coupons[cart.promoCode],
      );

  /// Delivery info for an address relative to the cart's restaurant.
  Map<String, dynamic>? deliverability(Restaurant? r, Address? a) {
    if (r == null || a == null) return null;
    final miles = r.distanceMilesTo(a.lat, a.lng);
    final delivers = miles == null || miles <= Config.maxDeliveryMiles;
    return {
      'deliversHere': delivers,
      'distanceMiles': miles,
      'deliveryFeeCents': r.deliveryFeeCents,
      'message': delivers
          ? '${r.name} delivers here${miles == null ? '' : ' · $miles mi'} · ${formatCents(r.deliveryFeeCents)} fee'
          : '${r.name} does not deliver this far (max ${Config.maxDeliveryMiles} mi).',
    };
  }

  Map<String, dynamic> toJson(Cart cart) {
    final restaurant = restaurantOf(cart);
    final resolved = lines(cart);
    final q = quote(cart);
    final address = addressOf(cart);
    final payment = paymentOf(cart);
    final coupon = cart.promoCode == null ? null : store.coupons[cart.promoCode];
    final couponCheck = coupon == null ? null : checkCoupon(coupon, restaurant, q.subtotalCents);
    final delivery = deliverability(restaurant, address);

    final blockers = <String>[];
    if (resolved.isEmpty) blockers.add('Your cart is empty.');
    if (restaurant != null && !restaurant.isAcceptingOrders) {
      blockers.add('${restaurant.name} is not accepting orders right now.');
    }
    if (restaurant != null && q.subtotalCents < restaurant.minOrderCents) {
      blockers.add('Minimum order is ${formatCents(restaurant.minOrderCents)}.');
    }
    if (resolved.any((l) => !l.dish.isAvailable)) {
      blockers.add('Some items are no longer available.');
    }
    if (address == null) blockers.add('Add a delivery address.');
    if (delivery != null && delivery['deliversHere'] == false) {
      blockers.add(delivery['message'] as String);
    }
    if (payment == null) blockers.add('Add a payment method.');
    if (payment != null && payment.isExpired) blockers.add('Your card has expired.');

    return {
      'isEmpty': resolved.isEmpty,
      'restaurant': restaurant == null
          ? null
          : {
              ...restaurant.toSummaryJson(fromLat: address?.lat, fromLng: address?.lng),
              'minOrderCents': restaurant.minOrderCents,
            },
      'items': resolved.map((l) => l.toJson()).toList(),
      'promo': coupon == null
          ? null
          : {
              ...coupon.toJson(),
              'applied': couponCheck!.eligible,
              'savingsCents': couponCheck.savingsCents,
              'reason': couponCheck.reason,
            },
      'deliveryAddress': address?.toJson(),
      'delivery': delivery,
      'schedule': cart.schedule.toJson(),
      'paymentMethod': payment?.toJson(),
      'pricing': q.toJson(),
      'canCheckout': blockers.isEmpty,
      'blockers': blockers,
    };
  }
}

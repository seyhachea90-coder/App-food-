import 'package:basil_api/basil_api.dart';
import 'package:dart_frog/dart_frog.dart';

/// PUT /api/v1/orders/{id}/delivery-instructions — "How should we drop it off?"
/// `saveForAddress: true` also saves them to the saved address for next time.
Future<Response> onRequest(RequestContext context, String id) => handle(context, {
      HttpMethod.put: () async {
        final user = context.user;
        final store = context.store;
        final order = store.ownedOrder(user, id);
        final body = await Body.parse(context);
        final dropoff = body.string('dropoff', required: true, oneOf: Address.dropoffs);
        final note = body.string('note', max: 250);
        final save = body.boolean('saveForAddress') ?? false;
        body.validate();

        if (!order.status.isActive) {
          throw ApiException.conflict('ORDER_CLOSED', 'This order has already been ${order.status.label.toLowerCase()}.');
        }
        order
          ..dropoff = dropoff!
          ..dropoffNote = note;
        var savedToAddress = false;
        if (save) {
          final address = store.addresses[order.address['addressId']];
          if (address != null && address.userId == user.id) {
            address
              ..dropoff = dropoff
              ..instructions = note;
            savedToAddress = true;
          }
        }
        return ok({
          'dropoff': {'method': order.dropoff, 'note': order.dropoffNote},
          'savedToAddress': savedToAddress,
          'message': 'Shared with your courier for order #${order.number}.',
        });
      },
    });

import 'package:basil_api/basil_api.dart';
import 'package:dart_frog/dart_frog.dart';

/// DELETE /api/v1/search/recent — "Clear all" recent searches.
Future<Response> onRequest(RequestContext context) => handle(context, {
      HttpMethod.delete: () {
        context.user.recentSearches.clear();
        return ok({'recent': <String>[]});
      },
    });

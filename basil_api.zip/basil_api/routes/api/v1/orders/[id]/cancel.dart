import 'package:basil_api/basil_api.dart';
import 'package:dart_frog/dart_frog.dart';

/// POST /api/v1/orders/{id}/cancel — only before the kitchen starts preparing.
Future<Response> onRequest(RequestContext context, String id) => handle(context, {
      HttpMethod.post: () async {
        final store = context.store;
        final order = store.ownedOrder(context.user, id);
        final body = await Body.parse(context);
        final reason = body.string('reason', max: 250);
        body.validate();

        if (order.status != OrderStatus.pending && order.status != OrderStatus.confirmed) {
          throw ApiException.conflict(
            'ORDER_NOT_CANCELLABLE',
            'The kitchen has already started on this order. Contact support for help.',
          );
        }
        final service = OrderService(store)
          ..setStatus(order, OrderStatus.cancelled, reason: reason ?? 'Cancelled by customer.');
        return ok(service.detailJson(order));
      },
    });

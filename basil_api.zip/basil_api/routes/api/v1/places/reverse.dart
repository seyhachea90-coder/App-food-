import 'package:basil_api/basil_api.dart';
import 'package:dart_frog/dart_frog.dart';

/// GET /api/v1/places/reverse?lat=&lng= — "Use my current location".
/// Returns the nearest known address to the device location.
Future<Response> onRequest(RequestContext context) => handle(context, {
      HttpMethod.get: () {
        final lat = context.queryDouble('lat');
        final lng = context.queryDouble('lng');
        if (lat == null || lng == null || lat.abs() > 90 || lng.abs() > 180) {
          throw ApiException.validation({'lat': 'Send valid lat and lng query parameters.'});
        }
        final places = context.store.places;
        Place? nearest;
        var best = double.infinity;
        for (final p in places) {
          final d = haversineMiles(lat, lng, p.lat, p.lng);
          if (d < best) {
            best = d;
            nearest = p;
          }
        }
        if (nearest == null || best > 25) {
          throw ApiException.notFound('Address near this location');
        }
        return ok({...nearest.toJson(), 'distanceMiles': double.parse(best.toStringAsFixed(2))});
      },
    });

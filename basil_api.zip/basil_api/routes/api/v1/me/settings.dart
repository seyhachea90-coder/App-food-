import 'package:basil_api/basil_api.dart';
import 'package:dart_frog/dart_frog.dart';

/// /api/v1/me/settings — "Basil, your way." (Settings screen)
Future<Response> onRequest(RequestContext context) => handle(context, {
      HttpMethod.get: () => ok(context.user.settings.toJson()),
      HttpMethod.patch: () async {
        final settings = context.user.settings;
        final body = await Body.parse(context);
        final notifications = body.object('notifications');
        final language = body.string('language', oneOf: UserSettings.languages);
        final appearance = body.string('appearance', oneOf: UserSettings.appearances);
        final location = body.string('locationAccess', oneOf: UserSettings.locationAccessValues);
        bool? flag(String key) {
          final v = notifications?[key];
          if (v == null) return null;
          if (v is! bool) {
            body.fail('notifications.$key', 'Must be true or false.');
            return null;
          }
          return v;
        }

        final orderUpdates = flag('orderUpdates');
        final offers = flag('offersAndRecommendations');
        final receipts = flag('emailReceipts');
        body.validate();

        if (orderUpdates != null) settings.orderUpdates = orderUpdates;
        if (offers != null) settings.offersAndRecommendations = offers;
        if (receipts != null) settings.emailReceipts = receipts;
        if (language != null) settings.language = language;
        if (appearance != null) settings.appearance = appearance;
        if (location != null) settings.locationAccess = location;
        return ok(settings.toJson());
      },
    });

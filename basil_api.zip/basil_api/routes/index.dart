import 'package:basil_api/basil_api.dart';
import 'package:dart_frog/dart_frog.dart';

/// GET / — service banner.
Response onRequest(RequestContext context) => ok({
      'name': 'Basil API',
      'version': Config.apiVersion,
      'basePath': '/api/v1',
      'health': '/api/v1/health',
    });

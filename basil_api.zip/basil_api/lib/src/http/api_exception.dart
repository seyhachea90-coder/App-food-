/// An error that is turned into a JSON error response by the root middleware.
///
/// Every error the API returns has the same shape:
/// `{"error": {"code": "...", "message": "...", "details": {...}}}`
class ApiException implements Exception {
  ApiException(this.statusCode, this.code, this.message, {this.details});

  factory ApiException.badRequest(String message, {String code = 'BAD_REQUEST'}) =>
      ApiException(400, code, message);

  factory ApiException.validation(Map<String, String> details) => ApiException(
        422,
        'VALIDATION_ERROR',
        'Some fields need a second look.',
        details: details,
      );

  factory ApiException.unauthorized([
    String message = 'Please sign in to continue.',
  ]) =>
      ApiException(401, 'UNAUTHORIZED', message);

  factory ApiException.forbidden([String message = 'You do not have access.']) =>
      ApiException(403, 'FORBIDDEN', message);

  factory ApiException.notFound(String resource) =>
      ApiException(404, 'NOT_FOUND', '$resource not found.');

  factory ApiException.conflict(String code, String message) =>
      ApiException(409, code, message);

  factory ApiException.unprocessable(String code, String message) =>
      ApiException(422, code, message);

  factory ApiException.methodNotAllowed(List<String> allowed) => ApiException(
        405,
        'METHOD_NOT_ALLOWED',
        'Method not allowed. Allowed: ${allowed.join(', ')}.',
      );

  final int statusCode;
  final String code;
  final String message;
  final Map<String, String>? details;

  Map<String, dynamic> toJson() => {
        'error': {
          'code': code,
          'message': message,
          if (details != null) 'details': details,
        },
      };

  @override
  String toString() => 'ApiException($statusCode, $code, $message)';
}

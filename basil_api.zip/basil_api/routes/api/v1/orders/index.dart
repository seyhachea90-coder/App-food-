import 'package:basil_api/basil_api.dart';
import 'package:dart_frog/dart_frog.dart';

/// /api/v1/orders
///  GET  — "Your orders" (?status=past|upcoming|all, page, limit)
///  POST — "Place order & pay": turns the current cart into an order.
Future<Response> onRequest(RequestContext context) => handle(context, {
      HttpMethod.get: () {
        final user = context.user;
        final service = OrderService(context.store);
        final status = context.queryEnum('status', ['all', 'past', 'upcoming'], 'all');
        final page = Pagination.of(context);
        final list = context.store.ordersOf(user.id).where((o) {
          return switch (status) {
            'past' => !o.status.isActive,
            'upcoming' => o.status.isActive,
            _ => true,
          };
        }).toList();
        return ok(
          page.slice(list).map(service.summaryJson).toList(),
          meta: {...page.meta(list.length), 'status': status},
        );
      },
      HttpMethod.post: () {
        final user = context.user;
        final store = context.store;
        final service = OrderService(store);
        final order = service.placeOrder(user, store.cartOf(user.id));
        return created({
          ...service.detailJson(order),
          'message': 'Payment successful. ${order.restaurantName} has received your order.',
        });
      },
    });

import 'package:basil_api/basil_api.dart';
import 'package:dart_frog/dart_frog.dart';

/// POST /api/v1/auth/logout — Profile → Log out.
/// Revokes the given refresh token, or every session with `allDevices: true`.
Future<Response> onRequest(RequestContext context) => handle(context, {
      HttpMethod.post: () async {
        final user = context.user;
        final body = await Body.parse(context);
        final token = body.string('refreshToken');
        final allDevices = body.boolean('allDevices') ?? false;
        body.validate();

        final store = context.store;
        if (allDevices) {
          store.refreshTokens.removeWhere((_, s) => s.userId == user.id);
        } else if (token != null && store.refreshTokens[token]?.userId == user.id) {
          store.refreshTokens.remove(token);
        }
        return ok({'message': 'Signed out.'});
      },
    });

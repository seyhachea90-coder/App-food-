import 'package:basil_api/basil_api.dart';
import 'package:dart_frog/dart_frog.dart';

/// GET /api/v1/orders/{id} — "Order details" / "Order confirmed".
/// `{id}` can be the order id (ord_...) or its number (BSL-1038).
Future<Response> onRequest(RequestContext context, String id) => handle(context, {
      HttpMethod.get: () {
        final order = context.store.ownedOrder(context.user, id);
        return ok(OrderService(context.store).detailJson(order));
      },
    });

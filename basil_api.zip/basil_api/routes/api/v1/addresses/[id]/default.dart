import 'package:basil_api/basil_api.dart';
import 'package:dart_frog/dart_frog.dart';

/// POST /api/v1/addresses/{id}/default — "Set as default".
Future<Response> onRequest(RequestContext context, String id) => handle(context, {
      HttpMethod.post: () {
        final user = context.user;
        final store = context.store;
        final address = store.ownedAddress(user, id);
        for (final a in store.addressesOf(user.id)) {
          a.isDefault = a.id == address.id;
        }
        return ok(address.toJson());
      },
    });

import 'package:basil_api/basil_api.dart';
import 'package:basil_api/src/services/review_service.dart';
import 'package:dart_frog/dart_frog.dart';

/// GET /api/v1/dishes/{id}/reviews — "★ 4.9 · 86 dish reviews".
Future<Response> onRequest(RequestContext context, String id) => handle(context, {
      HttpMethod.get: () {
        final store = context.store;
        final dish = store.dish(id);
        return reviewsResponse(
          context,
          reviews: store.reviews.where((v) => v.dishId == dish.id && v.target != 'courier'),
          breakdown: dish.ratingBreakdown,
          average: dish.rating,
        );
      },
    });

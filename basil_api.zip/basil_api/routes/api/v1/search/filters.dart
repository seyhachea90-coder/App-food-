import 'package:basil_api/basil_api.dart';
import 'package:dart_frog/dart_frog.dart';

/// GET /api/v1/search/filters — options for the "Filters" sheet. Each option's
/// `param`/`value` is what to send to /search or /restaurants.
Future<Response> onRequest(RequestContext context) => handle(context, {
      HttpMethod.get: () => ok({
            'sortBy': {
              'param': 'sort',
              'default': 'recommended',
              'options': [
                {'value': 'recommended', 'label': 'Recommended'},
                {'value': 'top_rated', 'label': 'Top rated'},
                {'value': 'fastest_delivery', 'label': 'Fastest delivery'},
                {'value': 'lowest_delivery_fee', 'label': 'Lowest delivery fee'},
              ],
            },
            'priceRange': {
              'param': 'price',
              'multiple': true,
              'options': [
                {'value': 1, 'label': r'$'},
                {'value': 2, 'label': r'$$'},
                {'value': 3, 'label': r'$$$'},
                {'value': 4, 'label': r'$$$$'},
              ],
            },
            'deliveryTime': {
              'param': 'maxDeliveryMinutes',
              'options': [
                {'value': null, 'label': 'Any time'},
                {'value': 30, 'label': 'Under 30 min'},
                {'value': 45, 'label': 'Under 45 min'},
              ],
            },
            'minimumRating': {
              'param': 'minRating',
              'options': [
                {'value': null, 'label': 'Any'},
                {'value': 4.0, 'label': '4.0+'},
                {'value': 4.5, 'label': '4.5+'},
              ],
            },
            'dietaryPreferences': {
              'param': 'dietary',
              'multiple': true,
              'options': [
                {'value': 'vegetarian', 'label': 'Vegetarian'},
                {'value': 'vegan', 'label': 'Vegan'},
                {'value': 'gluten_free', 'label': 'Gluten-free'},
                {'value': 'halal', 'label': 'Halal'},
              ],
            },
            'toggles': [
              {'param': 'freeDelivery', 'label': 'Free delivery only'},
              {'param': 'offers', 'label': 'Offers & deals'},
            ],
            'resultCountEndpoint': '/api/v1/restaurants?limit=1 (read meta.total for "Show N restaurants")',
          }),
    });

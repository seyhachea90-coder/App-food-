import 'package:basil_api/basil_api.dart';
import 'package:dart_frog/dart_frog.dart';

/// GET /api/v1/health
Future<Response> onRequest(RequestContext context) => handle(context, {
      HttpMethod.get: () => ok({
            'status': 'ok',
            'version': Config.apiVersion,
            'time': iso(DateTime.now()),
          }),
    });

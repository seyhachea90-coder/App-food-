import '../security/crypto.dart';

enum UserRole { customer, admin }

class UserSettings {
  bool orderUpdates = true;
  bool offersAndRecommendations = true;
  bool emailReceipts = true;
  String language = 'en';
  String appearance = 'light';
  String locationAccess = 'while_using';

  static const languages = ['en', 'es', 'fr', 'km'];
  static const appearances = ['light', 'dark', 'system'];
  static const locationAccessValues = ['while_using', 'always', 'never'];

  Map<String, dynamic> toJson() => {
        'notifications': {
          'orderUpdates': orderUpdates,
          'offersAndRecommendations': offersAndRecommendations,
          'emailReceipts': emailReceipts,
        },
        'language': language,
        'appearance': appearance,
        'locationAccess': locationAccess,
      };
}

class User {
  User({
    required this.id,
    required this.fullName,
    required this.email,
    required this.passwordHash,
    this.role = UserRole.customer,
    this.phone,
    this.emailVerified = false,
    this.authProvider = 'password',
    DateTime? createdAt,
  }) : createdAt = createdAt ?? DateTime.now().toUtc();

  final String id;
  String fullName;
  String email;
  String? phone;
  String passwordHash;
  final UserRole role;
  bool emailVerified;
  final String authProvider;
  String? avatarUploadId;
  final DateTime createdAt;
  final UserSettings settings = UserSettings();
  final List<String> recentSearches = [];

  String get firstName => fullName.split(' ').first;

  /// "Dara Sok" -> "Dara S." (public name on reviews).
  String get publicName {
    final parts = fullName.trim().split(RegExp(r'\s+'));
    if (parts.length < 2) return parts.first;
    return '${parts.first} ${parts.last[0].toUpperCase()}.';
  }

  String get initials => fullName.trim().isEmpty ? '?' : fullName.trim()[0].toUpperCase();

  String? get avatarUrl =>
      avatarUploadId == null ? null : '/api/v1/uploads/$avatarUploadId';

  Map<String, dynamic> toJson() => {
        'id': id,
        'fullName': fullName,
        'firstName': firstName,
        'publicName': publicName,
        'initials': initials,
        'email': email,
        'emailVerified': emailVerified,
        'phone': phone,
        'avatarUrl': avatarUrl,
        'role': role.name,
        'authProvider': authProvider,
        'createdAt': iso(createdAt),
      };
}

class Address {
  Address({
    required this.id,
    required this.userId,
    required this.label,
    required this.street,
    required this.city,
    required this.state,
    required this.zip,
    this.customLabel,
    this.apt,
    this.instructions,
    this.dropoff = 'hand_to_me',
    this.lat,
    this.lng,
    this.isDefault = false,
  });

  static const labels = ['home', 'work', 'other'];
  static const dropoffs = ['hand_to_me', 'leave_at_door'];

  final String id;
  final String userId;
  String label;
  String? customLabel;
  String street;
  String? apt;
  String city;
  String state;
  String zip;
  String? instructions;
  String dropoff;
  double? lat;
  double? lng;
  bool isDefault;

  String get displayLabel =>
      customLabel ?? '${label[0].toUpperCase()}${label.substring(1)}';

  String get line1 => apt == null ? street : '$street, $apt';
  String get line2 => '$city, $state $zip';

  Map<String, dynamic> toJson() => {
        'id': id,
        'label': label,
        'displayLabel': displayLabel,
        'customLabel': customLabel,
        'street': street,
        'apt': apt,
        'city': city,
        'state': state,
        'zip': zip,
        'line1': line1,
        'line2': line2,
        'instructions': instructions,
        'dropoff': dropoff,
        'location': lat == null || lng == null ? null : {'lat': lat, 'lng': lng},
        'isDefault': isDefault,
      };
}

class PaymentMethod {
  PaymentMethod({
    required this.id,
    required this.userId,
    required this.type,
    this.brand,
    this.last4,
    this.expMonth,
    this.expYear,
    this.holderName,
    this.email,
    this.isDefault = false,
    this.declines = false,
    DateTime? createdAt,
  }) : createdAt = createdAt ?? DateTime.now().toUtc();

  static const types = ['card', 'apple_pay', 'paypal'];

  final String id;
  final String userId;
  final String type;
  final String? brand;
  final String? last4;
  int? expMonth;
  int? expYear;
  String? holderName;
  final String? email;
  bool isDefault;

  /// Test-only: payments with this method are declined.
  final bool declines;
  final DateTime createdAt;

  String get label => switch (type) {
        'card' => '${_brandName(brand)} •••• $last4',
        'apple_pay' => 'Apple Pay',
        'paypal' => 'PayPal${email == null ? '' : ' · $email'}',
        _ => type,
      };

  bool get isExpired {
    if (type != 'card' || expMonth == null || expYear == null) return false;
    final now = DateTime.now();
    return expYear! < now.year || (expYear == now.year && expMonth! < now.month);
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'type': type,
        'label': label,
        'brand': brand,
        'last4': last4,
        'expMonth': expMonth,
        'expYear': expYear,
        'expiry': expMonth == null
            ? null
            : '${expMonth.toString().padLeft(2, '0')}/${(expYear! % 100).toString().padLeft(2, '0')}',
        'isExpired': isExpired,
        'holderName': holderName,
        'email': email,
        'isDefault': isDefault,
        'createdAt': iso(createdAt),
      };

  /// Snapshot stored on an order.
  Map<String, dynamic> toSnapshot() => {
        'paymentMethodId': id,
        'type': type,
        'brand': brand,
        'last4': last4,
        'label': label,
      };
}

String _brandName(String? brand) => switch (brand) {
      'visa' => 'Visa',
      'mastercard' => 'Mastercard',
      'amex' => 'American Express',
      _ => 'Card',
    };

class RefreshSession {
  RefreshSession(this.userId, this.expiresAt);
  final String userId;
  final DateTime expiresAt;
}

class ResetTicket {
  ResetTicket(this.userId, this.expiresAt);
  final String userId;
  final DateTime expiresAt;
}

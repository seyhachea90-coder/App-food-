import 'package:basil_api/basil_api.dart';
import 'package:dart_frog/dart_frog.dart';

/// PUT /api/v1/me/password — Edit profile → Change password.
Future<Response> onRequest(RequestContext context) => handle(context, {
      HttpMethod.put: () async {
        final user = context.user;
        final body = await Body.parse(context);
        final current = body.string('currentPassword', required: true);
        final next = body.password('newPassword');
        final confirm = body.string('confirmPassword', required: true);
        if (next != null && confirm != null && next != confirm) {
          body.fail('confirmPassword', 'Passwords do not match.');
        }
        body.validate();

        if (!verifyPassword(current!, user.passwordHash)) {
          throw ApiException.validation({'currentPassword': 'Current password is incorrect.'});
        }
        if (current == next) {
          throw ApiException.validation({'newPassword': 'Choose a password you have not used here.'});
        }
        user.passwordHash = hashPassword(next!);
        // Other devices must sign in again.
        context.store.refreshTokens.removeWhere((_, s) => s.userId == user.id);
        return ok({'message': 'Password changed.', ...issueSession(context.store, user)});
      },
    });

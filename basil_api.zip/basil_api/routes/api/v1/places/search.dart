import 'package:basil_api/basil_api.dart';
import 'package:dart_frog/dart_frog.dart';

/// GET /api/v1/places/search?q= — "Search for an address".
///
/// Backed by a small built-in list of Brooklyn addresses. Swap for a real
/// geocoder (Google Places, Mapbox) in production.
Future<Response> onRequest(RequestContext context) => handle(context, {
      HttpMethod.get: () {
        final q = context.queryString('q');
        if (q == null || q.length < 2) {
          throw ApiException.validation({'q': 'Type at least 2 characters.'});
        }
        final needle = q.toLowerCase();
        final results = context.store.places
            .where(
              (p) => '${p.name ?? ''} ${p.street} ${p.city} ${p.zip}'.toLowerCase().contains(needle),
            )
            .take(10)
            .map((p) => p.toJson())
            .toList();
        return ok(results, meta: {'total': results.length});
      },
    });

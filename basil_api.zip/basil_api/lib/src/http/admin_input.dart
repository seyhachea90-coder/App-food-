import '../models/models.dart';
import '../services/catalog_service.dart';
import 'request.dart';

final _slug = RegExp(r'^[a-z0-9_]{1,40}$');
final _hhmm = RegExp(r'^([01]\d|2[0-3]):[0-5]\d$');

List<DishOption>? readOptions(Body body, String key) {
  final raw = body.raw[key];
  if (raw == null) return null;
  if (raw is! List) {
    body.fail(key, 'Must be a list of {id, name, priceDeltaCents, description?}.');
    return null;
  }
  final out = <DishOption>[];
  final ids = <String>{};
  for (var i = 0; i < raw.length; i++) {
    final e = raw[i];
    if (e is! Map<String, dynamic>) {
      body.fail('$key[$i]', 'Must be an object.');
      continue;
    }
    final id = e['id'];
    final name = e['name'];
    final price = e['priceDeltaCents'];
    final description = e['description'];
    if (id is! String || !_slug.hasMatch(id) || !ids.add(id)) {
      body.fail('$key[$i].id', 'Use a unique lowercase id (a-z, 0-9, _).');
    } else if (name is! String || name.trim().isEmpty || name.length > 60) {
      body.fail('$key[$i].name', 'Required, up to 60 characters.');
    } else if (price is! int || price < 0 || price > 100000) {
      body.fail('$key[$i].priceDeltaCents', 'Whole cents, 0 or more.');
    } else if (description != null && description is! String) {
      body.fail('$key[$i].description', 'Must be text.');
    } else {
      out.add(DishOption(id: id, name: name.trim(), priceDeltaCents: price, description: description as String?));
    }
  }
  return out;
}

List<OpeningHours>? readHours(Body body) {
  final raw = body.raw['hours'];
  if (raw == null) return null;
  if (raw is! List || raw.isEmpty) {
    body.fail('hours', 'Must be a non-empty list of {label, weekdays, opens, closes}.');
    return null;
  }
  final out = <OpeningHours>[];
  for (var i = 0; i < raw.length; i++) {
    final e = raw[i];
    if (e is! Map<String, dynamic> ||
        e['label'] is! String ||
        e['weekdays'] is! List ||
        (e['weekdays'] as List).any((d) => d is! int || d < 1 || d > 7) ||
        e['opens'] is! String ||
        e['closes'] is! String ||
        !_hhmm.hasMatch(e['opens'] as String) ||
        !_hhmm.hasMatch(e['closes'] as String) ||
        OpeningHours.toMinutes(e['opens'] as String) >= OpeningHours.toMinutes(e['closes'] as String)) {
      body.fail('hours[$i]', 'Use {label, weekdays: [1-7], opens: "HH:mm", closes: "HH:mm"} with opens before closes.');
      continue;
    }
    out.add(
      OpeningHours(
        e['label'] as String,
        (e['weekdays'] as List).cast<int>(),
        e['opens'] as String,
        e['closes'] as String,
      ),
    );
  }
  return out;
}

/// Applies (and validates) restaurant fields. With [creating] the core fields
/// are required.
void applyRestaurantInput(Body body, Restaurant r, {required bool creating}) {
  final name = body.string('name', required: creating, max: 80);
  final cuisines = body.strings('cuisines', required: creating, maxItems: 5);
  final categoryIds = body.strings('categoryIds', maxItems: 6);
  final neighborhood = body.string('neighborhood', max: 60);
  final tagline = body.string('tagline', max: 200);
  final description = body.string('description', max: 1000);
  final address = body.string('address', required: creating, max: 200);
  final phone = body.string('phone', max: 30);
  final lat = body.number('lat', required: creating, min: -90, max: 90);
  final lng = body.number('lng', required: creating, min: -180, max: 180);
  final minMinutes = body.integer('deliveryMinMinutes', min: 5, max: 180);
  final maxMinutes = body.integer('deliveryMaxMinutes', min: 5, max: 240);
  final fee = body.integer('deliveryFeeCents', min: 0, max: 5000);
  final minOrder = body.integer('minOrderCents', min: 0, max: 50000);
  final priceLevel = body.integer('priceLevel', min: 1, max: 4);
  final dietary = body.strings('dietary', maxItems: 4);
  final offer = body.string('offer', max: 80);
  final badge = body.string('badge', max: 40);
  final accepting = body.boolean('isAcceptingOrders');
  final imageUrl = body.string('imageUrl', max: 500);
  final menuSections = body.strings('menuSections', maxItems: 20);
  final hours = readHours(body);
  if (dietary != null && dietary.any((d) => !dietaryOptions.contains(d))) {
    body.fail('dietary', 'Use: ${dietaryOptions.join(', ')}.');
  }
  if ((minMinutes ?? r.deliveryMinMinutes) > (maxMinutes ?? r.deliveryMaxMinutes)) {
    body.fail('deliveryMinMinutes', 'Must not be more than deliveryMaxMinutes.');
  }
  body.validate();

  if (name != null) r.name = name;
  if (cuisines != null) r.cuisines = cuisines;
  if (categoryIds != null) r.categoryIds = categoryIds;
  if (neighborhood != null) r.neighborhood = neighborhood;
  if (tagline != null) r.tagline = tagline;
  if (description != null) r.description = description;
  if (address != null) r.address = address;
  if (phone != null) r.phone = phone;
  if (lat != null) r.lat = lat;
  if (lng != null) r.lng = lng;
  if (minMinutes != null) r.deliveryMinMinutes = minMinutes;
  if (maxMinutes != null) r.deliveryMaxMinutes = maxMinutes;
  if (fee != null) r.deliveryFeeCents = fee;
  if (minOrder != null) r.minOrderCents = minOrder;
  if (priceLevel != null) r.priceLevel = priceLevel;
  if (dietary != null) r.dietary = dietary;
  if (body.has('offer')) r.offer = offer;
  if (body.has('badge')) r.badge = badge;
  if (accepting != null) r.isAcceptingOrders = accepting;
  if (imageUrl != null) r.imageUrl = imageUrl;
  if (menuSections != null) r.menuSections = menuSections;
  if (hours != null) r.hours = hours;
}

void applyDishInput(Body body, Dish d, {required bool creating}) {
  final name = body.string('name', required: creating, max: 80);
  final description = body.string('description', required: creating, max: 200);
  final details = body.string('details', max: 1000);
  final price = body.integer('priceCents', required: creating, min: 0, max: 100000);
  final section = body.string('section', required: creating, max: 40);
  final imageUrl = body.string('imageUrl', max: 500);
  final dietary = body.strings('dietary', maxItems: 4);
  final tags = body.strings('tags', maxItems: 10);
  final allergens = body.string('allergens', max: 200);
  final popular = body.boolean('isPopular');
  final available = body.boolean('isAvailable');
  final sizes = readOptions(body, 'sizes');
  final addOns = readOptions(body, 'addOns');
  if (sizes != null && sizes.isEmpty) body.fail('sizes', 'Add at least one size.');
  if (dietary != null && dietary.any((x) => !dietaryOptions.contains(x))) {
    body.fail('dietary', 'Use: ${dietaryOptions.join(', ')}.');
  }
  body.validate();

  if (name != null) d.name = name;
  if (description != null) d.description = description;
  if (body.has('details')) d.details = details;
  if (price != null) d.priceCents = price;
  if (section != null) d.section = section;
  if (imageUrl != null) d.imageUrl = imageUrl;
  if (dietary != null) d.dietary = dietary;
  if (tags != null) d.tags = tags;
  if (body.has('allergens')) d.allergens = allergens;
  if (popular != null) d.isPopular = popular;
  if (available != null) d.isAvailable = available;
  if (sizes != null) d.sizes = sizes;
  if (addOns != null) d.addOns = addOns;
}
